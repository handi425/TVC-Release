﻿//+------------------------------------------------------------------+
//|                                           EntryAjaib_HW.mq5 |
//|                                Copyright 2025, XoRonX G3DH3       |
//|                                         MetaTrader 5 EA           |
//+------------------------------------------------------------------+
#property copyright "XoRonX G3DH3"
#property version   "1.95" // Pembersihan kode tidak terpakai; invalidasi SL tetap aktif
#property strict

#define UI_BG_ZORDER       900
#define UI_OBJECT_ZORDER   1000
#define CHART_LINE_ZORDER  10

//--- INPUT PARAMETERS
input group       "Magic Number"
input long        InpMagicNumber  = 0;  // Magic Number untuk identifikasi order

#include <Trade\Trade.mqh>

//--- INPUT PARAMETERS
input group       "Entry Settings"
input double      InpEntryLot     = 0.5;  
input int         InpLayerCount   = 5;     
input int         InpMultiStep    = 2500;     // Jarak antar layer (Points) - Manual Input

input group       "Risk Reward"
input bool        InpSLTPEnabled  = true;     // SL/TP ON (false = entry tanpa SL/TP)
input int         InpSLPoints     = 20000;
input double      InpRewardRatio  = 2.0;
input int         InpBEPProfitPoints = 10000;  // Profit kecil saat pindah SL ke BEP (Points)


input group       "Close Settings"
input bool        InpCloseOwnOnly = true;     // Close Only EA's Entries (ceklis untuk aktifkan)
input bool        InpTodayOnly = true; // Filter hari ini untuk CLOSE ALL, BEP, dan TP partial


input group       "Margin Safety Settings"
input double      InpMaxMarginUsage = 20.0;   // Max Margin Usage (%) - Batas aman penggunaan margin
input double      InpMinMarginLevel = 150.0;  // Min Margin Level (%) - Level margin minimum sebelum warning

input group       "Notification Settings"
input bool        InpPushNotifPending = true; // Push Notif ke MT5 Mobile saat Pending Order tereksekusi

input group       "Appearance"
input bool        InpShowPanel    = false;     // Show Panel (tampilkan panel trading)
input color       TextColor       = clrWhite;

input group       "UI Scaling (HiDPI / Retina / MacBook)"
input double      InpUIScale      = 0.4;        // UI Scale (0 = auto dari DPI layar)
input int         InpUIFontDelta  = 0;        // Font Adjust (-6..+6, kecilkan bila teks terpotong)
input bool        InpUIAutoFit    = true;     // Auto Fit (kecilkan panel agar muat di chart)

//--- PLAN hanya mengirim order setelah candle breakout benar-benar close.
enum ENUM_HW_PLAN_ENTRY
  {
   HW_PLAN_DIRECT = 0, // Langsung entry setelah close (layer 1 market)
   HW_PLAN_RETEST = 1  // Retest setelah close (pending limit pada garis)
  };
input group "PLAN Breakout Confirmation"
input ENUM_HW_PLAN_ENTRY InpPlanEntryMode = HW_PLAN_DIRECT;
input ENUM_TIMEFRAMES InpPlanTimeframe = PERIOD_CURRENT; // CURRENT = timeframe chart
input int InpPlanWatchSeconds = 10; // Pantau countdown detik terakhir, tetap tunggu close

//--- Global Variables
CTrade trade;

//--- UI Layout Metrics ---------------------------------------------------
// Angka dasar di bawah dirancang untuk layar 96 DPI. Semua dimensi pixel
// dikalikan UIScale supaya panel ikut membesar di layar HiDPI/Retina
// (MacBook Pro), sementara lebar tombol dihitung ulang dari lebar teks yang
// benar-benar dirender sehingga label tidak pernah terpotong.
// Semua nilai di bawah di-set ulang oleh RecalcUIMetrics().
#define UI_BASE_DPI     96.0
#define UI_BASE_BTN_W   80
#define UI_BASE_BTN_H   30
#define UI_BASE_GAP     5
#define UI_BASE_MARGIN  10
#define UI_BTN_FONT     "Arial"

double UIScale     = 1.0;   // Faktor skala pixel aktif
int    UIFontDelta = 0;     // Penyesuaian font aktif (input + hasil auto-fit)

int buttonWidth  = UI_BASE_BTN_W;   // Lebar tombol utama (adaptif ke teks)
int buttonHeight = UI_BASE_BTN_H;
int startX       = UI_BASE_MARGIN;  // Margin kiri panel
int startY       = 35;              // Baris 0 dihitung dari sisi bawah chart
int gapY         = 35;              // Jarak antar baris
int colGap       = UI_BASE_GAP;     // Jarak antar kolom
int colPitch     = UI_BASE_BTN_W + UI_BASE_GAP;

int ctlLabelW    = 45;   // Lebar kolom label control panel (LOT:, GRID:, ...)
int ctlLabelH    = 14;   // Tinggi teks label control panel
int ctlEditW     = 55;   // Lebar edit box control panel
int ctlSmallW    = 25;   // Lebar tombol +/- control panel

int LastChartW   = -1;   // Cache ukuran chart, supaya scroll/zoom tidak memicu relayout
int LastChartH   = -1;

//--- Tunda relayout selama garis Plan sedang digeser. Memindahkan
//--- puluhan objek panel di tengah drag membuat MT5 melepas pegangan pada
//--- garis yang sedang ditarik (garisnya lompat / drag putus).
#define UI_DRAG_QUIET_MS 400
uint LastDragTick = 0;   // GetTickCount() saat event drag objek terakhir

string ObjPlanEntry = "Plan_Line_Entry";
string ObjPlanSL    = "Plan_Line_SL";
string ObjPlanTP    = "Plan_Line_TP";
string ObjPlanShadowPrefix = "Plan_Shadow_"; // Prefix untuk shadow multi-layer

//--- Harga terakhir garis yang bisa di-drag. Dipakai SyncDraggableLines()
//--- untuk mendeteksi pergerakan saat drag masih berlangsung.
double lastPlanEntryPrice = 0;
double lastPlanSLPrice    = 0;
double lastPlanTPPrice    = 0;

//--- Lot Control Variables
double CurrentLot = 0.01;       // Lot aktif yang digunakan
double LotStep = 0.01;          // Step untuk increment/decrement
double MinLot = 0.01;           // Minimum lot
double MaxLot = 100.0;          // Maximum lot
string ObjLotEdit = "BtnLotEdit";
string ObjLotLabel = "BtnLotLabel";
string ObjLotPlus = "BtnLotPlus";
string ObjLotMinus = "BtnLotMinus";

//--- Grid Control Variables (Jarak antar layer dalam Points)
int CurrentGrid = 550;          // Grid step aktif
int GridStep = 50;              // Step untuk increment/decrement
int MinGrid = 50;               // Minimum grid
int MaxGrid = 10000;            // Maximum grid
string ObjGridEdit = "BtnGridEdit";
string ObjGridLabel = "BtnGridLabel";
string ObjGridPlus = "BtnGridPlus";
string ObjGridMinus = "BtnGridMinus";

//--- Default awal garis SL (Points)
int CurrentSL = 10000;          // SL aktif

//--- Default awal garis TP (Risk:Reward)
double CurrentTPRatio = 2.0;    // TP Ratio aktif

//--- Layer Control Variables (Jumlah Layer)
int CurrentLayer = 5;           // Layer aktif
int LayerStep = 1;              // Step untuk increment/decrement
int MinLayer = 1;               // Minimum layer
int MaxLayer = 50;              // Maximum layer
string ObjLayerEdit = "BtnLayerEdit";
string ObjLayerLabel = "BtnLayerLabel";
string ObjLayerPlus = "BtnLayerPlus";
string ObjLayerMinus = "BtnLayerMinus";

//--- Watermark Variables
string ObjWatermark = "WatermarkLabel";
string EA_VERSION = "1.95";


//--- TP Partial Variables
string ObjTPPartialBtn = "BtnTPPartial";
int CurrentTPPartialPercent = 50;           // Persentase lot yang ditutup oleh TP partial
int TPPartialStep = 5;                      // Step untuk increment/decrement TP partial
int MinTPPartialPercent = 10;               // Minimum TP partial percent
int MaxTPPartialPercent = 90;               // Maximum TP partial percent
string ObjTPPartialEdit = "BtnTPPartialEdit";
string ObjTPPartialLabel = "BtnTPPartialLabel";
string ObjTPPartialPlus = "BtnTPPartialPlus";
string ObjTPPartialMinus = "BtnTPPartialMinus";
string ObjBEPBtn = "BtnBEP";

//--- Filter posisi untuk seluruh aksi manajemen posisi
bool TodayOnlyEnabled = true;                // Default: abaikan posisi dari hari sebelumnya

//--- Toggle visibilitas panel tombol trading
bool UIButtonsVisible = true;
string ObjUIPanelToggle = "BtnUIPanelToggle";

//--- BEP Control Variables
int CurrentBEPProfitPoints = 1000;          // Buffer profit saat pindah SL ke BEP
int BEPStep = 100;                          // Step untuk increment/decrement BEP
int MinBEPProfitPoints = 0;                 // Minimum BEP buffer
int MaxBEPProfitPoints = 50000;             // Maximum BEP buffer
string ObjBEPEdit = "BtnBEPEdit";
string ObjBEPLabel = "BtnBEPLabel";
string ObjBEPPlus = "BtnBEPPlus";
string ObjBEPMinus = "BtnBEPMinus";

//--- Plan Info Panel Variables
string ObjPlanInfoBG = "PlanInfoBG";
string ObjPlanInfoTitle = "PlanInfoTitle";
string ObjPlanInfoType = "PlanInfoType";
string ObjPlanInfoEntry = "PlanInfoEntry";
string ObjPlanInfoSL = "PlanInfoSL";
string ObjPlanInfoTP = "PlanInfoTP";
string ObjPlanInfoRisk = "PlanInfoRisk";
string ObjPlanInfoProfit = "PlanInfoProfit";
string ObjPlanInfoRR = "PlanInfoRR";
string ObjPlanInfoPips = "PlanInfoPips";
string ObjPlanExecuteBtn = "BtnPlanExecute"; // Tombol eksekusi mode plan aktif
string ObjPlanModeBtn = "BtnPlanMode";       // Toggle DIRECT / RETEST
ENUM_HW_PLAN_ENTRY CurrentPlanEntryMode = HW_PLAN_DIRECT;


//--- Virtual PLAN state. Snapshot dibuat saat ARM, tanpa request ke broker.
bool PlanArmed = false;
bool PlanSnapshotBuy = true;
ENUM_HW_PLAN_ENTRY PlanSnapshotEntryMode = HW_PLAN_DIRECT;
double PlanSnapshotEntry = 0;
double PlanSnapshotSL = 0;
double PlanSnapshotTP = 0;
double PlanSnapshotLot = 0;
int PlanSnapshotLayers = 0;
int PlanSnapshotGrid = 0;
datetime PlanArmedBar = 0;
datetime PlanLastClosedBar = 0;
string PlanStatus = "DRAFT - tekan ARM PLAN";
string ObjPlanInfoStatus = "PlanInfoStatus";

//--- Position Stats Panel Variables (Left Upper Corner)
string ObjStatsPanelBG = "StatsPanelBG";
string ObjStatsPanelTitle = "StatsPanelTitle";
string ObjStatsTotalProfit = "StatsTotalProfit";
string ObjStatsTotalPips = "StatsTotalPips";
string ObjStatsTotalPoints = "StatsTotalPoints";
string ObjStatsLayerBuy = "StatsLayerBuy";
string ObjStatsLayerSell = "StatsLayerSell";
string ObjStatsLotBuy = "StatsLotBuy";
string ObjStatsLotSell = "StatsLotSell";

//--- Lot Margin Info Variables
string ObjStatsUsedLot = "StatsUsedLot";
string ObjStatsAvailableLot = "StatsAvailableLot";
string ObjStatsMaxLot = "StatsMaxLot";
string ObjStatsBrokerTime = "StatsBrokerTime";
string ObjStatsSafeLot = "StatsSafeLot";
string ObjStatsMarginLevel = "StatsMarginLevel";
string ObjStatsSeparator = "StatsSeparator";

//--- Cent Account Detection
bool IsCentAccount = false;
double CentDivisor = 1.0;  // 1.0 for standard, 100.0 for cent

//--- Margin Call Line Variables
string ObjMCLine = "EA_MC_Line";
string ObjMCLabel = "EA_MC_Label";
double StopOutLevel = 50.0;  // Stop Out Level (%) - biasanya 50% atau 100%

//--- Zero Balance Line Variables (Liquidation Level - Final Stop)
string ObjZeroBalanceLine = "EA_ZeroBalance_Line";
string ObjZeroBalanceLabel = "EA_ZeroBalance_Label";

//+------------------------------------------------------------------+
//| UI Scaling Helpers                                                |
//+------------------------------------------------------------------+
//| Konversi nilai desain (96 DPI) ke pixel chart pada skala aktif.   |
//+------------------------------------------------------------------+
int UIPix(const int base)
{
   int v = (int)MathRound(base * UIScale);
   return(v < 1 ? 1 : v);
}

int UIFont(const int base)
{
   int f = base + UIFontDelta;
   if(f < 5)  f = 5;    // batas bawah; di layar Retina 5pt masih terbaca (dirender ~2x)
   if(f > 36) f = 36;
   return(f);
}

//--- Ukuran teks yang benar-benar dirender terminal (sudah ikut DPI layar).
//--- Inilah kunci anti "teks terpotong": lebar tombol dihitung dari sini,
//--- bukan dari konstanta pixel.
bool UIMeasureText(const string text, const int fontSize, const string font, int &w, int &h)
{
   uint tw = 0, th = 0;
   TextSetFont(font, -fontSize * 10, 0, 0);   // size negatif = 1/10 point, DPI-aware
   if(!TextGetSize(text, tw, th))
      return(false);
   w = (int)tw;
   h = (int)th;
   return(true);
}

int UITextWidth(const string text, const int fontSize, const string font)
{
   int w = 0, h = 0;
   if(!UIMeasureText(text, fontSize, font, w, h))
      return(0);
   return(w);
}

int UITextHeight(const string text, const int fontSize, const string font)
{
   int w = 0, h = 0;
   if(!UIMeasureText(text, fontSize, font, w, h))
      return(0);
   return(h);
}

//--- Semua label tombol utama + toggle, dipakai untuk mengukur lebar kolom.
void UIButtonLabels(string &out[])
{
   ArrayResize(out, 13);
   out[0] = "BUY NOW";
   out[1] = "SELL NOW";
   out[2] = "PLAN BUY";
   out[3] = "PLAN SELL";
   out[4] = "CLOSE ALL";
   out[5] = "BEP";
   out[6] = "TP½";
   out[7] = "SHOW ON";
   out[8] = "SHOW OFF";
   out[9] = "CANCEL PLAN";
   out[10] = "DIRECT";
   out[11] = "RETEST";
   out[12] = "ARM PLAN";
}

//--- Hitung seluruh metrik panel untuk satu nilai skala.
void UIComputeMetrics(const double scale)
{
   UIScale = scale;

   colGap = UIPix(UI_BASE_GAP);
   startX = UIPix(UI_BASE_MARGIN);

   //--- Tinggi tombol: minimal cukup untuk satu baris teks
   int lineH = UITextHeight("Ag", UIFont(9), UI_BTN_FONT);
   buttonHeight = UIPix(UI_BASE_BTN_H);
   if(lineH + UIPix(8) > buttonHeight)
      buttonHeight = lineH + UIPix(8);

   //--- Lebar tombol: cukup untuk label terpanjang (toggle pakai font 8)
   string labels[];
   UIButtonLabels(labels);
   int widest = 0;
   for(int i = 0; i < ArraySize(labels); i++)
   {
      int w = UITextWidth(labels[i], UIFont(8), UI_BTN_FONT);
      if(w > widest)
         widest = w;
   }
   buttonWidth = UIPix(UI_BASE_BTN_W);
   if(widest + UIPix(10) > buttonWidth)
      buttonWidth = widest + UIPix(10);

   colPitch = buttonWidth + colGap;
   gapY     = buttonHeight + UIPix(UI_BASE_GAP);
   startY   = gapY;

   //--- Metrik control panel: LABEL [-] [edit] [+]
   string ctlLabels[5] = {"LOT:", "GRID:", "LYR:", "TP1/2:", "BEP:"};
   int labelW = 0;
   for(int i = 0; i < ArraySize(ctlLabels); i++)
   {
      int w = UITextWidth(ctlLabels[i], UIFont(9), "Arial Bold");
      if(w > labelW)
         labelW = w;
   }
   ctlLabelW = (int)MathMax(UIPix(45), labelW + UIPix(8));
   ctlLabelH = (int)MathMax(UIPix(12), UITextHeight("Ag", UIFont(9), "Arial Bold"));
   ctlEditW  = (int)MathMax(UIPix(52), UITextWidth("000000", UIFont(10), UI_BTN_FONT) + UIPix(10));
   ctlSmallW = (int)MathMax(UIPix(25), UITextWidth("+", UIFont(12), UI_BTN_FONT) + UIPix(12));
   int controlW = ctlLabelW + (2 * ctlSmallW) + ctlEditW + UIPix(6);
   colPitch = (int)MathMax(colPitch, MathCeil((controlW + colGap) / 2.0));
}

//--- Metrik panel Position Stats (kiri-atas). Dipakai bersama oleh
//--- CreatePositionStatsPanel() dan perhitungan auto-fit di bawah.
int UIStatsLineHeight()
{
   return((int)MathMax(UIPix(18), UITextHeight("Ag", UIFont(9), "Consolas") + UIPix(4)));
}

int UIStatsPanelHeight()
{
   // 14 langkah baris + 4 jarak ekstra antar grup + baris terakhir.
   // Satu langkah tambahan digunakan untuk jam broker di bawah Max Capacity.
   int lineH = UIStatsLineHeight();
   return(UIPix(12) + (14 * lineH) + UIPix(5) + UIPix(3) + UIPix(5) + UIPix(5) + UIPix(16));
}

//--- Lebar/tinggi total yang dibutuhkan seluruh UI.
int UIRequiredWidth()
{
   int rowButtons = startX + colPitch + buttonWidth; // dua kolom aksi
   int rowControl = startX + (2 * colPitch) + ctlLabelW + (2 * ctlSmallW) + ctlEditW + UIPix(6);
   return((int)MathMax(rowButtons, rowControl));
}

int UIRequiredHeight()
{
   int h = startY + (4 * gapY) + buttonHeight; // nama EA sejajar LOT di baris 4
   if(InpShowPanel)
      h += UIPix(10) + UIStatsPanelHeight();     // panel stats menumpuk di kiri-atas
   return(h);
}

//+------------------------------------------------------------------+
//| Hitung ulang skala panel: DPI layar -> auto-fit ke ukuran chart   |
//+------------------------------------------------------------------+
void RecalcUIMetrics()
{
   //--- 1) Skala dasar: manual (InpUIScale) atau otomatis dari DPI layar.
   //---    Di Retina/HiDPI font dirender lebih besar dari koordinat pixel
   //---    chart, jadi dimensi pixel harus ikut dinaikkan.
   double scale = InpUIScale;
   if(scale <= 0)
   {
      double dpi = (double)TerminalInfoInteger(TERMINAL_SCREEN_DPI);
      if(dpi <= 0)
         dpi = UI_BASE_DPI;
      scale = dpi / UI_BASE_DPI;
   }
   scale = MathMax(0.55, MathMin(3.00, scale));

   UIFontDelta = (int)MathMax(-6, MathMin(6, InpUIFontDelta));

   int chartW = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
   int chartH = (int)ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);

   //--- 2) Auto-fit: kecilkan skala pixel selama masih menolong; begitu lebar
   //---    dikunci oleh lebar teks (mengecilkan skala tidak berpengaruh lagi),
   //---    barulah font yang diturunkan.
   int prevNeedW = -1;
   int prevNeedH = -1;

   for(int pass = 0; pass < 16; pass++)
   {
      UIComputeMetrics(scale);

      if(!InpUIAutoFit || chartW <= 0 || chartH <= 0)
         break;

      int needW = UIRequiredWidth();
      int needH = UIRequiredHeight();

      // Panel tombol (kiri-bawah) dan panel stats (kiri-atas) bertumpuk secara
      // vertikal, jadi budget tinggi hampir setinggi chart: syaratnya cuma
      // tidak saling menimpa.
      double fitW = (chartW * 0.85) / (double)needW;
      double fitH = (chartH * 0.98) / (double)needH;
      if(MathMin(fitW, fitH) >= 0.99)
         break;                                   // sudah muat

      // Cek kemajuan hanya pada sisi yang benar-benar jadi kendala
      bool progressed;
      if(fitW <= fitH)
         progressed = (prevNeedW < 0) || (needW <= (int)(prevNeedW * 0.97));
      else
         progressed = (prevNeedH < 0) || (needH <= (int)(prevNeedH * 0.97));

      prevNeedW = needW;
      prevNeedH = needH;

      if(scale > 0.55 && progressed)
      {
         scale = MathMax(0.55, scale * MathMax(MathMin(fitW, fitH), 0.75));
         continue;
      }
      if(UIFontDelta > -6)
      {
         UIFontDelta--;                           // font memang terlalu besar untuk chart ini
         continue;
      }
      break;
   }
}

//+------------------------------------------------------------------+
//| Chart/UI layering helpers                                        |
//+------------------------------------------------------------------+
void PrepareChartForUI()
{
   // Jika Chart on foreground aktif, candle/indikator akan menggambar di atas panel.
   ChartSetInteger(0, CHART_FOREGROUND, false);
}

bool IsUIBackgroundName(string name)
{
   return(name == ObjStatsPanelBG ||
          name == ObjPlanInfoBG);
}

bool IsUIObjectName(string name)
{
   return(name == ObjWatermark ||
          StringFind(name, "Btn") == 0 ||
          StringFind(name, "Stats") == 0 ||
          StringFind(name, "PlanInfo") == 0);
}

//--- Elemen panel tombol memakai prefix "Btn"; watermark ikut disembunyikan
//--- agar mode OFF benar-benar menyisakan satu tombol untuk membuka panel lagi.
bool IsUIButtonPanelObjectName(string name)
{
   return(name == ObjWatermark || StringFind(name, "Btn") == 0);
}

void SetUIButtonPanelVisibility(const bool visible)
{
   int total = ObjectsTotal(0);
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i);
      if(!IsUIButtonPanelObjectName(name))
         continue;

      // Toggle SHOW harus selalu terlihat, termasuk saat panel sedang OFF.
      long periods = (visible || name == ObjUIPanelToggle)
                     ? OBJ_ALL_PERIODS : OBJ_NO_PERIODS;
      ObjectSetInteger(0, name, OBJPROP_TIMEFRAMES, periods);
   }
}

void SetUIObjectOnTop(string name, long zorder)
{
   if(ObjectFind(0, name) < 0)
      return;

   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_ZORDER, zorder);
}

void SetChartObjectBehindUI(string name)
{
   if(ObjectFind(0, name) < 0)
      return;

   ObjectSetInteger(0, name, OBJPROP_BACK, true);
   ObjectSetInteger(0, name, OBJPROP_ZORDER, CHART_LINE_ZORDER);
}

void BringUIToFront()
{
   int total = ObjectsTotal(0);
   for(int i = total - 1; i >= 0; i--)
   {
      string name = ObjectName(0, i);
      if(!IsUIObjectName(name))
         continue;

      SetUIObjectOnTop(name, IsUIBackgroundName(name) ? UI_BG_ZORDER : UI_OBJECT_ZORDER);
   }
}

//+------------------------------------------------------------------+
//| Terapkan ulang seluruh geometri UI dengan metrik yang berlaku.    |
//| Semua fungsi Create* di bawah bersifat idempotent: objek dibuat   |
//| sekali, tetapi posisi/ukuran/font selalu di-set ulang.            |
//+------------------------------------------------------------------+
void ApplyUILayout()
{
   if(InpShowPanel)
      CreatePositionStatsPanel();

   CreateUI();
   CreateWatermark();

   //--- Panel info hanya ditata ulang bila memang sedang tampil.
   //--- PENTING: hanya geometri yang disentuh di sini. Jangan panggil
   //--- Update*Labels() dari jalur relayout — fungsi itu ikut memindahkan
   //--- garis Plan dan membuat ulang shadow line, sehingga kalau
   //--- terpicu di tengah drag, MT5 kehilangan pegangan pada garis yang
   //--- sedang ditarik. Teks label sendiri sudah dipertahankan karena
   //--- Create*InfoLabel() hanya menulis teks saat objek pertama dibuat.
   if(ObjectFind(0, ObjPlanInfoBG) >= 0)
      CreatePlanInfoPanel();

   SetUIButtonPanelVisibility(UIButtonsVisible);
   BringUIToFront();
}

//+------------------------------------------------------------------+
//| Relayout saat ukuran chart berubah (resize window / ganti layar). |
//| CHARTEVENT_CHART_CHANGE juga terpicu saat scroll & zoom, jadi     |
//| ukuran chart di-cache supaya relayout tidak jalan sia-sia.        |
//+------------------------------------------------------------------+
void RelayoutUI(const bool force = false)
{
   int w = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
   int h = (int)ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);

   if(!force && w == LastChartW && h == LastChartH)
      return;

   // Sedang / baru saja menggeser objek: tunda. Cache sengaja TIDAK diperbarui
   // supaya relayout tetap dijalankan pada pemanggilan berikutnya (OnTick).
   if(!force && (GetTickCount() - LastDragTick) < UI_DRAG_QUIET_MS)
      return;

   LastChartW = w;
   LastChartH = h;

   RecalcUIMetrics();
   ApplyUILayout();

   // Dicetak ke tab Experts supaya mudah menyetel InpUIScale / InpUIFontDelta
   // kalau terminal melaporkan DPI yang tidak sesuai (mis. MT5 via Wine di Mac).
   PrintFormat("UI layout: chart %dx%d px | DPI %d | scale %.2f | font %+d | tombol %dx%d px",
               w, h, (int)TerminalInfoInteger(TERMINAL_SCREEN_DPI),
               UIScale, UIFontDelta, buttonWidth, buttonHeight);
}

//+------------------------------------------------------------------+
//| Sinkronisasi garis turunan selama garis induk masih di-drag       |
//|                                                                   |
//| MT5 hanya mengirim CHARTEVENT_OBJECT_DRAG SEKALI, yaitu saat      |
//| tombol mouse dilepas. Akibatnya garis SL/TP dan shadow layer baru |
//| menyusul setelah drag selesai — terlihat seperti "anak tidak ikut |
//| ter-drag". Fungsi ini dipanggil dari CHARTEVENT_MOUSE_MOVE supaya |
//| semuanya bergerak mengikuti garis induk secara real-time.         |
//|                                                                   |
//| Return: true bila ada yang berubah (perlu ChartRedraw).           |
//+------------------------------------------------------------------+
void UpdatePlanDefaultsFromLines()
{
   if(ObjectFind(0, ObjPlanEntry) < 0 ||
      ObjectFind(0, ObjPlanSL) < 0 ||
      ObjectFind(0, ObjPlanTP) < 0)
      return;

   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   if(point <= 0)
      return;

   double entry = ObjectGetDouble(0, ObjPlanEntry, OBJPROP_PRICE);
   double sl = ObjectGetDouble(0, ObjPlanSL, OBJPROP_PRICE);
   double tp = ObjectGetDouble(0, ObjPlanTP, OBJPROP_PRICE);
   double slPoints = MathAbs(entry - sl) / point;
   double tpPoints = MathAbs(tp - entry) / point;

   // Simpan default dari hasil drag. Eksekusi tetap membaca harga garis dengan presisi penuh.
   if(slPoints >= 1.0)
      CurrentSL = (int)MathRound(slPoints);
   if(slPoints > 0)
      CurrentTPRatio = NormalizeDouble(tpPoints / slPoints, 1);

}

bool SyncDraggableLines()
{
   bool moved = false;
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double tol = point * 0.5;

   if(ObjectFind(0, ObjPlanEntry) >= 0 &&
      ObjectFind(0, ObjPlanSL) >= 0 &&
      ObjectFind(0, ObjPlanTP) >= 0)
     {
      double entry = ObjectGetDouble(0, ObjPlanEntry, OBJPROP_PRICE);
      double sl    = ObjectGetDouble(0, ObjPlanSL, OBJPROP_PRICE);
      double tp    = ObjectGetDouble(0, ObjPlanTP, OBJPROP_PRICE);

      // Inisialisasi cache ketika plan baru dibuat / EA baru dimuat.
      if(lastPlanEntryPrice <= 0 || lastPlanSLPrice <= 0 || lastPlanTPPrice <= 0)
        {
         lastPlanEntryPrice = entry;
         lastPlanSLPrice = sl;
         lastPlanTPPrice = tp;
        }

      // Entry adalah induk plan. Saat Entry digeser, pertahankan jarak SL/TP
      // yang terakhir (termasuk jarak hasil drag manual) dan geser semuanya.
      if(MathAbs(entry - lastPlanEntryPrice) > tol)
        {
         double delta = entry - lastPlanEntryPrice;
         sl = NormalizeDouble(sl + delta, _Digits);
         tp = NormalizeDouble(tp + delta, _Digits);
         ObjectSetDouble(0, ObjPlanSL, OBJPROP_PRICE, sl);
         ObjectSetDouble(0, ObjPlanTP, OBJPROP_PRICE, tp);

         lastPlanEntryPrice = entry;
         lastPlanSLPrice = sl;
         lastPlanTPPrice = tp;
         UpdatePlanLabels();
         moved = true;
        }
      else
        {
         long entryColor = ObjectGetInteger(0, ObjPlanEntry, OBJPROP_COLOR);
         bool isBuyPlan = (entryColor == clrBlue);

         // SL dan TP dapat digeser masing-masing. Level yang menyeberangi
         // Entry dikembalikan ke posisi valid terakhir. Jarak ditentukan dari garis.
         if(MathAbs(sl - lastPlanSLPrice) > tol)
           {
            bool validSide = isBuyPlan ? (sl < entry - tol) : (sl > entry + tol);
            bool validSL = validSide;
            if(validSL)
              {
               lastPlanSLPrice = sl;
               UpdatePlanDefaultsFromLines();
              }
            else
              {
               sl = lastPlanSLPrice;
               ObjectSetDouble(0, ObjPlanSL, OBJPROP_PRICE, sl);
              }
            UpdatePlanLabels();
            moved = true;
           }

         if(MathAbs(tp - lastPlanTPPrice) > tol)
           {
            bool validSide = isBuyPlan ? (tp > entry + tol) : (tp < entry - tol);
            bool validTP = validSide;
            if(validTP)
              {
               lastPlanTPPrice = tp;
               UpdatePlanDefaultsFromLines();
              }
            else
              {
               tp = lastPlanTPPrice;
               ObjectSetDouble(0, ObjPlanTP, OBJPROP_PRICE, tp);
              }
            UpdatePlanLabels();
            moved = true;
           }
        }
     }


   return(moved);
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   PrepareChartForUI();
   CurrentPlanEntryMode = InpPlanEntryMode;
   TodayOnlyEnabled = InpTodayOnly;

   // Wajib aktif supaya CHARTEVENT_MOUSE_MOVE terkirim; itulah satu-satunya cara
   // membuat garis SL/TP/shadow ikut bergerak SELAMA garis Entry masih ditarik
   // (CHARTEVENT_OBJECT_DRAG baru dikirim MT5 setelah tombol mouse dilepas).
   // Di-set sekali di sini, bukan di PrepareChartForUI() yang jalan tiap
   // CHART_CHANGE, supaya tidak ada tulis-properti berulang di jalur panas.
   ChartSetInteger(0, CHART_EVENT_MOUSE_MOVE, true);

   trade.SetExpertMagicNumber(InpMagicNumber);  // Set magic number untuk identifikasi
   trade.SetTypeFilling(ORDER_FILLING_IOC);
   
   // Initialize lot settings from symbol info
   CurrentLot = InpEntryLot;
   LotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   MinLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   MaxLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   
   // Initialize control variables from input parameters
   CurrentGrid = InpMultiStep;
   CurrentSL = InpSLPoints;
   CurrentTPRatio = InpRewardRatio;
   CurrentLayer = InpLayerCount;
   CurrentBEPProfitPoints = InpBEPProfitPoints;

   // Detect Cent Account
   DetectCentAccount();

   // Hitung metrik UI (DPI layar + auto-fit) lalu bangun panel
   RelayoutUI(true);
   EventSetTimer(1); // Countdown PLAN dan jam broker, termasuk tanpa tick
   ChartRedraw();
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   EventKillTimer();
   ObjectsDeleteAll(0, "Btn");
   ObjectDelete(0, ObjLotEdit);
   ObjectDelete(0, ObjLotLabel);
   ObjectDelete(0, ObjGridEdit);
   ObjectDelete(0, ObjGridLabel);
   ObjectDelete(0, ObjLayerEdit);
   ObjectDelete(0, ObjLayerLabel);
   ObjectDelete(0, ObjWatermark);
   ObjectDelete(0, ObjTPPartialEdit);
   ObjectDelete(0, ObjTPPartialLabel);
   ObjectDelete(0, ObjBEPEdit);
   ObjectDelete(0, ObjBEPLabel);
   DeletePlanLines(); 
   DeleteMCLine();  // Delete MC detection line
   DeleteZeroBalanceLine();  // Delete Zero Balance line
   DeletePositionStatsPanel();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| Timer Function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
   InvalidateArmedPlanAtSL();
   ProcessPlanPendingInvalidation();
   UpdateBrokerTimeLabel();
   UpdateVirtualPlanWatch();
   ChartRedraw();
  }

//+------------------------------------------------------------------+
//| OnTick Function                                                  |
//+------------------------------------------------------------------+
void OnTick()
  {
   ProcessPlanPendingInvalidation();
   ProcessVirtualPlan();
   // Update position stats panel
   UpdatePositionStatsPanel();
   
   // Update MC detection line (notification style)
   UpdateMCLine();
   
   // Update Zero Balance line (moves with equity)
   UpdateZeroBalanceLine();
   

   // Kirim push notif yang masih antri (rate-limit MT5: max 2 notif/detik)
   ProcessPushNotifQueue();

   // Jaring pengaman: kalau relayout sempat ditunda karena drag, jalankan di
   // sini. Murah — langsung keluar bila ukuran chart tidak berubah.
   RelayoutUI();

   BringUIToFront();

  }

//+------------------------------------------------------------------+
//| Push Notification Queue (batasi laju kirim ke MT5 Mobile)        |
//+------------------------------------------------------------------+
string PushNotifQueue[];        // Antrian pesan push notif
uint   LastPushNotifTick = 0;   // Waktu kirim terakhir (ms, GetTickCount)

void QueuePushNotification(string msg)
  {
   int n = ArraySize(PushNotifQueue);
   ArrayResize(PushNotifQueue, n + 1);
   PushNotifQueue[n] = msg;
   ProcessPushNotifQueue(); // coba kirim langsung
  }

void RemoveFirstPushNotif()
  {
   int n = ArraySize(PushNotifQueue);
   for(int i = 1; i < n; i++)
      PushNotifQueue[i - 1] = PushNotifQueue[i];
   ArrayResize(PushNotifQueue, n - 1);
  }

void ProcessPushNotifQueue()
  {
   if(ArraySize(PushNotifQueue) == 0)
      return;

   // Jaga jarak antar kirim ~700ms (batas server: 2 notif/detik, 10/menit)
   uint now = GetTickCount();
   if(LastPushNotifTick != 0 && (now - LastPushNotifTick) < 700)
      return;

   ResetLastError();
   string msg = PushNotifQueue[0];
   if(SendNotification(msg))
     {
      Print("Push notif terkirim: ", msg);
      RemoveFirstPushNotif();
     }
   else
     {
      int err = GetLastError();
      Print("Gagal kirim push notif (err ", err, "): ", msg);
      // Jika kena rate-limit, biarkan di antrian untuk dicoba lagi.
      // Error lain (MetaQuotes ID belum diset, dll) -> buang agar antrian tidak macet
      if(err != ERR_NOTIFICATION_TOO_FREQUENT)
         RemoveFirstPushNotif();
     }
   LastPushNotifTick = now;
  }

//+------------------------------------------------------------------+
//| Deteksi Pending Order tereksekusi -> Push Notif ke MT5 Mobile    |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
  {
   // Pengamanan PLAN tetap berjalan walaupun push notification dimatikan.
   if(trans.type == TRADE_TRANSACTION_DEAL_ADD)
      InvalidatePlanFromStopLossDeal(trans.deal);
   if(!InpPushNotifPending)
      return;

   // Hanya proses saat deal baru tercatat (order tereksekusi)
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD)
      return;

   if(!HistoryDealSelect(trans.deal))
      return;

   // Hanya deal pembukaan posisi (entry), bukan close/SL/TP
   if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(trans.deal, DEAL_ENTRY) != DEAL_ENTRY_IN)
      return;

   // Filter symbol dan Magic Number milik EA ini
   string dealSymbol = HistoryDealGetString(trans.deal, DEAL_SYMBOL);
   if(dealSymbol != _Symbol)
      return;
   if(HistoryDealGetInteger(trans.deal, DEAL_MAGIC) != InpMagicNumber)
      return;

   // Ambil order asal deal, pastikan tipenya pending order
   ulong orderTicket = (ulong)HistoryDealGetInteger(trans.deal, DEAL_ORDER);
   if(orderTicket == 0 || !HistoryOrderSelect(orderTicket))
      return;

   ENUM_ORDER_TYPE orderType = (ENUM_ORDER_TYPE)HistoryOrderGetInteger(orderTicket, ORDER_TYPE);
   string typeStr = "";
   switch(orderType)
     {
      case ORDER_TYPE_BUY_LIMIT:       typeStr = "BUY LIMIT";       break;
      case ORDER_TYPE_SELL_LIMIT:      typeStr = "SELL LIMIT";      break;
      case ORDER_TYPE_BUY_STOP:        typeStr = "BUY STOP";        break;
      case ORDER_TYPE_SELL_STOP:       typeStr = "SELL STOP";       break;
      case ORDER_TYPE_BUY_STOP_LIMIT:  typeStr = "BUY STOP LIMIT";  break;
      case ORDER_TYPE_SELL_STOP_LIMIT: typeStr = "SELL STOP LIMIT"; break;
      default: return; // Market order (bukan pending) -> abaikan
     }

   double dealVolume = HistoryDealGetDouble(trans.deal, DEAL_VOLUME);
   double dealPrice  = HistoryDealGetDouble(trans.deal, DEAL_PRICE);

   string msg = StringFormat("Entry Ajaib: Pending %s %s %.2f lot tereksekusi @ %s (#%I64u)",
                             typeStr, dealSymbol, dealVolume,
                             DoubleToString(dealPrice, _Digits), orderTicket);
   QueuePushNotification(msg);
  }

//+------------------------------------------------------------------+
//| ChartEvent & UI Functions                                        |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   // Garis anak mengikuti garis induk secara real-time selama masih ditarik.
   if(id == CHARTEVENT_MOUSE_MOVE)
     {
      if(SyncDraggableLines())
        {
         LastDragTick = GetTickCount();   // ada garis yang benar-benar bergerak
         ChartRedraw();
        }
      return;
     }

   if(id == CHARTEVENT_CHART_CHANGE)
     {
      PrepareChartForUI();
      SyncDraggableLines();  // chart change juga terpicu selama drag berlangsung
      RelayoutUI();          // hanya bekerja bila ukuran chart benar-benar berubah
      BringUIToFront();
      ChartRedraw();
      return;
     }

   if(id == CHARTEVENT_OBJECT_CLICK)
     {
      if(sparam == "BtnBuy") { PlaySound("ok.wav"); OpenOrderManual(ORDER_TYPE_BUY); }
      else if(sparam == "BtnSell") { PlaySound("ok.wav"); OpenOrderManual(ORDER_TYPE_SELL); }
      else if(sparam == "BtnPlanBuy") { PlaySound("tick.wav"); TogglePlan("BUY"); }
      else if(sparam == "BtnPlanSell") { PlaySound("tick.wav"); TogglePlan("SELL"); }
      else if(sparam == ObjPlanExecuteBtn) {
         PlaySound("ok.wav");
         ToggleVirtualPlan();
      }
      else if(sparam == ObjPlanModeBtn) { PlaySound("tick.wav"); TogglePlanEntryMode(); }
      else if(sparam == "BtnCloseAll") { PlaySound("alert.wav"); CloseAllPositions(); }

      else if(sparam == ObjLotPlus) { PlaySound("tick.wav"); AdjustLot(LotStep); }
      else if(sparam == ObjLotMinus) { PlaySound("tick.wav"); AdjustLot(-LotStep); }
      // Grid +/- buttons
      else if(sparam == ObjGridPlus) { PlaySound("tick.wav"); AdjustGrid(GridStep); }
      else if(sparam == ObjGridMinus) { PlaySound("tick.wav"); AdjustGrid(-GridStep); }
      // Layer +/- buttons
      else if(sparam == ObjLayerPlus) { PlaySound("tick.wav"); AdjustLayer(LayerStep); }
      else if(sparam == ObjLayerMinus) { PlaySound("tick.wav"); AdjustLayer(-LayerStep); }
      // TP Partial +/- buttons
      else if(sparam == ObjTPPartialPlus) { PlaySound("tick.wav"); AdjustTPPartialPercent(TPPartialStep); }
      else if(sparam == ObjTPPartialMinus) { PlaySound("tick.wav"); AdjustTPPartialPercent(-TPPartialStep); }
      // BEP +/- buttons
      else if(sparam == ObjBEPPlus) { PlaySound("tick.wav"); AdjustBEPProfitPoints(BEPStep); }
      else if(sparam == ObjBEPMinus) { PlaySound("tick.wav"); AdjustBEPProfitPoints(-BEPStep); }
      // Toggle buttons
      else if(sparam == ObjTPPartialBtn) { PlaySound("ok.wav"); ExecuteTPPartial(); }
      else if(sparam == ObjBEPBtn) { PlaySound("ok.wav"); ExecuteBEP(); }
      else if(sparam == ObjUIPanelToggle) { PlaySound("tick.wav"); ToggleUIButtonPanel(); }
      
      if(StringFind(sparam, "Btn") >= 0) {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ChartRedraw();
      }
     }
     
   // Handle Edit box input untuk lot
   if(id == CHARTEVENT_OBJECT_ENDEDIT)
     {
      if(sparam == ObjLotEdit)
        {
         string inputText = ObjectGetString(0, ObjLotEdit, OBJPROP_TEXT);
         double newLot = StringToDouble(inputText);
         if(newLot >= MinLot && newLot <= MaxLot)
           {
            CurrentLot = NormalizeDouble(newLot, 2);
           }
         else
           {
            Alert("Lot harus antara ", DoubleToString(MinLot, 2), " - ", DoubleToString(MaxLot, 2));
           }
         UpdateLotDisplay();
         UpdatePlanLabels();
        }
      // Handle Grid edit input
      else if(sparam == ObjGridEdit)
        {
         string inputText = ObjectGetString(0, ObjGridEdit, OBJPROP_TEXT);
         int newGrid = (int)StringToInteger(inputText);
         if(newGrid >= MinGrid && newGrid <= MaxGrid)
           {
            CurrentGrid = newGrid;
           }
         else
           {
            Alert("Grid harus antara ", IntegerToString(MinGrid), " - ", IntegerToString(MaxGrid), " points");
           }
         UpdateGridDisplay();
         UpdatePlanLabels();
        }


      // Handle Layer edit input
      else if(sparam == ObjLayerEdit)
        {
         string inputText = ObjectGetString(0, ObjLayerEdit, OBJPROP_TEXT);
         int newLayer = (int)StringToInteger(inputText);
         if(newLayer >= MinLayer && newLayer <= MaxLayer)
           {
            CurrentLayer = newLayer;
           }
         else
           {
            Alert("Layer harus antara ", IntegerToString(MinLayer), " - ", IntegerToString(MaxLayer));
           }
         UpdateLayerDisplay();
         UpdatePlanLabels();
        }
      // Handle TP Partial percent edit input
      else if(sparam == ObjTPPartialEdit)
        {
         string inputText = ObjectGetString(0, ObjTPPartialEdit, OBJPROP_TEXT);
         int newPercent = (int)StringToInteger(inputText);
         if(newPercent >= MinTPPartialPercent && newPercent <= MaxTPPartialPercent)
           {
            CurrentTPPartialPercent = newPercent;
           }
         else
           {
            Alert("TP Partial harus antara ", IntegerToString(MinTPPartialPercent), " - ", IntegerToString(MaxTPPartialPercent), " persen");
           }
         UpdateTPPartialDisplay();
        }
      // Handle BEP profit points edit input
      else if(sparam == ObjBEPEdit)
        {
         string inputText = ObjectGetString(0, ObjBEPEdit, OBJPROP_TEXT);
         int newBEP = (int)StringToInteger(inputText);
         if(newBEP >= MinBEPProfitPoints && newBEP <= MaxBEPProfitPoints)
           {
            CurrentBEPProfitPoints = newBEP;
           }
         else
           {
            Alert("BEP harus antara ", IntegerToString(MinBEPProfitPoints), " - ", IntegerToString(MaxBEPProfitPoints), " points");
           }
         UpdateBEPDisplay();
        }

     }
     
   // Drag selesai (tombol mouse dilepas). Sebagian besar pergerakan sudah
   // ditangani SyncDraggableLines() lewat MOUSE_MOVE; ini penutupnya supaya
   // posisi akhir pasti akurat walau event mouse terakhir sempat terlewat.
   if(id == CHARTEVENT_OBJECT_DRAG)
     {
      LastDragTick = GetTickCount();

      if(sparam == ObjPlanEntry || sparam == ObjPlanSL || sparam == ObjPlanTP)
      {
         // Pastikan posisi final ikut tersinkron bila event MOUSE_MOVE terakhir
         // tidak sempat diterima sebelum tombol mouse dilepas.
         SyncDraggableLines();
         ChartRedraw();
      }

     }
  }

void CreateUI()
{
   // Baris bawah: CLOSE ALL dan SHOW ON/OFF.
   int showCol = 1;
   int showRow = 0;
   CreateToggleButton(ObjUIPanelToggle,
                      UIButtonsVisible ? "SHOW ON" : "SHOW OFF",
                      showCol, UIButtonsVisible ? clrDodgerBlue : clrGray,
                      showRow);
   ObjectSetString(0, ObjUIPanelToggle, OBJPROP_TEXT,
                   UIButtonsVisible ? "SHOW ON" : "SHOW OFF");
   ObjectSetInteger(0, ObjUIPanelToggle, OBJPROP_BGCOLOR,
                    UIButtonsVisible ? clrDodgerBlue : clrGray);
   ObjectSetString(0, ObjUIPanelToggle, OBJPROP_TOOLTIP,
                   UIButtonsVisible ? "Sembunyikan panel tombol trading"
                                    : "Tampilkan panel tombol trading");

   if(!UIButtonsVisible)
      return;

   // TOMBOL AKSI DI KIRI
   CreateButton("BtnBuy", "BUY NOW", 0, 3, clrForestGreen); 
   CreateButton("BtnSell", "SELL NOW", 1, 3, clrFireBrick);
   // PLAN BUY/SELL tepat di bawah BUY NOW/SELL NOW.
   CreateButton("BtnPlanBuy", "PLAN BUY", 0, 2, clrDarkGreen);
   CreateButton("BtnPlanSell", "PLAN SELL", 1, 2, clrDarkRed);
   
   CreateButton("BtnCloseAll", "CLOSE ALL", 0, 0, clrRed, 80);
   
   CreateToggleButton(ObjBEPBtn, "BEP", 0, clrDarkOrange, 1);
   CreateToggleButton(ObjTPPartialBtn, "TP½", 1, clrTeal, 1);
   
   // Semua form di kolom kanan: LOT, GRID, LAYER, TP partial, BEP.
   CreateLotControlPanel();
   CreateGridControlPanel();
   CreateLayerControlPanel();
   CreateTPPartialControlPanel();
   CreateBEPControlPanel();
   
   BringUIToFront();
}

//+------------------------------------------------------------------+
//| Create Watermark Label                                            |
//+------------------------------------------------------------------+
void CreateWatermark()
{
   // Nama EA mengisi ruang kiri pada baris LOT (row 4).
   int watermarkY = startY + (4 * gapY) - (buttonHeight / 2);
   string watermarkText = "EntryAjaib HW v" + EA_VERSION;
   int watermarkFont = UIFont(12);
   int availableWidth = (2 * colPitch) - colGap;
   while(watermarkFont > 7 && UITextWidth(watermarkText, watermarkFont, "Arial Bold") > availableWidth)
      watermarkFont--;
   
   if(ObjectFind(0, ObjWatermark) < 0) {
      ObjectCreate(0, ObjWatermark, OBJ_LABEL, 0, 0, 0);
   }
   
   ObjectSetInteger(0, ObjWatermark, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_ANCHOR, ANCHOR_LEFT);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_XDISTANCE, startX);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_YDISTANCE, watermarkY);
   ObjectSetString(0, ObjWatermark, OBJPROP_TEXT, watermarkText);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_FONTSIZE, watermarkFont);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_COLOR, clrYellow);
   ObjectSetString(0, ObjWatermark, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, ObjWatermark, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, ObjWatermark, OBJPROP_HIDDEN, true);
}

void CreateButton(string name, string text, int col, int row, color bgColor, int widthOverride=0)
{
   //--- widthOverride diperlakukan sebagai lebar minimum; lebar akhir selalu
   //--- minimal selebar kolom supaya teks tidak terpotong di layar HiDPI.
   int w = buttonWidth;
   if(widthOverride > 0)
      w = (int)MathMax(buttonWidth, UIPix(widthOverride));

   if(ObjectFind(0, name) < 0) {
      ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, TextColor);
      ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bgColor);
   }
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, startX + (col * colPitch));
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, startY + (row * gapY));
   ObjectSetInteger(0, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, UIFont(7));
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 1);
}

//+------------------------------------------------------------------+
//| Layout generik control panel:   LABEL  [-]  [edit]  [+]           |
//| Dipakai oleh LOT/GRID/LYR/TP1-2/BEP. Posisi & ukuran  |
//| selalu di-set ulang supaya panel ikut menyesuaikan saat resize.   |
//+------------------------------------------------------------------+
void LayoutSmallButton(const string name, const string text, const int x, const int y)
{
   if(ObjectFind(0, name) < 0) {
      ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clrWhite);
      ObjectSetInteger(0, name, OBJPROP_BGCOLOR, clrDarkSlateGray);
   }
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, ctlSmallW);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, UIFont(12));
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 1);
}

void LayoutValueControl(const string labelName, const string minusName,
                        const string editName,  const string plusName,
                        const int col, const int row,
                        const string labelText, const color labelColor,
                        const string valueText, const color valueColor,
                        const int valueFontBase)
{
   int panelX = startX + (col * colPitch);
   int panelY = startY + (row * gapY);

   int xMinus = panelX + ctlLabelW;
   int xEdit  = xMinus + ctlSmallW + UIPix(2);
   int xPlus  = xEdit  + ctlEditW  + UIPix(2);

   //--- Label (dibuat rata tengah terhadap tinggi baris)
   int yLabel = panelY - ((buttonHeight - ctlLabelH) / 2);
   if(yLabel < 0)
      yLabel = panelY;

   if(ObjectFind(0, labelName) < 0) {
      ObjectCreate(0, labelName, OBJ_LABEL, 0, 0, 0);
      ObjectSetString(0, labelName, OBJPROP_TEXT, labelText);
      ObjectSetString(0, labelName, OBJPROP_FONT, "Arial Bold");
      ObjectSetInteger(0, labelName, OBJPROP_COLOR, labelColor);
   }
   ObjectSetInteger(0, labelName, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, labelName, OBJPROP_XDISTANCE, panelX);
   ObjectSetInteger(0, labelName, OBJPROP_YDISTANCE, yLabel);
   ObjectSetInteger(0, labelName, OBJPROP_FONTSIZE, UIFont(9));

   LayoutSmallButton(minusName, "-", xMinus, panelY);
   LayoutSmallButton(plusName,  "+", xPlus,  panelY);

   //--- Edit box (teks hanya di-set saat dibuat; nilainya diurus Update*Display)
   if(ObjectFind(0, editName) < 0) {
      ObjectCreate(0, editName, OBJ_EDIT, 0, 0, 0);
      ObjectSetString(0, editName, OBJPROP_TEXT, valueText);
      ObjectSetInteger(0, editName, OBJPROP_COLOR, valueColor);
      ObjectSetInteger(0, editName, OBJPROP_BGCOLOR, clrBlack);
      ObjectSetInteger(0, editName, OBJPROP_BORDER_COLOR, clrGray);
      ObjectSetInteger(0, editName, OBJPROP_ALIGN, ALIGN_CENTER);
      ObjectSetInteger(0, editName, OBJPROP_READONLY, false);
   }
   ObjectSetInteger(0, editName, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, editName, OBJPROP_XDISTANCE, xEdit);
   ObjectSetInteger(0, editName, OBJPROP_YDISTANCE, panelY);
   ObjectSetInteger(0, editName, OBJPROP_XSIZE, ctlEditW);
   ObjectSetInteger(0, editName, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, editName, OBJPROP_FONTSIZE, UIFont(valueFontBase));
   ObjectSetInteger(0, editName, OBJPROP_ZORDER, 1);
}

//+------------------------------------------------------------------+
//| Lot Control Panel Functions                                       |
//+------------------------------------------------------------------+
void CreateLotControlPanel()
{
   LayoutValueControl(ObjLotLabel, ObjLotMinus, ObjLotEdit, ObjLotPlus,
                      2, 4, "LOT:", clrYellow,
                      DoubleToString(CurrentLot, 2), clrLime, 11);
}

void AdjustLot(double step)
{
   double newLot = CurrentLot + step;
   if(newLot >= MinLot && newLot <= MaxLot)
     {
      CurrentLot = NormalizeDouble(newLot, 2);
      UpdateLotDisplay();
      UpdatePlanLabels();
     }
}

void UpdateLotDisplay()
{
   if(ObjectFind(0, ObjLotEdit) >= 0)
     {
      ObjectSetString(0, ObjLotEdit, OBJPROP_TEXT, DoubleToString(CurrentLot, 2));
      ChartRedraw();
     }
}

//+------------------------------------------------------------------+
//| Grid Control Panel Functions                                       |
//+------------------------------------------------------------------+
void CreateGridControlPanel()
{
   LayoutValueControl(ObjGridLabel, ObjGridMinus, ObjGridEdit, ObjGridPlus,
                      2, 3, "GRID:", clrAqua,
                      IntegerToString(CurrentGrid), clrCyan, 10);
}

void AdjustGrid(int step)
{
   int newGrid = CurrentGrid + step;
   if(newGrid >= MinGrid && newGrid <= MaxGrid)
     {
      CurrentGrid = newGrid;
      UpdateGridDisplay();
      UpdatePlanLabels();
     }
}

void UpdateGridDisplay()
{
   if(ObjectFind(0, ObjGridEdit) >= 0)
     {
      ObjectSetString(0, ObjGridEdit, OBJPROP_TEXT, IntegerToString(CurrentGrid));
      ChartRedraw();
     }
}


//+------------------------------------------------------------------+
//| Layer Control Panel Functions                                      |
//+------------------------------------------------------------------+
void CreateLayerControlPanel()
{
   LayoutValueControl(ObjLayerLabel, ObjLayerMinus, ObjLayerEdit, ObjLayerPlus,
                      2, 2, "LYR:", clrMagenta,
                      IntegerToString(CurrentLayer), clrViolet, 10);
}

void AdjustLayer(int step)
{
   int newLayer = CurrentLayer + step;
   if(newLayer >= MinLayer && newLayer <= MaxLayer)
     {
      CurrentLayer = newLayer;
      UpdateLayerDisplay();
      UpdatePlanLabels();
     }
}

void UpdateLayerDisplay()
{
   if(ObjectFind(0, ObjLayerEdit) >= 0)
     {
      ObjectSetString(0, ObjLayerEdit, OBJPROP_TEXT, IntegerToString(CurrentLayer));
      ChartRedraw();
     }
}

//+------------------------------------------------------------------+
//| Create Toggle Button (for retained panel actions)         |
//+------------------------------------------------------------------+
void CreateToggleButton(string name, string text, int col, color bgColor, int row=0)
{
   //--- Teks & warna toggle diubah oleh fungsi toggle masing-masing,
   //--- jadi hanya di-set saat objek pertama kali dibuat.
   if(ObjectFind(0, name) < 0) {
      ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clrWhite);
      ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bgColor);
   }
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_LOWER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, startX + (col * colPitch));
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, startY + (row * gapY));
   ObjectSetInteger(0, name, OBJPROP_XSIZE, buttonWidth);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, UIFont(8));
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 1);
}

void ToggleUIButtonPanel()
{
   UIButtonsVisible = !UIButtonsVisible;

   // ApplyUILayout menata ulang posisi toggle dan menerapkan visibilitas ke
   // seluruh tombol/control tanpa menghapus state yang sedang aktif.
   ApplyUILayout();
   Print("Panel tombol trading: ", UIButtonsVisible ? "ON" : "OFF");
   ChartRedraw();
}


//--- POSITION_TIME dan TimeCurrent() sama-sama memakai waktu server broker.
datetime TradingDayStart()
{
   MqlDateTime parts;
   if(!TimeToStruct(TimeCurrent(), parts))
      return(0);

   parts.hour = 0;
   parts.min = 0;
   parts.sec = 0;
   return(StructToTime(parts));
}

//--- Dipanggil setelah PositionGetTicket()/PositionSelectByTicket() berhasil.
bool PositionPassesTodayFilter(const datetime dayStart)
{
   return(!TodayOnlyEnabled || dayStart <= 0 ||
          (datetime)PositionGetInteger(POSITION_TIME) >= dayStart);
}


//+------------------------------------------------------------------+
//| TP Partial Control Panel Functions                                |
//+------------------------------------------------------------------+
void CreateTPPartialControlPanel()
{
   LayoutValueControl(ObjTPPartialLabel, ObjTPPartialMinus, ObjTPPartialEdit, ObjTPPartialPlus,
                      2, 1, "TP1/2:", clrTeal,
                      IntegerToString(CurrentTPPartialPercent), clrAqua, 10);
}

void AdjustTPPartialPercent(int step)
{
   int newPercent = CurrentTPPartialPercent + step;
   if(newPercent >= MinTPPartialPercent && newPercent <= MaxTPPartialPercent)
     {
      CurrentTPPartialPercent = newPercent;
      UpdateTPPartialDisplay();
     }
}

void UpdateTPPartialDisplay()
{
   if(ObjectFind(0, ObjTPPartialEdit) >= 0)
     {
      ObjectSetString(0, ObjTPPartialEdit, OBJPROP_TEXT, IntegerToString(CurrentTPPartialPercent));
      ChartRedraw();
     }
}

//+------------------------------------------------------------------+
//| BEP Control Panel Functions                                       |
//+------------------------------------------------------------------+
void CreateBEPControlPanel()
{
   LayoutValueControl(ObjBEPLabel, ObjBEPMinus, ObjBEPEdit, ObjBEPPlus,
                      2, 0, "BEP:", clrDarkOrange,
                      IntegerToString(CurrentBEPProfitPoints), clrOrange, 10);
}

void AdjustBEPProfitPoints(int step)
{
   int newBEP = CurrentBEPProfitPoints + step;
   if(newBEP >= MinBEPProfitPoints && newBEP <= MaxBEPProfitPoints)
     {
      CurrentBEPProfitPoints = newBEP;
      UpdateBEPDisplay();
     }
}

void UpdateBEPDisplay()
{
   if(ObjectFind(0, ObjBEPEdit) >= 0)
     {
      ObjectSetString(0, ObjBEPEdit, OBJPROP_TEXT, IntegerToString(CurrentBEPProfitPoints));
      ChartRedraw();
     }
}


//+------------------------------------------------------------------+
//| Execute TP Partial - Tombol aksi sekali tekan                      |
//| Close setengah lot untuk semua posisi yang sedang profit           |
//+------------------------------------------------------------------+
void ExecuteTPPartial()
{
   int partialCount = 0;
   int skipCount = 0;
   int excludedOldCount = 0;
   datetime dayStart = TodayOnlyEnabled ? TradingDayStart() : 0;
   
   double minLotSize = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double lotStepSize = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i);
      if(ticket <= 0) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      
      // Hanya manage posisi dari EA ini
      long posMagic = PositionGetInteger(POSITION_MAGIC);
      if(posMagic != InpMagicNumber) continue;

      if(TodayOnlyEnabled && (datetime)PositionGetInteger(POSITION_TIME) < dayStart)
        {
         excludedOldCount++;
         continue;
        }
      
      double profit = PositionGetDouble(POSITION_PROFIT);
      double swap = PositionGetDouble(POSITION_SWAP);
      double totalProfit = profit + swap;
      
      // Hanya partial posisi yang sedang profit
      if(totalProfit <= 0)
        {
         skipCount++;
         continue;
        }
      
      double volume = PositionGetDouble(POSITION_VOLUME);

      
      // Jika volume sudah terlalu kecil untuk di-partial, skip
      if(volume <= minLotSize)
        {
         skipCount++;
         continue;
        }
      
      // Hitung volume partial berdasarkan persen TP1/2 di panel.
      double halfVolume = NormalizeDouble(volume * CurrentTPPartialPercent / 100.0, 2);
      // Round down ke kelipatan lot step terdekat
      halfVolume = MathFloor(halfVolume / lotStepSize) * lotStepSize;
      if(halfVolume < minLotSize) halfVolume = minLotSize;
      
      // Pastikan sisa lot juga >= minLot
      double remainingVolume = NormalizeDouble(volume - halfVolume, 2);
      if(remainingVolume < minLotSize)
        {
         skipCount++;
         continue;
        }
      
      // Partial close setengah lot
      if(trade.PositionClosePartial(ticket, halfVolume))
        {
         partialCount++;
         PrintFormat("TPPartial: Closed %.2f of %.2f lots (%d%%, ticket #%d), remaining: %.2f lots, profit: $%.2f",
                     halfVolume, volume, CurrentTPPartialPercent, ticket, remainingVolume, totalProfit);
        }
      else
        {
         Print("TPPartial: Gagal partial close ticket #", ticket,
               " Error: ", trade.ResultRetcode(), " - ", trade.ResultRetcodeDescription());
        }
      Sleep(50);  // Beri jeda antar partial close
     }
   
   if(partialCount > 0)
      PrintFormat("TPPartial: %d posisi berhasil di-partial close, %d posisi lama diabaikan",
                  partialCount, excludedOldCount);
   else if(skipCount > 0)
      Print("TPPartial: Tidak ada posisi profit yang bisa di-partial (lot terlalu kecil atau belum profit)");
   else if(excludedOldCount > 0)
      PrintFormat("TPPartial: Tidak ada posisi hari ini (%d posisi lama diabaikan)", excludedOldCount);
   else
      Print("TPPartial: Tidak ada posisi aktif");
}

//+------------------------------------------------------------------+
//| Execute BEP - pindahkan SL ke entry plus profit buffer kecil      |
//+------------------------------------------------------------------+
void ExecuteBEP()
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   int bufferPoints = CurrentBEPProfitPoints;
   if(bufferPoints < 0) bufferPoints = 0;
   double buffer = bufferPoints * point;
   
   long stopsLevel = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL);
   long freezeLevel = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_FREEZE_LEVEL);
   long minLevelPoints = (stopsLevel > freezeLevel) ? stopsLevel : freezeLevel;
   double minDistance = minLevelPoints * point;
   
   int modifiedCount = 0;
   int skipCount = 0;
   int failedCount = 0;
   int excludedOldCount = 0;
   datetime dayStart = TodayOnlyEnabled ? TradingDayStart() : 0;
   
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong ticket = PositionGetTicket(i);
      if(ticket <= 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      
      if(InpCloseOwnOnly)
        {
         long posMagic = PositionGetInteger(POSITION_MAGIC);
         if(posMagic != InpMagicNumber) continue;
        }

      if(TodayOnlyEnabled && (datetime)PositionGetInteger(POSITION_TIME) < dayStart)
        {
         excludedOldCount++;
         continue;
        }
      
      long posType = PositionGetInteger(POSITION_TYPE);
      if(posType != POSITION_TYPE_BUY && posType != POSITION_TYPE_SELL) continue;
      
      bool isBuy = (posType == POSITION_TYPE_BUY);
      string typeText = isBuy ? "BUY" : "SELL";
      double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
      double currentSL = PositionGetDouble(POSITION_SL);
      double tp = PositionGetDouble(POSITION_TP);
      double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
      double newSL = 0;
      
      if(isBuy)
        {
         newSL = NormalizeDouble(openPrice + buffer, _Digits);
         
         if(newSL >= bid - minDistance)
           {
            skipCount++;
            PrintFormat("BEP: Skip BUY ticket #%I64u - harga belum cukup jauh untuk SL %.5f (Bid %.5f)",
                        ticket, newSL, bid);
            continue;
           }
         
         if(currentSL > 0 && currentSL >= newSL - point)
           {
            skipCount++;
            continue;
           }
        }
      else
        {
         newSL = NormalizeDouble(openPrice - buffer, _Digits);
         
         if(newSL <= ask + minDistance)
           {
            skipCount++;
            PrintFormat("BEP: Skip SELL ticket #%I64u - harga belum cukup jauh untuk SL %.5f (Ask %.5f)",
                        ticket, newSL, ask);
            continue;
           }
         
         if(currentSL > 0 && currentSL <= newSL + point)
           {
            skipCount++;
            continue;
           }
        }
      
      if(trade.PositionModify(ticket, newSL, tp))
        {
         modifiedCount++;
         PrintFormat("BEP: %s ticket #%I64u SL moved to %.5f (entry %.5f + buffer %d pts)",
                     typeText, ticket, newSL, openPrice, bufferPoints);
        }
      else
        {
         failedCount++;
         Print("BEP: Gagal modify ticket #", ticket,
               " Error: ", trade.ResultRetcode(), " - ", trade.ResultRetcodeDescription());
        }
      
      Sleep(50);
     }
   
   if(modifiedCount == 0 && skipCount == 0 && failedCount == 0)
     {
      if(excludedOldCount > 0)
         PrintFormat("BEP: Tidak ada posisi hari ini (%d posisi lama diabaikan)", excludedOldCount);
      else
         Print("BEP: Tidak ada posisi aktif");
     }
   else
      PrintFormat("BEP: %d posisi modified, %d skipped, %d failed, %d posisi lama diabaikan. Buffer: %d pts",
                  modifiedCount, skipCount, failedCount, excludedOldCount, bufferPoints);
}


//+------------------------------------------------------------------+
//| Plan Info Panel Functions                                         |
//+------------------------------------------------------------------+
void CreatePlanInfoPanel()
{
   int panelX = UIPix(10);
   int panelY = startY + buttonHeight + UIPix(8); // Ruang tombol di bawah PLAN INFO
   int lineH  = UIInfoLineHeight();

   // Lebar panel mengikuti baris terpanjang supaya angka tidak terpotong
   int panelW = UIInfoPanelWidth("▲ Profit: +$999999.99 (+999.9%)", 10, "Arial Bold");
   panelW = (int)MathMax(panelW, UIInfoPanelWidth("Type: SELL | RETEST | Lot: 99.99 x 99", 9, "Consolas"));

   // 10 baris teks termasuk status konfirmasi.
   // Di skala 1x rumus ini menghasilkan 200 px, sama persis dengan layout lama.
   panelW = (int)MathMax(panelW, UIInfoPanelWidth("10s | BREAK: tunggu candle close", 8, "Consolas"));
   panelW = (int)MathMax(panelW, (2 * buttonWidth) + (2 * UIPix(10)) + colGap);
   int panelH = UIPix(10) + (10 * lineH) + (2 * UIPix(5)) + UIPix(18);

   int yOffset = panelY + panelH - UIPix(10);  // Mulai dari atas panel (koordinat dari bawah)

   if(ObjectFind(0, ObjPlanInfoBG) < 0) {
      ObjectCreate(0, ObjPlanInfoBG, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_BGCOLOR, C'15,25,35');
      ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_BORDER_COLOR, clrDarkSlateGray);
   }
   ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_CORNER, CORNER_RIGHT_LOWER);
   ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_XDISTANCE, panelX);
   ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_YDISTANCE, panelY);
   ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_XSIZE, panelW);
   ObjectSetInteger(0, ObjPlanInfoBG, OBJPROP_YSIZE, panelH);
   SetUIObjectOnTop(ObjPlanInfoBG, UI_BG_ZORDER);

   // Title
   CreateInfoLabel(ObjPlanInfoTitle, panelX, yOffset, "═══ PLAN INFO ═══", clrGold, 10, "Arial Bold");
   yOffset -= lineH + UIPix(5);

   // Type
   CreateInfoLabel(ObjPlanInfoType, panelX, yOffset, "Type: ---", clrWhite, 9, "Consolas");
   yOffset -= lineH;

   // Entry
   CreateInfoLabel(ObjPlanInfoEntry, panelX, yOffset, "Entry: ---", clrWhite, 9, "Consolas");
   yOffset -= lineH;

   // SL
   CreateInfoLabel(ObjPlanInfoSL, panelX, yOffset, "SL: ---", clrCoral, 9, "Consolas");
   yOffset -= lineH;

   // TP
   CreateInfoLabel(ObjPlanInfoTP, panelX, yOffset, "TP: ---", clrLime, 9, "Consolas");
   yOffset -= lineH + UIPix(5);

   // Risk (Loss)
   CreateInfoLabel(ObjPlanInfoRisk, panelX, yOffset, "Risk: $0.00 (0.0%)", clrOrangeRed, 10, "Arial Bold");
   yOffset -= lineH;

   // Profit
   CreateInfoLabel(ObjPlanInfoProfit, panelX, yOffset, "Profit: $0.00 (0.0%)", clrLimeGreen, 10, "Arial Bold");
   yOffset -= lineH;

   // RR Ratio
   CreateInfoLabel(ObjPlanInfoRR, panelX, yOffset, "R:R = 1:0.00", clrCyan, 10, "Arial Bold");
   yOffset -= lineH;

   // Pips Info
   CreateInfoLabel(ObjPlanInfoPips, panelX, yOffset, "SL: 0 pts | TP: 0 pts", clrSilver, 8, "Arial");
   yOffset -= lineH;

   CreateInfoLabel(ObjPlanInfoStatus, panelX, yOffset, PlanStatus, clrGold, 8, "Consolas");

   // ARM/CANCEL mengaktifkan deteksi saja; mode entry DIRECT/RETEST.
   // Dua tombol sejajar tepat di bawah panel, dengan lebar mengikuti panel.
   int btnWidth = (panelW - (2 * UIPix(10)) - colGap) / 2;
   int xExecute = panelX + panelW - UIPix(10);
   int xMode = xExecute - btnWidth - colGap;
   int actionY = panelY - UIPix(8);

   if(ObjectFind(0, ObjPlanExecuteBtn) < 0) {
      ObjectCreate(0, ObjPlanExecuteBtn, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_COLOR, clrWhite);
   }
   ObjectSetString(0, ObjPlanExecuteBtn, OBJPROP_TEXT, PlanArmed ? "CANCEL PLAN" : "ARM PLAN");
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_BGCOLOR, PlanArmed ? clrDarkOrange : clrPurple);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_CORNER, CORNER_RIGHT_LOWER);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_XDISTANCE, xExecute);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_YDISTANCE, actionY);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_XSIZE, btnWidth);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_FONTSIZE, UIFont(9));
   ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_ZORDER, 2);

   if(ObjectFind(0, ObjPlanModeBtn) < 0) {
      ObjectCreate(0, ObjPlanModeBtn, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_COLOR, clrWhite);
   }
   ObjectSetString(0, ObjPlanModeBtn, OBJPROP_TEXT,
                   CurrentPlanEntryMode == HW_PLAN_DIRECT ? "DIRECT" : "RETEST");
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_BGCOLOR,
                    CurrentPlanEntryMode == HW_PLAN_DIRECT ? clrDodgerBlue : clrTeal);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_CORNER, CORNER_RIGHT_LOWER);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_XDISTANCE, xMode);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_YDISTANCE, actionY);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_XSIZE, btnWidth);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_YSIZE, buttonHeight);
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_FONTSIZE, UIFont(9));
   ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_ZORDER, 2);

   BringUIToFront();
}

//+------------------------------------------------------------------+
//| Metrik bersama panel info (Plan)                |
//+------------------------------------------------------------------+
int UIInfoLineHeight()
{
   return((int)MathMax(UIPix(18), UITextHeight("Ag", UIFont(10), "Arial Bold") + UIPix(4)));
}


//--- Lebar panel = baris terpanjang + padding, minimal 200 (skala)
int UIInfoPanelWidth(const string sampleLine, const int fontBase, const string font)
{
   int w = UITextWidth(sampleLine, UIFont(fontBase), font) + UIPix(20);
   return((int)MathMax(UIPix(200), w));
}

void CreateInfoLabel(string name, int x, int y, string text, color clr, int fontSize, string font)
{
   // Teks & warna hanya ditulis saat objek dibuat. Nilai hidupnya diurus
   // UpdatePlanInfoPanel(), jadi relayout tidak menimpanya dengan "---".
   if(ObjectFind(0, name) < 0) {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   }
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_RIGHT_LOWER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, UIFont(fontSize));
   ObjectSetString(0, name, OBJPROP_FONT, font);
}

void UpdatePlanInfoPanel(string typeStr, double entry, double sl, double tp, 
                          double profit, double loss, double slPips, double tpPips, double rr)
{
   // Buat panel jika belum ada
   if(ObjectFind(0, ObjPlanInfoBG) < 0)
      CreatePlanInfoPanel();
   
   color typeColor = (typeStr == "BUY") ? clrDodgerBlue : clrOrangeRed;
   double displayLoss = loss / CentDivisor;
   double displayProfit = profit / CentDivisor;
   double accountBalance = AccountInfoDouble(ACCOUNT_BALANCE) / CentDivisor;
   double riskPercent = (accountBalance > 0) ? (MathAbs(displayLoss) / accountBalance) * 100.0 : 0;
   double profitPercent = (accountBalance > 0) ? (MathAbs(displayProfit) / accountBalance) * 100.0 : 0;
   
   // Update label mode DIRECT/RETEST dan lot tetap.
   string modeText = CurrentPlanEntryMode == HW_PLAN_DIRECT ? "DIRECT" : "RETEST";
   string lotText = StringFormat("Lot: %.2f x %d", CurrentLot, CurrentLayer);
   ObjectSetString(0, ObjPlanInfoTitle, OBJPROP_TEXT,
                   StringFormat("=== PLAN INFO: %s ===", modeText));
   ObjectSetString(0, ObjPlanInfoType, OBJPROP_TEXT,
                   StringFormat("Type: %s | %s | %s", typeStr, modeText, lotText));
   ObjectSetInteger(0, ObjPlanInfoType, OBJPROP_COLOR, typeColor);
   
   ObjectSetString(0, ObjPlanInfoEntry, OBJPROP_TEXT, StringFormat("Entry: %.5f", entry));
   ObjectSetString(0, ObjPlanInfoSL, OBJPROP_TEXT, StringFormat("SL: %.5f", sl));
   ObjectSetString(0, ObjPlanInfoTP, OBJPROP_TEXT, StringFormat("TP: %.5f", tp));
   
   ObjectSetString(0, ObjPlanInfoRisk, OBJPROP_TEXT, StringFormat("▼ Risk: -$%.2f (-%.1f%%)", MathAbs(displayLoss), riskPercent));
   ObjectSetString(0, ObjPlanInfoProfit, OBJPROP_TEXT, StringFormat("▲ Profit: +$%.2f (+%.1f%%)", MathAbs(displayProfit), profitPercent));
   ObjectSetString(0, ObjPlanInfoRR, OBJPROP_TEXT, StringFormat("R:R = 1 : %.2f", rr));
   ObjectSetString(0, ObjPlanInfoPips, OBJPROP_TEXT, StringFormat("SL: %.0f pts | TP: %.0f pts", slPips, tpPips));
   
   BringUIToFront();
   ChartRedraw();
}

void DeletePlanInfoPanel()
{
   ObjectDelete(0, ObjPlanInfoBG);
   ObjectDelete(0, ObjPlanInfoTitle);
   ObjectDelete(0, ObjPlanInfoType);
   ObjectDelete(0, ObjPlanInfoEntry);
   ObjectDelete(0, ObjPlanInfoSL);
   ObjectDelete(0, ObjPlanInfoTP);
   ObjectDelete(0, ObjPlanInfoRisk);
   ObjectDelete(0, ObjPlanInfoProfit);
   ObjectDelete(0, ObjPlanInfoRR);
   ObjectDelete(0, ObjPlanInfoPips);
   ObjectDelete(0, ObjPlanInfoStatus);
   ObjectDelete(0, ObjPlanExecuteBtn);
   ObjectDelete(0, ObjPlanModeBtn);
   ChartRedraw();
}

// Terapkan nilai SL/TP dari control panel ke plan. Fungsi ini hanya dipanggil
// saat nilai SL atau rasio TP memang diubah lewat edit box / tombol +/-.
// Refresh lain (lot, grid, layer, mode) tidak boleh menimpa hasil drag manual.


void UpdatePlanLabels()
{
   if(ObjectFind(0, ObjPlanEntry) < 0 ||
      ObjectFind(0, ObjPlanSL) < 0 ||
      ObjectFind(0, ObjPlanTP) < 0) {
      DeletePlanInfoPanel();
      return;
   }
   
   double entry = ObjectGetDouble(0, ObjPlanEntry, OBJPROP_PRICE);
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   
   // Tentukan tipe berdasarkan warna garis entry
   long entryColor = ObjectGetInteger(0, ObjPlanEntry, OBJPROP_COLOR);
   string typeStr = (entryColor == clrBlue) ? "BUY" : "SELL";
   ENUM_ORDER_TYPE type = (typeStr == "BUY") ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   
   // Posisi SL/TP dibaca langsung dari garis agar level hasil drag manual
   // tidak ditimpa saat label, lot, grid, layer, atau mode diperbarui.
   double sl = ObjectGetDouble(0, ObjPlanSL, OBJPROP_PRICE);
   double tp = ObjectGetDouble(0, ObjPlanTP, OBJPROP_PRICE);
   
   // Hitung profit dan loss (Akumulasi semua layer)
   double profitVal = 0, lossVal = 0;
   
   // Simulasi setiap layer mengikuti mode aktif: lot tetap
   for(int i = 0; i < CurrentLayer; i++)
   {
      double layerEntry = 0;
      // Hitung entry price untuk layer ini
      if(typeStr == "BUY")
         layerEntry = entry - (i * CurrentGrid * point);
      else
         layerEntry = entry + (i * CurrentGrid * point);
         
      double layerProfit = 0;
      double layerLoss = 0;
      
      double layerLot = CurrentLot;

      // Calculate profit/loss per layer
      if(OrderCalcProfit(type, _Symbol, layerLot, layerEntry, tp, layerProfit))
         profitVal += layerProfit;

      if(OrderCalcProfit(type, _Symbol, layerLot, layerEntry, sl, layerLoss))
         lossVal += layerLoss;
   }
   
   // Hitung pips
   double slPips = MathAbs(entry - sl) / point;
   double tpPips = MathAbs(tp - entry) / point;
   double rrRatio = (lossVal != 0) ? MathAbs(profitVal / lossVal) : 0;
   double displayLossVal = lossVal / CentDivisor;
   double displayProfitVal = profitVal / CentDivisor;
   double accountBalance = AccountInfoDouble(ACCOUNT_BALANCE) / CentDivisor;
   double riskPercent = (accountBalance > 0) ? (MathAbs(displayLossVal) / accountBalance) * 100.0 : 0;
   double profitPercent = (accountBalance > 0) ? (MathAbs(displayProfitVal) / accountBalance) * 100.0 : 0;
   
   // Update text pada garis
   ObjectSetString(0, ObjPlanTP, OBJPROP_TEXT, StringFormat("TP: +$%.2f (+%.1f%%, %.0f pts)", MathAbs(displayProfitVal), profitPercent, tpPips));
   ObjectSetString(0, ObjPlanSL, OBJPROP_TEXT, StringFormat("SL: -$%.2f (-%.1f%%, %.0f pts)", MathAbs(displayLossVal), riskPercent, slPips));
   ObjectSetString(0, ObjPlanEntry, OBJPROP_TEXT, StringFormat("PLAN %s @ %.5f", typeStr, entry));
   
   // Refresh shadow lines (menambah/menghapus sesuai CurrentLayer)
   RefreshPlanShadowLines(entry, typeStr);
   
   // Update Panel Info
   UpdatePlanInfoPanel(typeStr, entry, sl, tp, profitVal, lossVal, slPips, tpPips, rrRatio);
   
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Refresh Shadow Lines - Handle dynamic layer count changes         |
//+------------------------------------------------------------------+
void RefreshPlanShadowLines(double baseEntry, string type)
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   color shadowColor = (type == "BUY") ? clrDodgerBlue : clrOrangeRed;

   // Garis yang sudah ada DIPINDAHKAN, bukan dihapus-lalu-dibuat-ulang.
   // Fungsi ini kini jalan pada setiap gerakan mouse selama drag, dan
   // menghapus/membuat objek terus-menerus membuat MT5 melepas pegangan
   // pada garis yang sedang ditarik (drag putus / garis lompat).
   for(int i = 1; i < CurrentLayer; i++)
   {
      double shadowPrice = 0;

      if(type == "BUY")
         shadowPrice = baseEntry - (i * CurrentGrid * point);
      else
         shadowPrice = baseEntry + (i * CurrentGrid * point);

      shadowPrice = NormalizeDouble(shadowPrice, _Digits);

      string shadowName = ObjPlanShadowPrefix + IntegerToString(i);

      if(ObjectFind(0, shadowName) < 0)
         CreateShadowLine(shadowName, shadowPrice, shadowColor, "");

      ObjectSetDouble(0, shadowName, OBJPROP_PRICE, shadowPrice);
      ObjectSetInteger(0, shadowName, OBJPROP_COLOR, shadowColor);
      double layerLot = CurrentLot;
      ObjectSetString(0, shadowName, OBJPROP_TEXT,
                      StringFormat("Layer %d | %.2f lot @ %.5f", i + 1, layerLot, shadowPrice));
   }

   // Buang sisa garis kalau jumlah layer dikurangi
   for(int i = CurrentLayer; i <= 20; i++)
   {
      string shadowName = ObjPlanShadowPrefix + IntegerToString(i);
      if(ObjectFind(0, shadowName) >= 0)
         ObjectDelete(0, shadowName);
   }
}


void TogglePlan(string type)
{
   bool exists = (ObjectFind(0, ObjPlanEntry) >= 0);
   if(exists) {
      long entryColor = ObjectGetInteger(0, ObjPlanEntry, OBJPROP_COLOR);
      string currentType = (entryColor == clrBlue) ? "BUY" : "SELL";
      DeletePlanLines();
      if(currentType == type) return;
   }
   CreatePlanLines(type);
}


void DeletePlanLines()
{
   PlanArmed = false;
   PlanStatus = "DRAFT - tekan ARM PLAN";
   PlanArmedBar = 0;
   PlanLastClosedBar = 0;
   ObjectDelete(0, ObjPlanEntry);
   ObjectDelete(0, ObjPlanSL);
   ObjectDelete(0, ObjPlanTP);
   lastPlanEntryPrice = 0;
   lastPlanSLPrice = 0;
   lastPlanTPPrice = 0;
   // Hapus semua shadow lines
   DeletePlanShadowLines();
   DeletePlanInfoPanel();
   ChartRedraw();
}

void DeletePlanShadowLines()
{
   // Hapus semua object dengan prefix shadow
   for(int i = 1; i <= 20; i++) // Max 20 layers
   {
      string shadowName = ObjPlanShadowPrefix + IntegerToString(i);
      if(ObjectFind(0, shadowName) >= 0)
         ObjectDelete(0, shadowName);
   }
}

void CreatePlanLines(string type)
{
   // Dapatkan range harga yang terlihat di chart dan gunakan harga tengah
   double chartPriceMin = ChartGetDouble(0, CHART_PRICE_MIN);
   double chartPriceMax = ChartGetDouble(0, CHART_PRICE_MAX);
   double chartMiddlePrice = (chartPriceMin + chartPriceMax) / 2.0;
   
   // Gunakan harga tengah chart sebagai entry point awal
   double price = NormalizeDouble(chartMiddlePrice, _Digits);
   
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   DeletePlanLines();
   double slPrice = (type == "BUY") ? price - (CurrentSL * point) : price + (CurrentSL * point);
   double tpPrice = (type == "BUY") ? price + ((CurrentSL * CurrentTPRatio) * point) : price - ((CurrentSL * CurrentTPRatio) * point);
   color entryColor = (type == "BUY") ? clrBlue : clrRed;
   lastPlanEntryPrice = price;
   lastPlanSLPrice = NormalizeDouble(slPrice, _Digits);
   lastPlanTPPrice = NormalizeDouble(tpPrice, _Digits);
   CreateHLine(ObjPlanEntry, price, entryColor, STYLE_DASH, "PLAN ENTRY");
   CreateHLine(ObjPlanSL, lastPlanSLPrice, clrRed, STYLE_SOLID, "PLAN SL");
   CreateHLine(ObjPlanTP, lastPlanTPPrice, clrGreen, STYLE_SOLID, "PLAN TP");
   
   // Buat shadow lines untuk multi-layer preview
   CreatePlanShadowLines(price, type);
   
   UpdatePlanLabels();
   BringUIToFront();
   ChartRedraw();
}

void CreatePlanShadowLines(double baseEntry, string type)
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   color shadowColor = (type == "BUY") ? clrDodgerBlue : clrOrangeRed;
   
   // Buat shadow line untuk setiap layer (mulai dari layer 2)
   for(int i = 1; i < CurrentLayer; i++)
   {
      double shadowPrice = 0;
      
      if(type == "BUY")
         shadowPrice = baseEntry - (i * CurrentGrid * point); // Buy: layer di bawah
      else
         shadowPrice = baseEntry + (i * CurrentGrid * point); // Sell: layer di atas
      
      shadowPrice = NormalizeDouble(shadowPrice, _Digits);
      
      string shadowName = ObjPlanShadowPrefix + IntegerToString(i);
      string shadowText = StringFormat("Layer %d @ %.5f", i+1, shadowPrice);
      
      CreateShadowLine(shadowName, shadowPrice, shadowColor, shadowText);
   }
}

void CreateShadowLine(string name, double price, color col, string desc)
{
   if(ObjectCreate(0, name, OBJ_HLINE, 0, 0, price)) {
      ObjectSetInteger(0, name, OBJPROP_COLOR, col);
      ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_DOT);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_SELECTED, false); 
      ObjectSetInteger(0, name, OBJPROP_BACK, true); // Di belakang chart
      ObjectSetInteger(0, name, OBJPROP_ZORDER, CHART_LINE_ZORDER);
      ObjectSetString(0, name, OBJPROP_TEXT, desc);
   }
}

void CreateHLine(string name, double price, color col, ENUM_LINE_STYLE style, string desc)
{
   if(ObjectCreate(0, name, OBJ_HLINE, 0, 0, price)) {
      ObjectSetInteger(0, name, OBJPROP_COLOR, col);
      ObjectSetInteger(0, name, OBJPROP_STYLE, style);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, 2);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTED, true); 
      SetChartObjectBehindUI(name);
      ObjectSetString(0, name, OBJPROP_TEXT, desc);
   }
}


void OpenOrderManual(ENUM_ORDER_TYPE type)
{
   // Buy/Sell Now selalu hanya membuka 1 order
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double openPrice = (type == ORDER_TYPE_BUY) ? SymbolInfoDouble(_Symbol, SYMBOL_ASK) : SymbolInfoDouble(_Symbol, SYMBOL_BID);
   
   // Set SL/TP based on InpSLTPEnabled input
   double slPrice = 0;
   double tpPrice = 0;
   if(InpSLTPEnabled)
     {
      slPrice = (type == ORDER_TYPE_BUY) ? openPrice - (CurrentSL * point) : openPrice + (CurrentSL * point);
      tpPrice = (type == ORDER_TYPE_BUY) ? openPrice + ((CurrentSL * CurrentTPRatio) * point) : openPrice - ((CurrentSL * CurrentTPRatio) * point);
     }
   
   string comment = "EntryAjaib HW";
   trade.PositionOpen(_Symbol, type, CurrentLot, openPrice, slPrice, tpPrice, comment);
}


void CloseAllPositions() {
   int maxRetries = 10;    // Maksimum percobaan ulang
   int attempt = 0;
   int totalClosed = 0;
   int excludedOldCount = 0;
   datetime dayStart = TodayOnlyEnabled ? TradingDayStart() : 0;
   
   while(attempt < maxRetries) {
      int closedCount = 0;
      int remainingCount = 0;
      
      for(int i = PositionsTotal() - 1; i >= 0; i--) {
         ulong ticket = PositionGetTicket(i);
         if(ticket <= 0) continue;
         if(PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
         
         // Cek Magic Number jika InpCloseOwnOnly aktif
         if(InpCloseOwnOnly) {
            long posMagic = PositionGetInteger(POSITION_MAGIC);
            if(posMagic != InpMagicNumber) {
               continue;  // Skip posisi bukan milik EA ini
            }
         }
         
         bool shouldClose = true;

         if(shouldClose && !PositionPassesTodayFilter(dayStart)) {
            if(attempt == 0) excludedOldCount++;
            continue;
         }

         if(shouldClose) {
            remainingCount++;
            // Refresh data posisi sebelum close
            if(!PositionSelectByTicket(ticket)) continue;
            
            if(trade.PositionClose(ticket)) {
               closedCount++;
               totalClosed++;
            } else {
               Print("ClosePositions: Gagal close ticket #", ticket, 
                     " Error: ", trade.ResultRetcode(), " - ", trade.ResultRetcodeDescription());
            }
            Sleep(50);  // Beri jeda agar server sempat proses
         }
      }
      
      // Jika tidak ada posisi tersisa yang perlu ditutup, selesai
      if(remainingCount == 0) break;
      
      // Jika semua berhasil ditutup pada attempt ini, selesai
      if(closedCount == remainingCount) break;
      
      // Masih ada yang gagal, tunggu sebentar lalu coba lagi
      attempt++;
      if(attempt < maxRetries) {
         Sleep(200);  // Tunggu lebih lama sebelum retry
         Print("ClosePositions: Retry attempt ", attempt, "/", maxRetries, 
               " - ", remainingCount - closedCount, " posisi masih terbuka");
      }
   }
   
   if(attempt >= maxRetries) {
      Alert("ClosePositions: Beberapa posisi mungkin gagal ditutup setelah ", maxRetries, " percobaan!");
   }
   PrintFormat("CloseAllPositions: %d posisi ditutup, %d posisi lama diabaikan",
               totalClosed, excludedOldCount);
}


//+------------------------------------------------------------------+
//| Position Stats Panel Functions (Left Upper Corner)                |
//+------------------------------------------------------------------+
void CreatePositionStatsPanel()
{
   int panelX = UIPix(10);
   int panelY = UIPix(10);   // From top
   int lineH  = UIStatsLineHeight();
   int padX   = UIPix(10);

   // Lebar mengikuti baris terpanjang supaya angka lot/margin tidak terpotong
   int panelW = (int)MathMax(UIPix(180),
                             UITextWidth("─── LOT MARGIN INFO ───", UIFont(9), "Consolas") + (2 * padX));
   panelW = (int)MathMax(panelW,
                         UITextWidth("Max Capacity: 999.99 lot", UIFont(9), "Consolas") + (2 * padX));

   int panelH = UIStatsPanelHeight();

   // Background Panel
   if(ObjectFind(0, ObjStatsPanelBG) < 0) {
      ObjectCreate(0, ObjStatsPanelBG, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_BGCOLOR, C'15,25,35');
      ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_BORDER_COLOR, clrDarkSlateGray);
      ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_BACK, false);
   }
   ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_XDISTANCE, panelX);
   ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_YDISTANCE, panelY);
   ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_XSIZE, panelW);
   ObjectSetInteger(0, ObjStatsPanelBG, OBJPROP_YSIZE, panelH);
   SetUIObjectOnTop(ObjStatsPanelBG, UI_BG_ZORDER);

   int yOffset = panelY + UIPix(12);
   int xOffset = panelX + padX;
   int xIndent = xOffset + UIPix(15);

   // Title with Account Type
   string titleText = IsCentAccount ? "═ POSITION STATS ═" : "═ POSITION STATS ═";
   color titleColor = IsCentAccount ? clrOrange : clrGold;
   CreateStatsLabel(ObjStatsPanelTitle, xOffset, yOffset, titleText, titleColor, 9, "Arial Bold");
   yOffset += lineH + UIPix(5);

   // Total Profit/Loss
   CreateStatsLabel(ObjStatsTotalProfit, xOffset, yOffset, "P/L: $0.00", clrWhite, 9, "Arial Bold");
   yOffset += lineH + UIPix(3);

   // Total Pips
   CreateStatsLabel(ObjStatsTotalPips, xOffset, yOffset, "Pips: 0.0", clrCyan, 9, "Consolas");
   yOffset += lineH;

   // Total Points
   CreateStatsLabel(ObjStatsTotalPoints, xOffset, yOffset, "Points: 0.0", clrSilver, 8, "Consolas");
   yOffset += lineH + UIPix(5);

   // Buy Layers
   CreateStatsLabel(ObjStatsLayerBuy, xOffset, yOffset, "▲ BUY: 0 layers", clrLime, 8, "Consolas");
   yOffset += lineH;

   // Buy Lots
   CreateStatsLabel(ObjStatsLotBuy, xIndent, yOffset, "Lot: 0.00", clrLimeGreen, 8, "Consolas");
   yOffset += lineH;

   // Sell Layers
   CreateStatsLabel(ObjStatsLayerSell, xOffset, yOffset, "▼ SELL: 0 layers", clrOrangeRed, 8, "Consolas");
   yOffset += lineH;

   // Sell Lots
   CreateStatsLabel(ObjStatsLotSell, xIndent, yOffset, "Lot: 0.00", clrCoral, 8, "Consolas");
   yOffset += lineH + UIPix(5);

   // Separator line
   CreateStatsLabel(ObjStatsSeparator, xOffset, yOffset, "─── LOT MARGIN INFO ───", clrDimGray, 8, "Consolas");
   yOffset += lineH;

   // Margin Level
   CreateStatsLabel(ObjStatsMarginLevel, xOffset, yOffset, "Margin Level: --%", clrWhite, 9, "Consolas");
   yOffset += lineH;

   // Used Lot (Total lots currently in use)
   CreateStatsLabel(ObjStatsUsedLot, xOffset, yOffset, "Used: 0.00 lot", clrYellow, 9, "Consolas");
   yOffset += lineH;

   // Safe Lot (Conservative - based on max margin usage %)
   CreateStatsLabel(ObjStatsSafeLot, xOffset, yOffset, "Safe: 0.00 lot", clrLime, 9, "Consolas");
   yOffset += lineH;

   // Available Lot (Remaining lots based on free margin - 100%)
   CreateStatsLabel(ObjStatsAvailableLot, xOffset, yOffset, "Available: 0.00 lot", clrAqua, 8, "Consolas");
   yOffset += lineH;

   // Max Lot (Total capacity based on equity)
   CreateStatsLabel(ObjStatsMaxLot, xOffset, yOffset, "Max Capacity: 0.00 lot", clrSilver, 8, "Consolas");
   yOffset += lineH;

   // Broker server time
   CreateStatsLabel(ObjStatsBrokerTime, xOffset, yOffset, "Broker Time: --:--:--", clrLightSteelBlue, 8, "Consolas");

   BringUIToFront();
}

void CreateStatsLabel(string name, int x, int y, string text, color clr, int fontSize, string font)
{
   bool isNew = (ObjectFind(0, name) < 0);
   if(isNew) {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   }
   // Teks & warna diperbarui tiap tick oleh UpdatePositionStatsPanel(),
   // jadi saat relayout hanya geometri yang di-set ulang.
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, UIFont(fontSize));
   ObjectSetString(0, name, OBJPROP_FONT, font);
}

void UpdateBrokerTimeLabel()
{
   if(ObjectFind(0, ObjStatsBrokerTime) < 0)
      return;

   datetime brokerTime = TimeTradeServer();
   if(brokerTime <= 0)
      brokerTime = TimeCurrent();

   ObjectSetString(0, ObjStatsBrokerTime, OBJPROP_TEXT,
                   "Broker Time: " + TimeToString(brokerTime, TIME_SECONDS));
   ObjectSetInteger(0, ObjStatsBrokerTime, OBJPROP_COLOR, clrLightSteelBlue);
}

void UpdatePositionStatsPanel()
{
   double totalProfit = 0;
   double totalPoints = 0;
   int buyLayers = 0;
   int sellLayers = 0;
   double buyLots = 0;
   double sellLots = 0;
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   
   // Detect Gold/Silver symbols
   string symbolUpper = _Symbol;
   StringToUpper(symbolUpper);
   bool isGold = (StringFind(symbolUpper, "XAU") >= 0 || StringFind(symbolUpper, "GOLD") >= 0);
   bool isSilver = (StringFind(symbolUpper, "XAG") >= 0 || StringFind(symbolUpper, "SILVER") >= 0);
   
   // Pip multiplier calculation
   double pipMultiplier = 1.0;
   if(isGold)
   {
      // Gold: 1 pip = $1.00 movement
      // 2 digit (2650.50): 1 pip = 100 points
      // 3 digit (2650.505): 1 pip = 1000 points
      pipMultiplier = (digits == 3) ? 1000.0 : 100.0;
   }
   else if(isSilver)
   {
      // Silver: 1 pip = $0.01 movement (similar to forex)
      // 2 digit (30.50): 1 pip = 1 point
      // 3 digit (30.505): 1 pip = 10 points
      pipMultiplier = (digits == 3) ? 10.0 : 1.0;
   }
   else
   {
      // Forex: Standard 5/3 digit = 10, 4/2 digit = 1
      pipMultiplier = (digits == 3 || digits == 5) ? 10.0 : 1.0;
   }
   
   // Calculate from all open positions for this symbol with our magic number
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
      {
         long posMagic = PositionGetInteger(POSITION_MAGIC);
         if(posMagic == InpMagicNumber)
         {
            double posProfit = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
            double currentPrice = PositionGetDouble(POSITION_PRICE_CURRENT);
            double volume = PositionGetDouble(POSITION_VOLUME);
            long posType = PositionGetInteger(POSITION_TYPE);
            
            totalProfit += posProfit;
            
            // Calculate points (raw smallest tick movement)
            double pts = 0;
            if(posType == POSITION_TYPE_BUY)
            {
               pts = (currentPrice - openPrice) / point;
               buyLayers++;
               buyLots += volume;
            }
            else if(posType == POSITION_TYPE_SELL)
            {
               pts = (openPrice - currentPrice) / point;
               sellLayers++;
               sellLots += volume;
            }
            totalPoints += pts;
         }
      }
   }
   
   // Calculate pips from points
   double totalPips = totalPoints / pipMultiplier;
   
   // Apply cent divisor for correct profit display
   double displayProfit = totalProfit / CentDivisor;
   
   // Calculate P/L percentage relative to balance
   double accountBalance = AccountInfoDouble(ACCOUNT_BALANCE) / CentDivisor;
   double profitPercent = (accountBalance > 0) ? (displayProfit / accountBalance) * 100.0 : 0;
   
   // Update panel labels
   color profitColor = (displayProfit >= 0) ? clrLime : clrRed;
   string profitSign = (displayProfit >= 0) ? "+" : "";
   string currencySymbol = IsCentAccount ? "$" : "$";
   string percentSign = (profitPercent >= 0) ? "+" : "";
   ObjectSetString(0, ObjStatsTotalProfit, OBJPROP_TEXT, StringFormat("P/L: %s%s%.2f (%s%.1f%%)", profitSign, currencySymbol, displayProfit, percentSign, profitPercent));
   ObjectSetInteger(0, ObjStatsTotalProfit, OBJPROP_COLOR, profitColor);
   
   // Pips display
   color pipsColor = (totalPips >= 0) ? clrCyan : clrOrangeRed;
   ObjectSetString(0, ObjStatsTotalPips, OBJPROP_TEXT, StringFormat("Pips: %.1f", totalPips));
   ObjectSetInteger(0, ObjStatsTotalPips, OBJPROP_COLOR, pipsColor);
   
   // Points display
   color pointsColor = (totalPoints >= 0) ? clrSilver : clrCoral;
   ObjectSetString(0, ObjStatsTotalPoints, OBJPROP_TEXT, StringFormat("Points: %.0f", totalPoints));
   ObjectSetInteger(0, ObjStatsTotalPoints, OBJPROP_COLOR, pointsColor);
   
   ObjectSetString(0, ObjStatsLayerBuy, OBJPROP_TEXT, StringFormat("▲ BUY: %d layer%s", buyLayers, buyLayers != 1 ? "s" : ""));
   ObjectSetString(0, ObjStatsLotBuy, OBJPROP_TEXT, StringFormat("   Lot: %.2f", buyLots));
   
   ObjectSetString(0, ObjStatsLayerSell, OBJPROP_TEXT, StringFormat("▼ SELL: %d layer%s", sellLayers, sellLayers != 1 ? "s" : ""));
   ObjectSetString(0, ObjStatsLotSell, OBJPROP_TEXT, StringFormat("   Lot: %.2f", sellLots));
   
   //=== LOT MARGIN INFO CALCULATION ===
   double usedLots = buyLots + sellLots;
   double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);

   double usedMargin = AccountInfoDouble(ACCOUNT_MARGIN);
   
   // Calculate Margin Level (%)
   double marginLevel = 0;
   if(usedMargin > 0)
      marginLevel = (equity / usedMargin) * 100.0;
   
   // Calculate margin required for 1 lot
   double marginFor1Lot = 0;
   double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   
   // Use OrderCalcMargin for accurate margin calculation
   if(!OrderCalcMargin(ORDER_TYPE_BUY, _Symbol, 1.0, currentPrice, marginFor1Lot))
   {
      // Fallback: Use basic calculation if OrderCalcMargin fails
      double contractSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
      double leverage = (double)AccountInfoInteger(ACCOUNT_LEVERAGE);
      if(leverage > 0)
         marginFor1Lot = (contractSize * currentPrice) / leverage;
      else
         marginFor1Lot = contractSize * currentPrice / 100.0; // Assume 1:100 leverage
   }
   
   // Get lot step and min/max lot from symbol info
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double minLotSymbol = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLotSymbol = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   
   // Calculate max capacity based on total equity (theoretical maximum if no positions)
   double maxCapacityLots = 0;
   if(marginFor1Lot > 0)
   {
      maxCapacityLots = equity / marginFor1Lot;
      maxCapacityLots = MathFloor(maxCapacityLots / lotStep) * lotStep;
      if(maxCapacityLots > maxLotSymbol) maxCapacityLots = maxLotSymbol;
   }
   
   // Calculate available lots based on free margin (100% of free margin)
   double availableLots = 0;
   if(marginFor1Lot > 0)
   {
      availableLots = freeMargin / marginFor1Lot;
      // Normalize to lot step
      availableLots = MathFloor(availableLots / lotStep) * lotStep;
      // Ensure minimum lot
      if(availableLots < minLotSymbol) availableLots = 0;
      // Cap at max lot
      if(availableLots > maxLotSymbol) availableLots = maxLotSymbol;
   }
   
   //=== SAFE LOT CALCULATION (CONSERVATIVE) ===
   // Safe Lot = How many lots can still be ADDED while staying within margin safety limits
   // Formula: SafeMargin = (Equity * MaxMarginUsage%) - UsedMargin
   //          SafeLots = SafeMargin / MarginFor1Lot
   
   double maxMarginToUse = equity * (InpMaxMarginUsage / 100.0);  // Maximum margin allowed
   double safeMarginRemaining = maxMarginToUse - usedMargin;      // How much more margin can be used
   
   double safeLots = 0;
   if(marginFor1Lot > 0 && safeMarginRemaining > 0)
   {
      safeLots = safeMarginRemaining / marginFor1Lot;
      safeLots = MathFloor(safeLots / lotStep) * lotStep;
      if(safeLots < minLotSymbol) safeLots = 0;
      if(safeLots > maxLotSymbol) safeLots = maxLotSymbol;
   }
   
   // Calculate current margin usage percentage
   double marginUsagePercent = (equity > 0) ? (usedMargin / equity) * 100.0 : 0;
   
   //=== UPDATE PANEL LABELS ===
   
   // Margin Level display with warning colors
   color marginLevelColor = clrLime;
   string marginLevelText = "";
   if(usedMargin == 0)
   {
      marginLevelText = "Margin Level: --";
      marginLevelColor = clrGray;
   }
   else
   {
      marginLevelText = StringFormat("Margin Level: %.0f%%", marginLevel);
      if(marginLevel < InpMinMarginLevel)
         marginLevelColor = clrRed;        // DANGER!
      else if(marginLevel < InpMinMarginLevel * 2)
         marginLevelColor = clrOrange;     // Warning
      else if(marginLevel < InpMinMarginLevel * 3)
         marginLevelColor = clrYellow;     // Caution
      else
         marginLevelColor = clrLime;       // Safe
   }
   ObjectSetString(0, ObjStatsMarginLevel, OBJPROP_TEXT, marginLevelText);
   ObjectSetInteger(0, ObjStatsMarginLevel, OBJPROP_COLOR, marginLevelColor);
   
   // Used Lot
   color usedColor = clrGray;
   if(usedLots > 0)
   {
      if(marginUsagePercent > InpMaxMarginUsage)
         usedColor = clrRed;        // Over limit!
      else if(marginUsagePercent > InpMaxMarginUsage * 0.8)
         usedColor = clrOrange;     // Near limit
      else
         usedColor = clrYellow;     // Normal
   }
   ObjectSetString(0, ObjStatsUsedLot, OBJPROP_TEXT, StringFormat("Used: %.2f lot (%.0f%%)", usedLots, marginUsagePercent));
   ObjectSetInteger(0, ObjStatsUsedLot, OBJPROP_COLOR, usedColor);
   
   // Safe Lot (Conservative - main recommendation)
   color safeColor = clrLime;
   if(safeLots == 0 && usedLots > 0)
      safeColor = clrRed;           // No more safe capacity
   else if(safeLots < minLotSymbol * 5)
      safeColor = clrOrange;        // Very limited
   else
      safeColor = clrLime;          // Good capacity
   
   ObjectSetString(0, ObjStatsSafeLot, OBJPROP_TEXT, StringFormat("★ Safe: %.2f lot", safeLots));
   ObjectSetInteger(0, ObjStatsSafeLot, OBJPROP_COLOR, safeColor);
   
   // Available Lot (100% margin - for reference only)
   ObjectSetString(0, ObjStatsAvailableLot, OBJPROP_TEXT, StringFormat("Available: %.2f lot", availableLots));
   ObjectSetInteger(0, ObjStatsAvailableLot, OBJPROP_COLOR, clrAqua);
   
   // Max Capacity
   ObjectSetString(0, ObjStatsMaxLot, OBJPROP_TEXT, StringFormat("Max Capacity: %.2f lot", maxCapacityLots));
   ObjectSetInteger(0, ObjStatsMaxLot, OBJPROP_COLOR, clrSilver);

   // Broker server time
   UpdateBrokerTimeLabel();
   
   ChartRedraw();
}

void DeletePositionStatsPanel()
{
   ObjectDelete(0, ObjStatsPanelBG);
   ObjectDelete(0, ObjStatsPanelTitle);
   ObjectDelete(0, ObjStatsTotalProfit);
   ObjectDelete(0, ObjStatsTotalPips);
   ObjectDelete(0, ObjStatsTotalPoints);
   ObjectDelete(0, ObjStatsLayerBuy);
   ObjectDelete(0, ObjStatsLayerSell);
   ObjectDelete(0, ObjStatsLotBuy);
   ObjectDelete(0, ObjStatsLotSell);
   // Lot Margin Info
   ObjectDelete(0, ObjStatsSeparator);
   ObjectDelete(0, ObjStatsMarginLevel);
   ObjectDelete(0, ObjStatsUsedLot);
   ObjectDelete(0, ObjStatsSafeLot);
   ObjectDelete(0, ObjStatsAvailableLot);
   ObjectDelete(0, ObjStatsMaxLot);
   ObjectDelete(0, ObjStatsBrokerTime);
}

//+------------------------------------------------------------------+
//| Detect Cent Account Function                                       |
//| Checks: Symbol suffix, Account currency, Symbol path               |
//+------------------------------------------------------------------+
void DetectCentAccount()
{
   IsCentAccount = false;
   CentDivisor = 1.0;
   
   // Method 1: Check symbol name for cent suffix
   string symbol = _Symbol;
   string symbolLower = symbol;
   StringToLower(symbolLower);
   
   // Common cent symbol patterns: EURUSDc, EURUSD.c, EURUSDcent, EURUSD_c
   if(StringFind(symbolLower, "cent") >= 0 ||
      StringGetCharacter(symbolLower, StringLen(symbolLower) - 1) == 'c' ||
      StringFind(symbolLower, ".c") >= 0 ||
      StringFind(symbolLower, "_c") >= 0)
   {
      IsCentAccount = true;
   }
   
   // Method 2: Check account currency for cent currencies
   string currency = AccountInfoString(ACCOUNT_CURRENCY);
   StringToUpper(currency);
   
   // Common cent currencies: USC (US Cent), EUC (Euro Cent), GBC (British Cent)
   if(currency == "USC" || currency == "EUC" || currency == "GBC" || 
      currency == "CHC" || currency == "AUC" || currency == "NZC" ||
      currency == "CAC" || currency == "JPY100" ||
      StringFind(currency, "CENT") >= 0)
   {
      IsCentAccount = true;
   }
   
   // Method 3: Check symbol path for cent folders
   string symbolPath = SymbolInfoString(_Symbol, SYMBOL_PATH);
   StringToLower(symbolPath);
   if(StringFind(symbolPath, "cent") >= 0)
   {
      IsCentAccount = true;
   }
   
   // Method 4: Check contract size (cent accounts often have 1000 instead of 100000)
   double contractSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
   if(contractSize == 1000.0)
   {
      IsCentAccount = true;
   }
   
   // Set divisor based on detection
   if(IsCentAccount)
   {
      CentDivisor = 100.0;
      Print("Cent Account Detected! Symbol: ", _Symbol, ", Currency: ", currency);
   }
   else
   {
      CentDivisor = 1.0;
      Print("Standard Account Detected. Symbol: ", _Symbol, ", Currency: ", currency);
   }
}


//+------------------------------------------------------------------+
//| MARGIN CALL DETECTION FUNCTIONS                                   |
//+------------------------------------------------------------------+
//| Update MC Line - Calculate and draw MC level                      |
//+------------------------------------------------------------------+
void UpdateMCLine()
{
   // Get account info
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double usedMargin = AccountInfoDouble(ACCOUNT_MARGIN);
   double stopOutLevel = AccountInfoDouble(ACCOUNT_MARGIN_SO_SO); // Stop Out Level dari broker
   
   // Jika broker tidak return stop out level, gunakan default
   if(stopOutLevel == 0) stopOutLevel = StopOutLevel;
   
   // Hitung total lots dan posisi dominan
   double buyLots = 0, sellLots = 0;
   double buyValue = 0, sellValue = 0;
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
      {
         long posMagic = PositionGetInteger(POSITION_MAGIC);
         if(posMagic == InpMagicNumber)
         {
            double volume = PositionGetDouble(POSITION_VOLUME);
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
            long posType = PositionGetInteger(POSITION_TYPE);
            
            if(posType == POSITION_TYPE_BUY)
            {
               buyLots += volume;
               buyValue += volume * openPrice;
            }
            else if(posType == POSITION_TYPE_SELL)
            {
               sellLots += volume;
               sellValue += volume * openPrice;
            }
         }
      }
   }
   
   double totalLots = buyLots + sellLots;
   
   // Jika tidak ada posisi, hapus MC line
   if(totalLots == 0 || usedMargin == 0)
   {
      DeleteMCLine();
      return;
   }
   
   // Hitung equity yang tersisa sampai Stop Out
   // Stop Out terjadi ketika: Equity = UsedMargin * (StopOutLevel / 100)
   double stopOutEquity = usedMargin * (stopOutLevel / 100.0);
   double equityToMC = equity - stopOutEquity;
   
   // Jika sudah di bawah MC level, tetap tampilkan di current price
   if(equityToMC <= 0) equityToMC = 0;
   
   // Hitung tick value untuk konversi equity ke points
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   
   // MC price calculation
   double mcPrice = 0;
   
   if(tickValue > 0 && totalLots > 0)
   {
      // Points movement needed to reach MC
      // equityToMC = pointsToMC * tickValue * totalLots / (tickSize / point)
      double pointsToMC = (equityToMC * tickSize) / (tickValue * totalLots * point);
      
      // Tentukan arah berdasarkan posisi net
      if(buyLots > sellLots)
      {
         // Net BUY - MC terjadi jika harga turun
         double avgBuyPrice = (buyLots > 0) ? buyValue / buyLots : SymbolInfoDouble(_Symbol, SYMBOL_BID);
         mcPrice = avgBuyPrice - (pointsToMC * point);
      }
      else if(sellLots > buyLots)
      {
         // Net SELL - MC terjadi jika harga naik
         double avgSellPrice = (sellLots > 0) ? sellValue / sellLots : SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         mcPrice = avgSellPrice + (pointsToMC * point);
      }
      else
      {
         // Hedged position - MC berdasarkan pergerakan absolut terbesar
         double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         double avgBuyPrice = (buyLots > 0) ? buyValue / buyLots : currentPrice;
         mcPrice = avgBuyPrice - (pointsToMC * point);
      }
      
      mcPrice = NormalizeDouble(mcPrice, _Digits);
   }
   
   // Skip jika MC price tidak valid
   if(mcPrice <= 0) 
   {
      DeleteMCLine();
      return;
   }
   
   // Create atau Update MC Line
   CreateMCLine(mcPrice, equityToMC);
}

//+------------------------------------------------------------------+
//| Create MC Line and Label                                          |
//+------------------------------------------------------------------+
void CreateMCLine(double mcPrice, double equityToMC)
{
   color mcColor = clrOrangeRed;
   
   // Warna berdasarkan jarak ke MC
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double pctToMC = (equity > 0) ? (equityToMC / equity) * 100.0 : 0;
   
   if(pctToMC < 10)
      mcColor = clrRed;           // DANGER! Sangat dekat MC
   else if(pctToMC < 25)
      mcColor = clrOrangeRed;     // Warning
   else if(pctToMC < 50)
      mcColor = clrOrange;        // Caution
   else
      mcColor = clrGold;          // Still safe
   
   // Create/Update MC Horizontal Line
   if(ObjectFind(0, ObjMCLine) < 0)
   {
      ObjectCreate(0, ObjMCLine, OBJ_HLINE, 0, 0, mcPrice);
      ObjectSetInteger(0, ObjMCLine, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, ObjMCLine, OBJPROP_SELECTED, false);
      ObjectSetInteger(0, ObjMCLine, OBJPROP_BACK, true);
      ObjectSetInteger(0, ObjMCLine, OBJPROP_ZORDER, CHART_LINE_ZORDER);
   }
   ObjectSetDouble(0, ObjMCLine, OBJPROP_PRICE, mcPrice);
   ObjectSetInteger(0, ObjMCLine, OBJPROP_COLOR, mcColor);
   ObjectSetInteger(0, ObjMCLine, OBJPROP_STYLE, STYLE_DASHDOTDOT);  // Notification style (dash-dot-dot)
   ObjectSetInteger(0, ObjMCLine, OBJPROP_WIDTH, 1);  // Thin line for notification
   
   // Format label text
   string mcText = StringFormat("⚠ MC/Margin Call @ %.5f (%.1f%% equity left)", mcPrice, pctToMC);
   
   // Create/Update MC Price Label
   if(ObjectFind(0, ObjMCLabel) < 0)
   {
      ObjectCreate(0, ObjMCLabel, OBJ_TEXT, 0, 0, mcPrice);
   }
   
   // Position label at current time (right side of chart)
   datetime labelTime = TimeCurrent() + PeriodSeconds(PERIOD_CURRENT) * 5;
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_TIME, labelTime);
   ObjectSetDouble(0, ObjMCLabel, OBJPROP_PRICE, mcPrice);
   ObjectSetString(0, ObjMCLabel, OBJPROP_TEXT, mcText);
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_COLOR, mcColor);
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_FONTSIZE, UIFont(9));
   ObjectSetString(0, ObjMCLabel, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_ANCHOR, ANCHOR_LEFT_LOWER);
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_BACK, true);
   ObjectSetInteger(0, ObjMCLabel, OBJPROP_ZORDER, CHART_LINE_ZORDER);
   
   BringUIToFront();
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Delete MC Line and Label                                          |
//+------------------------------------------------------------------+
void DeleteMCLine()
{
   ObjectDelete(0, ObjMCLine);
   ObjectDelete(0, ObjMCLabel);
}

//+------------------------------------------------------------------+
//| ZERO BALANCE LINE FUNCTIONS (Where Equity = 0)                    |
//+------------------------------------------------------------------+
//| Update Zero Balance Line - Calculate and draw liquidation level   |
//+------------------------------------------------------------------+
void UpdateZeroBalanceLine()
{
   // Get account info
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);

   
   // Hitung total lots dan posisi untuk symbol ini
   double buyLots = 0, sellLots = 0;
   double buyValue = 0, sellValue = 0;
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && PositionGetString(POSITION_SYMBOL) == _Symbol)
      {
         long posMagic = PositionGetInteger(POSITION_MAGIC);
         if(posMagic == InpMagicNumber)
         {
            double volume = PositionGetDouble(POSITION_VOLUME);
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
            long posType = PositionGetInteger(POSITION_TYPE);
            
            if(posType == POSITION_TYPE_BUY)
            {
               buyLots += volume;
               buyValue += volume * openPrice;
            }
            else if(posType == POSITION_TYPE_SELL)
            {
               sellLots += volume;
               sellValue += volume * openPrice;
            }
         }
      }
   }
   
   double totalLots = buyLots + sellLots;
   
   // Jika tidak ada posisi, hapus Zero Balance line
   if(totalLots == 0)
   {
      DeleteZeroBalanceLine();
      return;
   }
   
   // Hitung tick value untuk konversi equity ke points
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   
   // Zero Balance price calculation - dimana equity = 0 (total loss)
   double zeroBalancePrice = 0;
   
   if(tickValue > 0 && totalLots > 0)
   {
      // Points movement needed to reach Zero Balance (equity = 0)
      // Menggunakan CURRENT PRICE + EQUITY (bukan entry price)
      double pointsToZero = (equity * tickSize) / (tickValue * totalLots * point);
      
      // Tentukan arah berdasarkan posisi net
      // PENTING: Gunakan CURRENT PRICE, bukan entry price!
      if(buyLots > sellLots)
      {
         // Net BUY - dari harga SEKARANG, berapa turun sampai equity = 0
         double currentBid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         zeroBalancePrice = currentBid - (pointsToZero * point);
      }
      else if(sellLots > buyLots)
      {
         // Net SELL - dari harga SEKARANG, berapa naik sampai equity = 0
         double currentAsk = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
         zeroBalancePrice = currentAsk + (pointsToZero * point);
      }
      else
      {
         // Hedged position
         double currentBid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
         zeroBalancePrice = currentBid - (pointsToZero * point);
      }
      
      zeroBalancePrice = NormalizeDouble(zeroBalancePrice, _Digits);
   }
   
   // Skip jika price tidak valid
   if(zeroBalancePrice <= 0) 
   {
      DeleteZeroBalanceLine();
      return;
   }
   
   // Create atau Update Zero Balance Line
   CreateZeroBalanceLine(zeroBalancePrice);
}

//+------------------------------------------------------------------+
//| Create Zero Balance Line and Label (Solid Dotted Style)           |
//+------------------------------------------------------------------+
void CreateZeroBalanceLine(double zeroPrice)
{

   
   // Create/Update Zero Balance Horizontal Line - SOLID STYLE (The definitive Liquidation Line)
   if(ObjectFind(0, ObjZeroBalanceLine) < 0)
   {
      ObjectCreate(0, ObjZeroBalanceLine, OBJ_HLINE, 0, 0, zeroPrice);
      ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_SELECTED, false);
      ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_BACK, true);
      ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_ZORDER, CHART_LINE_ZORDER);
   }
   ObjectSetDouble(0, ObjZeroBalanceLine, OBJPROP_PRICE, zeroPrice);
   ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_COLOR, clrDarkRed); // Merah Gelap (Tegas)
   ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_STYLE, STYLE_SOLID); // Solid line
   ObjectSetInteger(0, ObjZeroBalanceLine, OBJPROP_WIDTH, 2); // Agak tebal agar terlihat jelas sebagai Batas Akhir
   
   // Hitung jarak ke zero balance
   double currentPrice = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double distancePoints = MathAbs(currentPrice - zeroPrice) / SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   
   // Format label text - Lebih informatif sebagai FINAL STOP
   string zeroBalanceText = StringFormat("⛔ LIQUIDATION STOP @ %.5f | Dist: %.0f pts [BALANCE = 0]", zeroPrice, distancePoints);
   
   // Create/Update Zero Balance Price Label
   if(ObjectFind(0, ObjZeroBalanceLabel) < 0)
   {
      ObjectCreate(0, ObjZeroBalanceLabel, OBJ_TEXT, 0, 0, zeroPrice);
   }
   
   // Position label at current time (right side of chart)
   datetime labelTime = TimeCurrent() + PeriodSeconds(PERIOD_CURRENT) * 5;
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_TIME, labelTime);
   ObjectSetDouble(0, ObjZeroBalanceLabel, OBJPROP_PRICE, zeroPrice);
   ObjectSetString(0, ObjZeroBalanceLabel, OBJPROP_TEXT, zeroBalanceText);
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_COLOR, clrDarkRed);
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_FONTSIZE, UIFont(9));
   ObjectSetString(0, ObjZeroBalanceLabel, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_BACK, true);
   ObjectSetInteger(0, ObjZeroBalanceLabel, OBJPROP_ZORDER, CHART_LINE_ZORDER);
   
   BringUIToFront();
   ChartRedraw();
}

//+------------------------------------------------------------------+
//| Delete Zero Balance Line and Label                                |
//+------------------------------------------------------------------+
void DeleteZeroBalanceLine()
{
   ObjectDelete(0, ObjZeroBalanceLine);
   ObjectDelete(0, ObjZeroBalanceLabel);
}

//+------------------------------------------------------------------+
//| Virtual PLAN: wick never places an order; only closed-bar crossing |
//+------------------------------------------------------------------+
// The broker's stop side is Bid for BUY and Ask for SELL; equality is a touch.
bool PlanSLTouched(bool isBuy, double sl, double bid, double ask)
{
   if(sl <= 0 || bid <= 0 || ask <= 0) return(false);
   if(isBuy) return(bid <= sl);
   return(ask >= sl);
}

bool InvalidateArmedPlanAtSL()
{
   if(!PlanArmed || !VirtualPlanUnchanged()) return(false);
   MqlTick quote;
   if(!SymbolInfoTick(_Symbol, quote)) return(false);
   if(!PlanSLTouched(PlanSnapshotBuy, PlanSnapshotSL, quote.bid, quote.ask)) return(false);
   PlanArmed = false;
   SetVirtualPlanStatus("INVALID - SL tersentuh, PLAN batal");
   PrintFormat("HW PLAN %s dibatalkan: SL invalidasi %.5f tersentuh sebelum entry.",
               PlanSnapshotBuy ? "BUY" : "SELL", PlanSnapshotSL);
   return(true);
}

string PlanStopRegistryPrefix()
{
   return("HWPS_" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "_");
}

// Delete only pending orders carrying this plan's unique tag AND EA ownership.
// Invalidity is latched: failed deletions retry even after price rebounds from SL.
void ProcessPlanPendingInvalidation()
{
   string prefix = PlanStopRegistryPrefix();
   MqlTick quote;
   if(!SymbolInfoTick(_Symbol, quote)) return;
   // Snapshot keys: deleting globals or adding latch keys changes the live index.
   string keys[];
   for(int k = GlobalVariablesTotal() - 1; k >= 0; k--)
   {
      string key = GlobalVariableName(k);
      if(StringFind(key, prefix) != 0 || StringSubstr(key, StringLen(key) - 2) == "_X") continue;
      int n = ArraySize(keys);
      ArrayResize(keys, n + 1);
      keys[n] = key;
   }
   for(int k = 0; k < ArraySize(keys); k++)
   {
      string key = keys[k];
      if(!GlobalVariableCheck(key)) continue;
      string group = StringSubstr(key, StringLen(prefix));
      double signedSL = GlobalVariableGet(key);
      string invalidKey = key + "_X";
      bool invalid = GlobalVariableCheck(invalidKey);
      bool foreignOwner = false;
      int remaining = 0;
      for(int i = OrdersTotal() - 1; i >= 0; i--)
      {
         ulong ticket = OrderGetTicket(i);
         if(ticket == 0 || StringFind(OrderGetString(ORDER_COMMENT), group + " ") != 0) continue;
         if(OrderGetString(ORDER_SYMBOL) != _Symbol || OrderGetInteger(ORDER_MAGIC) != InpMagicNumber)
         {
            foreignOwner = true;
            continue;
         }
         ENUM_ORDER_TYPE type = (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
         if(type != ORDER_TYPE_BUY_LIMIT && type != ORDER_TYPE_SELL_LIMIT) continue;
         if(!invalid && PlanSLTouched(signedSL > 0, MathAbs(signedSL), quote.bid, quote.ask))
         {
            if(!GlobalVariableSet(invalidKey, 1.0))
            {
               remaining++;
               Print("HW PLAN: gagal menyimpan invalidasi pending; coba lagi.");
               continue;
            }
            GlobalVariablesFlush();
            invalid = true;
            PrintFormat("HW PLAN %s invalid: SL %.5f tersentuh; hapus pending milik plan.", group, MathAbs(signedSL));
         }
         if(!invalid) { remaining++; continue; }
         bool sent = trade.OrderDelete(ticket);
         uint result = trade.ResultRetcode();
         if(!sent || result != TRADE_RETCODE_DONE)
         {
            // Filled/removed while request was in flight: it is no longer pending.
            if(OrderSelect(ticket)) remaining++;
            PrintFormat("HW PLAN hapus pending #%I64u: %u - %s", ticket, result, trade.ResultRetcodeDescription());
         }
         else PrintFormat("HW PLAN %s: pending #%I64u dihapus karena invalidasi SL.", group, ticket);
      }
      if(remaining == 0 && !foreignOwner)
      {
         GlobalVariableDel(key);
         GlobalVariableDel(invalidKey);
      }
   }
}

// A broker SL deal also invalidates siblings, including when price already bounced
// before OnTick can see the touch. Locate the plan tag on the opening order.
void InvalidatePlanFromStopLossDeal(ulong deal)
{
   if(!HistoryDealSelect(deal)) return;
   if(HistoryDealGetString(deal, DEAL_SYMBOL) != _Symbol ||
      (ENUM_DEAL_REASON)HistoryDealGetInteger(deal, DEAL_REASON) != DEAL_REASON_SL) return;
   long positionID = HistoryDealGetInteger(deal, DEAL_POSITION_ID);
   if(!HistorySelectByPosition(positionID)) return;
   for(int i = 0; i < HistoryDealsTotal(); i++)
   {
      ulong openingDeal = HistoryDealGetTicket(i);
      ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(openingDeal, DEAL_ENTRY);
      if(entry != DEAL_ENTRY_IN && entry != DEAL_ENTRY_INOUT) continue;
      if(HistoryDealGetInteger(openingDeal, DEAL_MAGIC) != InpMagicNumber) continue;
      ulong order = (ulong)HistoryDealGetInteger(openingDeal, DEAL_ORDER);
      string comment = HistoryOrderGetString(order, ORDER_COMMENT);
      if(comment == "") comment = HistoryDealGetString(openingDeal, DEAL_COMMENT);
      int separator = StringFind(comment, " ");
      if(separator < 0) continue;
      string key = PlanStopRegistryPrefix() + StringSubstr(comment, 0, separator);
      if(!GlobalVariableCheck(key)) continue;
      GlobalVariableSet(key + "_X", 1.0);
      GlobalVariablesFlush();
   }
   ProcessPlanPendingInvalidation();
}

ENUM_TIMEFRAMES PlanTimeframe()
{
   return(InpPlanTimeframe == PERIOD_CURRENT ? (ENUM_TIMEFRAMES)_Period : InpPlanTimeframe);
}

bool PlanBreakoutConfirmed(bool isBuy, double level, double previousClose, double closedClose)
{
   if(isBuy)
      return(previousClose <= level && closedClose > level);
   return(previousClose >= level && closedClose < level);
}

void SetVirtualPlanStatus(string value)
{
   PlanStatus = value;
   if(ObjectFind(0, ObjPlanInfoStatus) >= 0)
      ObjectSetString(0, ObjPlanInfoStatus, OBJPROP_TEXT, value);
   if(ObjectFind(0, ObjPlanExecuteBtn) >= 0)
   {
      ObjectSetString(0, ObjPlanExecuteBtn, OBJPROP_TEXT, PlanArmed ? "CANCEL PLAN" : "ARM PLAN");
      ObjectSetInteger(0, ObjPlanExecuteBtn, OBJPROP_BGCOLOR, PlanArmed ? clrDarkOrange : clrPurple);
   }
}

bool VirtualPlanUnchanged()
{
   if(ObjectFind(0, ObjPlanEntry) < 0 || ObjectFind(0, ObjPlanSL) < 0 ||
      ObjectFind(0, ObjPlanTP) < 0) return(false);
   double tol = SymbolInfoDouble(_Symbol, SYMBOL_POINT) * 0.5;
   return(MathAbs(ObjectGetDouble(0, ObjPlanEntry, OBJPROP_PRICE) - PlanSnapshotEntry) < tol &&
          MathAbs(ObjectGetDouble(0, ObjPlanSL, OBJPROP_PRICE) - PlanSnapshotSL) < tol &&
          MathAbs(ObjectGetDouble(0, ObjPlanTP, OBJPROP_PRICE) - PlanSnapshotTP) < tol &&
          MathAbs(CurrentLot - PlanSnapshotLot) < 0.00000001 &&
          CurrentLayer == PlanSnapshotLayers && CurrentGrid == PlanSnapshotGrid &&
          CurrentPlanEntryMode == PlanSnapshotEntryMode);
}

void ToggleVirtualPlan()
{
   if(PlanArmed)
   {
      PlanArmed = false;
      SetVirtualPlanStatus("DRAFT - deteksi dibatalkan");
      return;
   }
   SyncDraggableLines();
   if(ObjectFind(0, ObjPlanEntry) < 0 || ObjectFind(0, ObjPlanSL) < 0 ||
      ObjectFind(0, ObjPlanTP) < 0)
   {
      Alert("Buat PLAN BUY/SELL dan atur garis breakout, SL swing, serta TP terlebih dahulu.");
      return;
   }
   MqlRates bars[];
   ArraySetAsSeries(bars, true);
   if(CopyRates(_Symbol, PlanTimeframe(), 0, 3, bars) != 3)
   {
      Alert("Data candle konfirmasi belum siap. Coba ARM PLAN lagi.");
      return;
   }
   PlanSnapshotBuy = (ObjectGetInteger(0, ObjPlanEntry, OBJPROP_COLOR) == clrBlue);
   PlanSnapshotEntry = NormalizeDouble(ObjectGetDouble(0, ObjPlanEntry, OBJPROP_PRICE), _Digits);
   PlanSnapshotSL = NormalizeDouble(ObjectGetDouble(0, ObjPlanSL, OBJPROP_PRICE), _Digits);
   PlanSnapshotTP = NormalizeDouble(ObjectGetDouble(0, ObjPlanTP, OBJPROP_PRICE), _Digits);
   PlanSnapshotLot = CurrentLot;
   PlanSnapshotLayers = CurrentLayer;
   PlanSnapshotGrid = CurrentGrid;
   PlanSnapshotEntryMode = CurrentPlanEntryMode;
   bool validSide = PlanSnapshotBuy
                    ? (PlanSnapshotSL < PlanSnapshotEntry && PlanSnapshotTP > PlanSnapshotEntry)
                    : (PlanSnapshotSL > PlanSnapshotEntry && PlanSnapshotTP < PlanSnapshotEntry);
   if(!validSide || CurrentLayer < 1 || CurrentLayer > MaxLayer || CurrentLot <= 0 || CurrentGrid <= 0)
   {
      Alert("PLAN tidak valid: cek arah SL/TP, LOT, LAYER, dan GRID.");
      return;
   }
   PlanArmedBar = bars[0].time;
   PlanLastClosedBar = bars[1].time; // Candle sebelum ARM tidak boleh memicu entry.
   PlanArmed = true;
   if(InvalidateArmedPlanAtSL()) return;
   SetVirtualPlanStatus("ARMED - tunggu breakout close");
   PrintFormat("HW PLAN ARMED %s | %s | %s | breakout %.5f | SL %.5f | TP %.5f",
               PlanSnapshotBuy ? "BUY" : "SELL", EnumToString(PlanTimeframe()),
               CurrentPlanEntryMode == HW_PLAN_DIRECT ? "DIRECT" : "RETEST",
               PlanSnapshotEntry, PlanSnapshotSL, PlanSnapshotTP);
   UpdateVirtualPlanWatch();
}

void UpdateVirtualPlanWatch()
{
   if(!PlanArmed) return;
   if(!VirtualPlanUnchanged())
   {
      PlanArmed = false;
      SetVirtualPlanStatus("DRAFT - plan berubah, ARM lagi");
      return;
   }
   MqlRates live[];
   if(CopyRates(_Symbol, PlanTimeframe(), 0, 1, live) != 1) return;
   int seconds = PeriodSeconds(PlanTimeframe());
   datetime now = TimeTradeServer();
   if(now <= 0) now = TimeCurrent();
   int remaining = (int)MathMax(0, (double)(live[0].time + seconds - now));
   int watch = (int)MathMax(1, InpPlanWatchSeconds);
   bool beyond = PlanSnapshotBuy ? live[0].close > PlanSnapshotEntry : live[0].close < PlanSnapshotEntry;
   bool wick = PlanSnapshotBuy ? live[0].high > PlanSnapshotEntry : live[0].low < PlanSnapshotEntry;
   string mode = CurrentPlanEntryMode == HW_PLAN_DIRECT ? "DIRECT" : "RETEST";
   string status = StringFormat("%s %s | tunggu close", mode, EnumToString(PlanTimeframe()));
   if(remaining <= watch)
      status = StringFormat("%ds | %s", remaining, beyond ? "BREAK: tunggu close" : (wick ? "WICK: belum valid" : "belum breakout"));
   SetVirtualPlanStatus(status); // Countdown only: never trade from OnTimer/live candle.
}

void ProcessVirtualPlan()
{
   if(!PlanArmed) return;
   // SL touch has priority over a simultaneous closed-candle breakout.
   if(InvalidateArmedPlanAtSL()) return;
   if(!VirtualPlanUnchanged())
   {
      PlanArmed = false;
      SetVirtualPlanStatus("DRAFT - plan berubah, ARM lagi");
      return;
   }
   MqlRates bars[];
   ArraySetAsSeries(bars, true);
   if(CopyRates(_Symbol, PlanTimeframe(), 0, 3, bars) != 3) return;
   if(bars[1].time <= PlanLastClosedBar)
   {
      UpdateVirtualPlanWatch();
      return;
   }
   PlanLastClosedBar = bars[1].time;
   // Require a fresh closed bar since ARM, a real bar rollover, and a close crossing.
   int seconds = PeriodSeconds(PlanTimeframe());
   if(bars[1].time < PlanArmedBar || bars[0].time <= bars[1].time ||
      bars[1].time + seconds > TimeCurrent()) return;
   if(!PlanBreakoutConfirmed(PlanSnapshotBuy, PlanSnapshotEntry, bars[2].close, bars[1].close))
   {
      UpdateVirtualPlanWatch();
      return;
   }
   PlanArmed = false; // Consume signal BEFORE sending requests: no duplicate on later ticks.
   SetVirtualPlanStatus("BREAKOUT VALID - kirim order");
   PrintFormat("HW PLAN close valid: %s close %.5f melewati %.5f", PlanSnapshotBuy ? "BUY" : "SELL",
               bars[1].close, PlanSnapshotEntry);
   ExecuteConfirmedPlan();
}

void ExecuteConfirmedPlan()
{
   double point = SymbolInfoDouble(_Symbol, SYMBOL_POINT);
   double minDistance = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * point;
   double volumeStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(volumeStep <= 0)
   {
      SetVirtualPlanStatus("GAGAL - volume step tidak valid");
      return;
   }
   double sl = InpSLTPEnabled ? PlanSnapshotSL : 0;
   double tp = InpSLTPEnabled ? PlanSnapshotTP : 0;
   string group = "HW" + IntegerToString((long)TimeLocal()) + "_" +
                  IntegerToString((long)(GetMicrosecondCount() % 1000000));
   string stopKey = PlanStopRegistryPrefix() + group;
   while(GlobalVariableCheck(stopKey))
   {
      group = "HW" + IntegerToString((long)TimeLocal()) + "_" +
              IntegerToString((long)(GetMicrosecondCount() % 1000000));
      stopKey = PlanStopRegistryPrefix() + group;
   }
   // Store before sending orders, so even partially successful plans are tracked.
   // Signed SL: positive BUY, negative SELL. Terminal globals survive EA reloads.
   if(!GlobalVariableSet(stopKey, PlanSnapshotBuy ? PlanSnapshotSL : -PlanSnapshotSL))
   {
      SetVirtualPlanStatus("GAGAL - tidak dapat menyimpan batas invalidasi");
      return;
   }
   GlobalVariablesFlush();
   int successes = 0;
   for(int i = 0; i < PlanSnapshotLayers; i++)
   {
      MqlTick quote;
      if(!SymbolInfoTick(_Symbol, quote) || quote.ask <= 0 || quote.bid <= 0) break;
      if(PlanSLTouched(PlanSnapshotBuy, PlanSnapshotSL, quote.bid, quote.ask))
      {
         GlobalVariableSet(stopKey + "_X", 1.0);
         Print("HW PLAN: SL tersentuh saat pengiriman layer; hentikan pengiriman.");
         break;
      }
      double layerPrice = NormalizeDouble(PlanSnapshotEntry + (PlanSnapshotBuy ? -1 : 1) * i * PlanSnapshotGrid * point, _Digits);
      double lot = PlanSnapshotLot;
      double steppedLot = MathRound(lot / volumeStep) * volumeStep;
      if(lot < MinLot || lot > MaxLot || MathAbs(lot - steppedLot) > volumeStep * 0.00001)
      {
         PrintFormat("HW PLAN skip layer %d: lot %.8f tidak valid", i + 1, lot);
         continue;
      }
      // DIRECT: only layer 1 is immediate. RETEST: wait at base line using a limit.
      // If the live quote already touched the retest/layer level, execute at market.
      bool touched = PlanSnapshotBuy ? quote.ask <= layerPrice : quote.bid >= layerPrice;
      bool market = (PlanSnapshotEntryMode == HW_PLAN_DIRECT && i == 0) || touched;
      double entryPrice = market ? (PlanSnapshotBuy ? quote.ask : quote.bid) : layerPrice;
      double stopReference = market ? (PlanSnapshotBuy ? quote.bid : quote.ask) : layerPrice;
      bool validStops = !InpSLTPEnabled || (PlanSnapshotBuy
                       ? sl < stopReference && tp > stopReference && stopReference - sl >= minDistance && tp - stopReference >= minDistance
                       : sl > stopReference && tp < stopReference && sl - stopReference >= minDistance && stopReference - tp >= minDistance);
      if(!validStops || (!market && (PlanSnapshotBuy ? quote.ask - layerPrice < minDistance : layerPrice - quote.bid < minDistance)))
      {
         PrintFormat("HW PLAN skip layer %d: SL/TP atau jarak pending tidak valid (harga %.5f)", i + 1, entryPrice);
         continue;
      }
      trade.SetTypeFillingBySymbol(_Symbol);
      bool sent = false;
      string comment = StringFormat("%s %s L%d", group, PlanSnapshotEntryMode == HW_PLAN_DIRECT ? "DIR" : "RET", i + 1);
      if(market)
         sent = PlanSnapshotBuy ? trade.Buy(lot, _Symbol, 0, sl, tp, comment) : trade.Sell(lot, _Symbol, 0, sl, tp, comment);
      else
         sent = PlanSnapshotBuy ? trade.BuyLimit(lot, layerPrice, _Symbol, sl, tp, ORDER_TIME_GTC, 0, comment)
                                : trade.SellLimit(lot, layerPrice, _Symbol, sl, tp, ORDER_TIME_GTC, 0, comment);
      uint result = trade.ResultRetcode();
      bool accepted = sent && (result == TRADE_RETCODE_DONE || result == TRADE_RETCODE_PLACED || result == TRADE_RETCODE_DONE_PARTIAL);
      if(accepted) successes++;
      else PrintFormat("HW PLAN gagal layer %d: %u - %s", i + 1, result, trade.ResultRetcodeDescription());
   }
   PrintFormat("HW PLAN selesai: %d/%d layer diterima broker", successes, PlanSnapshotLayers);
   ProcessPlanPendingInvalidation();
   if(successes == PlanSnapshotLayers)
   {
      DeletePlanLines();
      PlaySound("ok.wav");
   }
   else
   {
      SetVirtualPlanStatus(StringFormat("%d/%d berhasil - deteksi OFF", successes, PlanSnapshotLayers));
      Alert("HW PLAN: ", successes, "/", PlanSnapshotLayers, " layer berhasil. Cek Experts; tidak ada retry otomatis.");
   }
}


// Pilih cara entry PLAN: lot setiap layer tetap sama.
void TogglePlanEntryMode()
{
   CurrentPlanEntryMode = CurrentPlanEntryMode == HW_PLAN_DIRECT ? HW_PLAN_RETEST : HW_PLAN_DIRECT;
   if(PlanArmed)
   {
      PlanArmed = false;
      SetVirtualPlanStatus("DRAFT - mode berubah, ARM lagi");
   }
   if(ObjectFind(0, ObjPlanModeBtn) >= 0)
   {
      ObjectSetString(0, ObjPlanModeBtn, OBJPROP_TEXT, CurrentPlanEntryMode == HW_PLAN_DIRECT ? "DIRECT" : "RETEST");
      ObjectSetInteger(0, ObjPlanModeBtn, OBJPROP_BGCOLOR, CurrentPlanEntryMode == HW_PLAN_DIRECT ? clrDodgerBlue : clrTeal);
   }
   UpdatePlanLabels();
   ChartRedraw();
}
