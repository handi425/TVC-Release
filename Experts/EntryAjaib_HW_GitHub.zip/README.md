# EntryAjaib HW

Expert Advisor untuk **MetaTrader 5**, ditulis dalam MQL5. Versi saat ini: **1.95**.

EntryAjaib HW menyediakan entry manual dan PLAN breakout dengan konfirmasi candle close. Pengguna menentukan level swing melalui garis yang dapat digeser, lalu memilih **DIRECT** atau **RETEST**. Lot setiap layer tetap sama.

## Fungsi utama

| Tombol / kontrol | Fungsi |
| --- | --- |
| BUY NOW / SELL NOW | Membuka satu posisi market menggunakan LOT aktif. Tidak menunggu konfirmasi PLAN. |
| PLAN BUY / PLAN SELL | Membuat garis breakout, SL, TP, dan preview layer. Menekan kembali arah PLAN yang sama menghapus PLAN. |
| ARM PLAN | Mengaktifkan deteksi breakout. Tidak langsung mengirim order. |
| CANCEL PLAN | Membatalkan deteksi yang sedang menunggu. Tidak menghapus pending order yang sudah dikirim setelah konfirmasi. |
| DIRECT / RETEST | Memilih cara entry setelah candle breakout close. Muncul bersama PLAN INFO. |
| LOT | Mengatur volume yang sama untuk setiap layer. |
| GRID | Mengatur jarak layer dalam **points**, bukan pips. |
| LYR | Mengatur jumlah layer PLAN. |
| TP ½ | Menutup sebagian volume posisi yang sedang profit; persentase mengikuti form TP ½. |
| BEP | Memindahkan SL ke harga pembukaan ditambah buffer profit, jika harga dan aturan broker memungkinkan. |
| CLOSE ALL | Menutup posisi pada simbol chart sesuai filter magic number dan hari pembukaan. Tidak menghapus pending order. |
| SHOW ON/OFF | Menampilkan atau menyembunyikan tombol, form, dan nama EA. |

Form SL/TP tidak tersedia di chart. Atur SL dan TP dengan menggeser garis PLAN. EA tidak mencari swing high/low secara otomatis.

## Konfirmasi breakout

- **BUY:** close candle sebelumnya berada di bawah atau tepat pada garis breakout, lalu candle yang baru selesai close **di atas** garis tersebut.
- **SELL:** close candle sebelumnya berada di atas atau tepat pada garis breakout, lalu candle yang baru selesai close **di bawah** garis tersebut.
- Wick yang melewati garis tetapi close kembali di sisi awal tidak memicu order.
- Close tepat pada garis belum dianggap breakout.
- Candle yang sudah selesai sebelum ARM PLAN ditekan tidak digunakan sebagai sinyal entry.

Dalam **10 detik terakhir**, EA menampilkan countdown dan status harga: breakout sementara, wick, atau belum breakout. Countdown tidak memicu entry. Konfirmasi diperiksa pada tick setelah candle benar-benar selesai.

## DIRECT dan RETEST

| Mode | Layer pertama | Layer berikutnya |
| --- | --- | --- |
| DIRECT | Market setelah breakout dikonfirmasi close. | Limit pada level GRID. |
| RETEST | Limit pada garis breakout setelah konfirmasi, untuk menunggu harga kembali. | Limit pada level GRID. |

Jika harga eksekusi sudah menyentuh level retest atau level layer, layer tersebut dapat dieksekusi sebagai market. BUY menggunakan Ask untuk pemeriksaan sentuh level entry; SELL menggunakan Bid. Setiap order tetap diperiksa terhadap lot, jarak pending, dan SL/TP yang diperbolehkan broker.

Untuk BUY, layer berikutnya berada di bawah garis breakout. Untuk SELL, layer berikutnya berada di atasnya. Seluruh layer menggunakan LOT tetap dan level SL/TP PLAN yang sama jika `InpSLTPEnabled` aktif.

## Invalidasi PLAN oleh SL

Garis SL juga menjadi batas invalidasi setup:

- Sebelum entry, PLAN dibatalkan jika BUY Bid menyentuh atau melewati SL, atau SELL Ask menyentuh atau melewati SL.
- Jika SL tersentuh saat pengiriman layer, pengiriman layer berikutnya dihentikan.
- Pending order yang masih tersisa dari kelompok PLAN tersebut dibatalkan ketika batas SL tersentuh atau posisi dalam kelompok terkena stop loss.
- Pembatalan pending dibatasi oleh tag PLAN, simbol, dan magic number. Penghapusan yang gagal akan dicoba kembali.

Batas invalidasi disimpan menggunakan terminal global variables. Garis SL tetap menjadi batas invalidasi PLAN meskipun pemasangan SL/TP order dinonaktifkan melalui `InpSLTPEnabled`.

## Cara menggunakan

1. Pilih PLAN BUY atau PLAN SELL.
2. Geser garis breakout ke swing high untuk BUY atau swing low untuk SELL.
3. Tempatkan garis SL pada swing lawan dan tentukan garis TP.
4. Atur LOT, GRID, dan LYR.
5. Pilih DIRECT atau RETEST di bawah PLAN INFO.
6. Tekan ARM PLAN dan tunggu candle close yang valid.

Mengubah garis, LOT, GRID, LYR, atau mode saat PLAN menunggu akan menonaktifkan deteksi. Tekan ARM PLAN lagi setelah perubahan selesai. Satu sinyal hanya diproses sekali. Jika sebagian layer gagal, hasil ditampilkan di tab Experts dan tidak dikirim ulang secara otomatis.

## Pengaturan input

| Input | Default | Keterangan |
| --- | --- | --- |
| `InpMagicNumber` | `0` | Identitas order EA. |
| `InpEntryLot` | `0.5` | LOT awal. |
| `InpLayerCount` | `5` | Jumlah layer awal. |
| `InpMultiStep` | `2500` | Jarak GRID awal dalam points. |
| `InpPlanEntryMode` | `HW_PLAN_DIRECT` | Mode awal; dapat diubah melalui tombol DIRECT/RETEST. |
| `InpPlanTimeframe` | `PERIOD_CURRENT` | Timeframe candle konfirmasi; CURRENT mengikuti chart. |
| `InpPlanWatchSeconds` | `10` | Durasi pemantauan countdown terakhir. |
| `InpSLTPEnabled` | `true` | Memasang SL/TP pada order yang dibuka. |
| `InpSLPoints` | `20000` | Jarak awal garis SL sebelum digeser. |
| `InpRewardRatio` | `2.0` | Rasio TP awal terhadap jarak SL. |
| `InpBEPProfitPoints` | `10000` | Buffer profit saat aksi BEP. |
| `InpCloseOwnOnly` | `true` | CLOSE ALL hanya untuk magic number EA. |
| `InpTodayOnly` | `true` | CLOSE ALL, BEP, dan TP partial hanya mengelola posisi yang dibuka hari ini menurut waktu broker. |
| `InpPushNotifPending` | `true` | Notifikasi ketika pending order EA tereksekusi. |
| `InpShowPanel` | `false` | Menampilkan panel statistik posisi; berbeda dari tombol SHOW. |

Pengaturan tambahan: `InpMaxMarginUsage` dan `InpMinMarginLevel` menentukan indikator informasi margin; keduanya bukan pembatas otomatis pengiriman order. `InpUIScale`, `InpUIFontDelta`, `InpUIAutoFit`, dan `TextColor` mengatur tampilan.

Panel statistik mencakup profit, jumlah layer BUY/SELL, volume, margin, dan waktu broker. EA juga menyediakan estimasi garis margin call dan zero balance serta pendeteksian akun cent.

## Instalasi dan compile

1. Buka MetaTrader 5, lalu pilih **File → Open Data Folder**.
2. Salin `EntryAjaib_HW.mq5` ke folder `MQL5/Experts/EntryAjaib_HW/`.
3. Buka file di MetaEditor dan tekan **F7** untuk menghasilkan `EntryAjaib_HW.ex5`.
4. Refresh Navigator MT5, lalu pasang EA pada chart.
5. Aktifkan Algo Trading dan izin trading EA untuk menggunakan fungsi pengiriman order.

Dependensi MQL5: `Trade/Trade.mqh`, yang tersedia pada instalasi MT5.

## Pemeriksaan kode

Jalankan pemeriksaan logika menggunakan Python:

```bash
python -m unittest discover -s tests -v
```

Pemeriksaan mencakup close breakout, wick, batas SL, pemilihan DIRECT/RETEST, pencegahan sinyal berulang, dan pembatalan pending berdasarkan kelompok PLAN. Pengujian ini membaca ekspresi pada source MQL5; tidak mengirim transaksi dan tidak menggantikan pengujian integrasi di Strategy Tester atau broker.

Verifikasi versi 1.95: compile MetaEditor **0 error, 0 warning** dan **8 uji logika lulus**.

## Isi repository

```text
EntryAjaib_HW.mq5
README.md
.gitignore
tests/
  test_hw_plan.py
```

File `.ex5` dihasilkan melalui compile dan dapat disertakan terpisah pada GitHub Releases.

Copyright pada source: **XoRonX G3DH3**. Repository ini belum menetapkan lisensi distribusi tambahan.
