"""Decision checks using expressions extracted from the actual MQL5 source.

These checks do not submit trades or replace MT5/broker integration testing.
Run: python -m unittest discover -s tests -v
"""
from pathlib import Path
import re
import unittest


SOURCE = (Path(__file__).resolve().parents[1] / "EntryAjaib_HW.mq5").read_text(
    encoding="utf-8-sig"
)


def body(name):
    match = re.search(r"(?:void|bool) " + name + r"\([^\n]*\)\s*\{", SOURCE)
    if not match:
        raise AssertionError(name)
    start = SOURCE.index("{", match.start())
    depth = 0
    tokens = r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|[{}]'
    for token in re.finditer(tokens, SOURCE[start:]):
        if token.group() == "{":
            depth += 1
        elif token.group() == "}":
            depth -= 1
            if depth == 0:
                return SOURCE[start + 1 : start + token.start()]
    raise AssertionError(name)


def evaluate(expression, **values):
    expression = expression.replace("&&", " and ").replace("||", " or ")
    return eval(expression, {"__builtins__": {}}, values)


class PlanInvalidationTests(unittest.TestCase):
    def test_sl_touch_boundaries_and_spread_side(self):
        expressions = re.findall(r"return\(([^;]+)\);", body("PlanSLTouched"))
        self.assertEqual(len(expressions), 3)
        for buy, bid, ask, expected in [
            (True, 101, 102, False),
            (True, 100, 101, True),  # Bid exactly at BUY SL; Ask still above.
            (True, 98, 99, True),    # Gap below SL.
            (False, 98, 99, False),
            (False, 99, 100, True),  # Ask exactly at SELL SL; Bid still below.
            (False, 101, 102, True), # Gap above SL.
        ]:
            with self.subTest(buy=buy, bid=bid, ask=ask):
                expression = expressions[1 if buy else 2]
                self.assertEqual(evaluate(expression, sl=100, bid=bid, ask=ask), expected)
        guard = re.search(r"if\(([^\n]+)\) return\(false\);", body("PlanSLTouched")).group(1)
        for sl, bid, ask in [(0, 99, 101), (100, 0, 101), (100, 99, 0)]:
            self.assertTrue(evaluate(guard, sl=sl, bid=bid, ask=ask))

    def test_sl_has_priority_over_breakout_and_each_layer(self):
        code = body("ProcessVirtualPlan")
        self.assertLess(code.index("InvalidateArmedPlanAtSL()"), code.index("PlanBreakoutConfirmed("))
        code = body("ExecuteConfirmedPlan")
        self.assertLess(code.index("PlanSLTouched("), code.index("trade.Buy("))
        self.assertIn('GlobalVariableSet(stopKey + "_X", 1.0)', code)
        self.assertIn("ProcessPlanPendingInvalidation();", code)

    def test_pending_cleanup_is_scoped_and_latched(self):
        code = body("ProcessPlanPendingInvalidation")
        deletion = code.index("trade.OrderDelete(ticket)")
        for guard in ['group + " "', 'ORDER_SYMBOL', 'ORDER_MAGIC', 'ORDER_TYPE_BUY_LIMIT',
                      'ORDER_TYPE_SELL_LIMIT', 'GlobalVariableCheck(invalidKey)']:
            self.assertLess(code.index(guard), deletion)
        self.assertIn('GlobalVariableSet(invalidKey, 1.0)', code)
        self.assertIn("if(!invalid) { remaining++; continue; }", code)
        self.assertIn("if(OrderSelect(ticket)) remaining++;", code)
        self.assertIn("remaining == 0 && !foreignOwner", code)
        # Broker SL detection must work independently of the notification toggle.
        transaction = SOURCE[SOURCE.index("void OnTradeTransaction("):]
        self.assertLess(transaction.index("InvalidatePlanFromStopLossDeal(trans.deal)"),
                        transaction.index("if(!InpPushNotifPending)"))


class ClosedCandleTests(unittest.TestCase):
    def test_close_confirmation_boundaries(self):
        expressions = re.findall(r"return\(([^;]+)\);", body("PlanBreakoutConfirmed"))
        self.assertEqual(len(expressions), 2)
        # Direction, previous close, closed close, expected signal.
        cases = [
            (True, 99, 101, True),
            (True, 100, 101, True),
            (True, 99, 100, False),
            (True, 99, 99.5, False),  # Wick above 100, close inside.
            (True, 101, 102, False),  # Already above: no new breakout.
            (True, 101, 99, False),
            (False, 101, 99, True),
            (False, 100, 99, True),
            (False, 101, 100, False),
            (False, 101, 100.5, False),  # Wick below 100, close inside.
            (False, 99, 98, False),
            (False, 99, 101, False),
        ]
        for buy, previous, close, expected in cases:
            with self.subTest(buy=buy, previous=previous, close=close):
                actual = evaluate(
                    expressions[0 if buy else 1], level=100,
                    previousClose=previous, closedClose=close,
                )
                self.assertEqual(actual, expected)

    def test_no_trade_from_countdown_or_arm(self):
        for name in ["OnTimer", "UpdateVirtualPlanWatch", "ToggleVirtualPlan"]:
            with self.subTest(function=name):
                code = body(name)
                self.assertNotIn("trade.", code)
                self.assertNotIn("ExecuteConfirmedPlan();", code)
                self.assertNotIn("ProcessVirtualPlan();", code)

    def test_fresh_closed_bar_and_single_signal_guards(self):
        code = body("ProcessVirtualPlan")
        self.assertIn("if(!PlanArmed) return;", code)
        self.assertIn("bars[1].time <= PlanLastClosedBar", code)
        self.assertIn("bars[1].time < PlanArmedBar", code)
        self.assertIn("bars[1].time + seconds > TimeCurrent()", code)
        self.assertIn("bars[2].close, bars[1].close", code)
        self.assertLess(code.index("PlanArmed = false; // Consume"), code.index("ExecuteConfirmedPlan();"))

    def test_direct_and_retest_layer_routing(self):
        code = body("ExecuteConfirmedPlan")
        expression = re.search(r"bool market = (.*);", code).group(1)
        for mode, layer, touched, expected in [
            (0, 0, False, True),  # Direct first layer enters after close.
            (0, 1, False, False),  # Subsequent layer waits on grid.
            (1, 0, False, False),  # Retest waits on base line.
            (1, 1, False, False),
            (1, 0, True, True),  # Retest already touched: market execution.
            (1, 1, True, True),
        ]:
            with self.subTest(mode=mode, layer=layer, touched=touched):
                self.assertEqual(evaluate(expression, PlanSnapshotEntryMode=mode,
                                          HW_PLAN_DIRECT=0, i=layer, touched=touched), expected)
        self.assertNotIn("BuyStop(", code)
        self.assertNotIn("SellStop(", code)
        self.assertIn("PlanSnapshotSL : 0", code)
        self.assertIn("PlanSnapshotTP : 0", code)

    def test_edit_and_cancel_do_not_leave_detection_active(self):
        self.assertIn("PlanArmed = false;", body("DeletePlanLines"))
        self.assertIn("PlanArmed = false;", body("ToggleVirtualPlan"))
        snapshot = body("VirtualPlanUnchanged")
        for setting in ["PlanSnapshotEntry", "PlanSnapshotSL", "PlanSnapshotTP",
                        "PlanSnapshotLot", "PlanSnapshotLayers", "PlanSnapshotGrid",
                        "PlanSnapshotEntryMode"]:
            self.assertIn(setting, snapshot)


if __name__ == "__main__":
    unittest.main()
