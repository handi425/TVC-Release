# Workspace chart HPX 2.10.2

Panduan pembelajaran menggunakan nama referensi netral. Pembersihan penyebutan merek kursus tidak mengubah materi, rumus, rasio, diagram, atau pengaturan alat. Lisensi dan atribusi open source tetap dipertahankan.

Toolbar atas memuat timeframe, HPX, ZWave, Live, Indikator, detail struktur, dan fokus chart. Tombol tema berada tepat di kiri Panduan dan diterapkan juga pada halaman panduan serta source/lisensi. Alat gambar berada di kiri chart, sedangkan rentang waktu dan jam WIB berada di bawah. Tombol di kiri logo memperluas sidebar atau merangkumnya menjadi ikon. Tema, lebar sidebar, dan konfigurasi indikator tersimpan pada browser/perangkat yang digunakan.

## Timeframe chart dan Radar

Tombol panah di samping timeframe membuka semua interval chart yang didukung. Klik bintang untuk memilih tombol yang tampil pada toolbar; interval terpilih tetap terlihat meski belum difavoritkan. Favorit disimpan per browser/perangkat. Pilihan ini terpisah dari **Pengaturan → Timeframe Radar & pemantauan**, sehingga perubahan favorit atau timeframe chart tidak mengubah interval scan.

Saat panel indikator dinonaktifkan, chart harga mengisi sisa tinggi layar. Alat gambar mempunyai scroll sendiri agar tidak memaksa ruang kosong. Panel aktif tetap dapat diatur tingginya.

## Indikator dan preset

Buka **Indikator → Standar** untuk menambahkan SMA, WMA, Bollinger Bands, MACD, ATR, ADX/DMI, VWAP, Supertrend, atau OBV. Indikator harga memakai chart utama; MACD, ATR, ADX/DMI, dan OBV mempunyai panel sendiri dengan pembatas yang dapat ditarik dan crosshair tersinkron. Beberapa salinan indikator yang sama dapat dipakai dengan periode berbeda. Batasnya 12 indikator tambahan.

Klik nama indikator aktif atau tombol pengaturan panel untuk mengubah parameter, nama, dan warna. **Simpan preset** menyimpan konfigurasi yang sedang diisi; **Preset Saya** dapat menambahkan salinan konfigurasi tersebut ke chart. Maksimal 24 preset. Hanya konfigurasi yang disimpan, bukan riwayat harga tambahan.

**Custom HPX** menghubungkan Harmonic Pattern X, ZWave, RSI Divergence, Stochastic Divergence, dan EMA multi-periode ke kontrol HPX yang sudah ada. HPX dan ZWave juga tersedia langsung di toolbar atas. Perhitungan RSI/Stochastic dari sumber MT5 pengguna tetap dipakai; studi tambahan tidak mengubah parameter Radar atau deteksi harmonic.

## Quarter Levels – S/R

Buka **Indikator → Custom HPX → Quarter Levels – S/R**. Indikator baru ini **nonaktif secara default**, termasuk pada profil lama yang belum pernah memakainya. **Atur** membuka pengaturan tanpa mengaktifkannya. Tombol Aktif/Nonaktif atau isian aktivasi pada dialog menentukan tampilannya; hanya pengaturan yang disimpan, bukan cache harga.

Grid otomatis memakai close harian sebelumnya dan minimum tick instrumen. Target jarak awal 0.625% dibulatkan ke kelipatan 1, 2, 2.5, 5, atau 10 dari pangkat sepuluh, dengan grid berpusat pada kelipatan nol ditambah offset global. Mode manual memakai anchor harga dan jarak level sendiri. **Kunci posisi level** menonaktifkan isian posisi; mode otomatis tetap mengikuti simbol serta referensi hariannya.

Deteksi memakai candle selesai pada timeframe yang dipilih, termasuk interval yang lebih kecil dari chart. Candle berturut-turut yang menyentuh zona dihitung sebagai satu kunjungan. Rejection support dan resistance disimpan terpisah; kunjungan yang telah dimulai sebelum batas lookback diabaikan. Candle berjalan tidak menambah hitungan. Level yang memenuhi jumlah minimum rejection pada sisi harga saat ini menjadi garis utuh dan lebih tebal; level lain putus-putus/transparan.

Saat harga diperbarui otomatis, grid terakhir tetap terlihat dengan status **Memperbarui Quarter Levels…** sampai data harian dan timeframe deteksi yang baru selesai dihitung. Hasil baru mengganti grid sekaligus; tidak ada cache harga tambahan di disk. Grid lama dibersihkan saat simbol/timeframe atau pengaturan berubah, indikator dimatikan, atau pembaruan Quarter gagal agar level yang tidak sesuai tidak ditampilkan.

Pengaturan meliputi toleransi sentuhan, jarak close konfirmasi, lookback, jumlah level, harga label dan hitungan S/R, offset label, ketebalan, transparansi dan tiga warna. Data harian/timeframe tambahan diambil langsung hanya ketika indikator aktif. Saat data tidak tersedia, status ditampilkan tanpa membuat candle pengganti. Grid mengikuti drag/zoom dan ikut ekspor PNG. Reference Pine asli disimpan di `reference/Quarter_Levels_reference.pine`.

## Alat gambar

- Pilih/geser, garis tren, ray/sinar, garis diperpanjang, garis panah, garis horizontal/vertikal, kanal paralel, kotak area, lingkaran/elips, Fibonacci retracement, penggaris, dan teks catatan.
- Gambar dengan dua klik atau tarik, menggunakan mouse maupun sentuhan. Mode pilih memungkinkan pemindahan objek dan titik anchor.
- Kanal paralel memakai tiga titik. Teks dapat diedit dengan klik ganda atau Enter; Ctrl+Enter menyimpan dan Escape membatalkan.
- Magnet menempelkan titik ke OHLC candle terdekat. Pemilih warna mengatur warna gambar baru.
- Undo/redo dan penghapusan dapat diurungkan. Ctrl+Z, Ctrl+Shift+Z, Delete, dan Escape bekerja saat chart atau toolbar mendapat fokus.
- Gambar tersimpan menurut grup, simbol, dan timeframe. Anchor memakai waktu candle dan posisi relatif, sehingga penambahan riwayat tidak menggeser objek ke candle yang salah.

Teks label divergence, Harmonic, dan ZWave tidak memakai border atau shadow. Overlay mengikuti perubahan skala selama drag/zoom tanpa menghitung ulang seluruh indikator.

Ekspor PNG menyertakan tema chart, indikator, garis divergence, dan gambar. Di ponsel, alat gambar menjadi baris yang dapat digulir; panel indikator tersedia melalui **Indikator & observasi sumber**.

## Harmonic manual XABC

Label zona menampilkan **PRZ · Nama Pola**. Pemilihan awal otomatis mendukung Gartley, Bat, Alternate Bat, Butterfly, Crab, Deep Crab, Shark, Cypher, dan 5-0. Stingray tersedia sebagai rute lanjutan Bat setelah PRZ Alternate Bat ditembus; pemilihan awal otomatis tetap memakai sembilan keluarga tersebut.

Pilih ikon **Harmonic manual XABC** pada toolbar gambar, lalu klik **X → A → B → C** dari kiri ke kanan pada candle yang berbeda. Titik **D** diproyeksikan otomatis. Garis dan label menampilkan XABCD, rasio, **AB=CD**, **ALT AB=CD 1.272**, **ALT AB=CD 1.618**, **PRZ**, dan **SL**, dengan nama keluarga hanya pada label PRZ. Gambar baru dapat ditambahkan pada chart yang sama; batas totalnya tetap 100 gambar per konteks chart.

AB=CD dihitung dari `C + (B − A)`; ALT memakai pengali 1.272 dan 1.618. PRZ mengikuti konfluensi proyeksi pada referensi Manual HP pengguna. Jika konfluensi belum valid, titik dan proyeksi AB=CD tetap dapat diedit dengan penjelasan status. SL mengikuti batas invalidasi/HOP HPX dan pengali jarak dari sisi jauh PRZ. Untuk aturan yang tidak memiliki HOP, jarak dasar mengikuti buffer HPX 5% XA, minimum satu tick.

Pilih pola, lalu gunakan tombol **Pengaturan gambar terpilih**, klik ganda, atau Enter untuk mengatur toleransi rasio, panjang level, pengali jarak SL, serta kapan ALT tampil. Toleransi 0.03 berarti toleransi rasio absolut. Pengaturan berlaku hanya untuk pola tersebut. Titik X/A/B/C dapat ditarik satu per satu, dan bentuk dapat digeser seluruhnya. D mengikuti proyeksi; sentuhan pertama membekukan posisinya. Close candle selesai melewati sisi jauh PRZ menandai **PRZ ditembus**; wick candle berjalan tidak membatalkan zona. Gambar historis tetap tersimpan sampai dihapus pengguna.

Perhitungan proyeksi disimpan di memori dan dipakai ulang selama zoom. Autoscale memasukkan level manual yang relevan meskipun HPX otomatis dimatikan. Skala harga manual tetap dapat digunakan; **Pas-kan chart** mengembalikan autoscale. Saat peningkatan, gambar lama dimigrasikan ke penyimpanan baru dan salinan lama dipertahankan agar tab versi sebelumnya tidak menimpa pola baru. Yang tersimpan adalah anchor dan pengaturan gambar, bukan cache candle.

## Pergantian PRZ Bat

Pola yang berawal sebagai **Bat** mengikuti **Bat → Alternate Bat → Stingray**, memakai XABC yang sama. Pergantian hanya dipicu close candle selesai melewati sisi jauh PRZ aktif: di bawah zona bullish atau di atas zona bearish. Wick, candle berjalan, dan engulfing saja tidak memindahkan tahap. Riwayat diproses berurutan sejak C, sehingga pola tersimpan juga mengikuti break historis yang sudah terjadi.

Hanya satu PRZ, SL, dan D tahap aktif yang digambar. Setelah promosi, PRZ/SL lama hilang dan diganti dengan level baru. AB=CD dan ALT tetap berasal dari XABC semula. Tahap baru tidak mewarisi sentuhan wick sebelum aktivasinya. Gap close yang sekaligus menembus dua zona valid dapat memproses dua tahap pada candle yang sama.

Alternate Bat lanjutan mewarisi kelayakan Bat, tetapi tetap memerlukan irisan XA/BC yang valid. Jika belum valid, zona lama dihapus dan pesan meminta penyesuaian titik/toleransi; Stingray ditahan. Setelah PRZ Stingray ditembus, rute berakhir tanpa zona/D/SL aktif. Gambar XABC dan proyeksi AB=CD tetap dapat diedit. Aturan rute ini khusus pola yang berawal sebagai Bat.

## Elliott Wave Manual

Pilih **Elliott Wave manual** pada toolbar gambar, lalu pilih **1–2–3–4–5**, **A–B–C**, **A–B–C–D–E**, **W–X–Y**, atau **W–X–Y–X–Z**. Tempatkan titik awal **0**, kemudian titik wave berurutan dari kiri ke kanan. X kedua pada urutan triple ditampilkan sebagai X dan disimpan sebagai anchor X2 agar dasar ukur tidak tertukar.

Pola tidak harus lengkap. Setelah sedikitnya dua titik ditempatkan, gunakan **Simpan wave sementara (Enter)**, Enter, atau klik ganda untuk menyimpan titik yang sudah dipilih. Setelah 0–1–2, ukuran dan jalur proyeksi 3–4–5 sudah dapat ditampilkan. Pilih pola lalu **Lanjutkan titik Elliott** untuk menambahkan titik berikutnya pada objek yang sama; **Urungkan titik Elliott terakhir** menghapus titik terakhir. Escape membatalkan draft tanpa menghapus pola tersimpan. Undo/redo tetap berlaku.

Klik ganda objek, klik kanan → **Pengaturan**, atau roda gigi untuk memilih varian pola, kelas **Paling umum**, **Umum**, **Acuan konstruksi**, atau **Semua ukuran** yang tersedia. Ukuran per wave dapat dipilih tersendiri dari sumber rasio. Pola yang sumbernya tidak mempunyai peringkat frekuensi memakai Acuan; tidak diberi peringkat buatan. Angka tunggal tetap garis dan interval tetap interval aslinya, tanpa tambahan toleransi.

Titik yang ditempatkan pengguna memakai garis utama, sedangkan titik/jalur berikutnya memakai garis putus-putus dan label **proyeksi**. Proyeksi berikutnya memakai titik sebelumnya yang mungkin juga masih berupa proyeksi, sehingga semuanya bersyarat. Posisi mendatar proyeksi hanya tata letak, bukan perkiraan waktu pasar. Batas struktur disesuaikan dengan titik manual; ukuran di luar batas diberi penjelasan, bukan dianggap valid.

Fibonacci pada wave yang sudah ditempatkan ditulis di dekat titik wave, dengan rasio aktual dan urutan anchor pengukurnya. Wave dasar ditandai 100% basis; ini bukan target atau bukti konfirmasi pasar. C Zigzag memakai Larry Pull dua titik sesuai acuan, sedangkan alternatif tiga titik pada Flat tetap memakai dasar yang berbeda. Wave 5 Impulse mempertahankan dasar neto 0→3 dari titik 4.

**Trendline** dan **Channeling** dapat diaktifkan secara terpisah pada pengaturan objek; keduanya **nonaktif secara default**. Garis yang memakai titik proyeksi tetap ditandai bersyarat. Warna, ketebalan, label, koordinat dan panjang tampilan proyeksi dapat diatur. Gambar lama dan salinan penyimpanannya dipertahankan saat migrasi.

## Fokus chart Android dan ponsel

Tombol **Fokus chart** tersedia di toolbar chart pada Android dan layar kecil. Mode ini memenuhi area aplikasi dengan chart dan alat gambar, termasuk panel RSI/Stochastic/indikator tambahan yang aktif. Tombol **Keluar** tetap terlihat. Perubahan orientasi menyesuaikan ukuran chart; keluar fokus mengembalikan susunan panel sebelumnya.

Back/Escape menutup dialog atau menu yang terbuka terlebih dahulu, kemudian keluar dari fokus sebelum berpindah layar. Pengaturan indikator dan gambar tetap bisa dibuka dalam mode fokus. Bila fullscreen native tidak tersedia, layout fokus tetap bekerja di dalam viewport aplikasi. Status fokus tidak dipertahankan saat membuka ulang aplikasi.

## Pengaturan semua alat gambar

**Klik ganda** garis/objek, **klik kanan → Pengaturan**, tombol gear saat objek dipilih, atau Enter membuka dialog pengaturan alat tersebut. Pengaturan mencakup warna, ketebalan dan gaya garis, opasitas, label, serta koordinat waktu WIB/harga yang relevan. Bentuk memiliki pengaturan isi; teks memiliki isian dan ukuran/gaya huruf; Fibonacci memiliki level yang dapat diubah. Harmonic memiliki pengaturan tampilan dan warna PRZ/AB=CD/SL, selain toleransi, panjang level, dan pengali SL.

Perubahan diterapkan ke objek terpilih dalam satu langkah undo. Batal mempertahankan nilai sebelumnya. Waktu baru harus sesuai candle yang tersedia; perubahan harga atau waktu anchor harmonic menghitung ulang proyeksi dan rutenya. Klik kanan juga menyediakan penghapusan objek yang dapat diurungkan.

## Live dan penyimpanan harga

Chart meminta data langsung menggunakan `no_cache=true` pada setiap pemuatan dan pembaruan. Jalur ini tidak membaca/menulis cache candle SQLite, tidak menggabungkan riwayat Investing yang tersimpan, tidak memakai fallback harga lama jika penyedia gagal, dan tidak menyimpan hasil ke cache analisis. Data chart aktif tetap berada di memori untuk ditampilkan dan dihitung.

**Live** memperbarui chart setiap 15/30/60/120 detik; interval awal 30 detik. Permintaan tidak bertumpuk. Pembaruan dijeda saat tab tidak terlihat, tampilan Radar aktif, gambar sedang dikerjakan, atau chart sedang digeser/di-zoom. Posisi horizontal, skala harga manual, pilihan pola, dan isian pengaturan yang belum diterapkan dipertahankan selama pembaruan.

Waktu bar, observasi sumber, dan waktu pengambilan tetap ditampilkan. Kesegaran harga mengikuti endpoint publik Yahoo Finance/Investing; interval polling bukan jaminan streaming tick broker. Kegagalan pembaruan diberi label dan dicoba lagi pada interval berikutnya.

Pengaturan, preset, Favorit, dan anotasi tetap disimpan. Cache lama tidak dihapus. Radar dan pemantauan Favorit mempertahankan jalur cache yang sudah ada; pengaturan TTL diberi label khusus untuk kedua fitur tersebut.

## Perhitungan studi tambahan

Pemanasan ditampilkan sebagai ruang kosong. Perhitungan tidak memakai candle masa depan. Bollinger menggunakan deviasi standar populasi; ATR dan ADX/DMI memakai penghalusan Wilder secara awal; MACD menyediakan tipe rata-rata EMA/SMA. EMA MACD dimulai dari nilai sumber pertama, berbeda dari seed SMA pada EMA HPX yang sudah ada.

VWAP memakai kalender zona waktu bursa untuk reset anchor dan menampilkan catatan keterbatasan sesi. Jika timeframe lebih kasar daripada anchor, atau volume yang diperlukan tidak tersedia, indikator menampilkan alasan ketidaktersediaan. OBV juga membutuhkan volume yang benar-benar disediakan sumber. Tidak ada volume atau nilai indikator buatan untuk mengisi data yang hilang.

Referensi rumus: [Bollinger Bands](https://www.tradingview.com/support/solutions/43000501840-bollinger-bands-bb/), [MACD](https://www.tradingview.com/support/solutions/43000502344-moving-average-convergence-divergence-macd-indicator/), [ATR](https://www.tradingview.com/support/solutions/43000501823-average-true-range-atr/), [ADX](https://www.tradingview.com/support/solutions/43000589099-average-directional-index-adx/), [VWAP](https://www.tradingview.com/support/solutions/43000502018-volume-weighted-average-price-vwap/), [Supertrend](https://www.tradingview.com/support/solutions/43000634738-supertrend/), dan [OBV](https://www.tradingview.com/support/solutions/43000502593-on-balance-volume-obv/).
