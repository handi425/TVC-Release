# Memilih pola pemindai HPX 2.7.0

Pengaturan ini tersedia pada Android dan Windows.

1. Buka **Radar → Pola scan**, atau **Pengaturan → Pola aktif untuk scan**.
2. Aktifkan/nonaktifkan sakelar masing-masing pola. Gunakan **Aktifkan semua** atau **Nonaktifkan semua** bila diperlukan.
3. Tekan **Simpan pengaturan**. Tombol Batal menutup perubahan yang belum disimpan.
4. Jalankan scan baru. Radar menampilkan jumlah pola aktif dan nama-namanya.

Pilihan yang tersedia: Alternate Bat, Bat, Butterfly, Crab, Gartley, Deep Crab, Shark, Cypher, dan Stingray. Sakelar Shark mencakup empat varian; Cypher mencakup dua varian. Pilihan berlaku bagi arah bullish dan bearish.

Stingray mengikuti transisi **Bat → Alternate Bat → Stingray** pada mesin HPX. Aktifkan ketiganya untuk mendeteksi transisi tersebut.

Pilihan disimpan untuk analisis Chart, Radar, dan pemantauan PRZ. Sakelar Harmonic pada Chart mengatur tampilan di chart secara terpisah. Pola yang hanya tersedia sebagai materi Panduan tidak menjadi pilihan pemindai.

Setelah pilihan berubah, hasil Radar lama dibersihkan dan respons scan lama diabaikan. Notifikasi tertunda dari pengaturan sebelumnya dibuang; riwayat notifikasi yang telah tercatat tetap tersedia. Pemantauan memulai baseline baru agar sentuhan historis tidak memicu pemberitahuan baru.

Jika semua pola nonaktif, tombol Mulai scan dinonaktifkan. Buka Pola scan untuk mengaktifkan pola kembali. Pada pengaturan lama yang belum memiliki pilihan pola, seluruh pola aktif secara bawaan.
