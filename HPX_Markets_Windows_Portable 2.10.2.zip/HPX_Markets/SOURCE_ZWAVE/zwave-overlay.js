/*
 * This Source Code Form is subject to the Mozilla Public License, v. 2.0.
 * https://mozilla.org/MPL/2.0/
 * ZWave - Triangle and PDF Fibonacci, XoRonX | Mr Poleks.
 * HPX chart renderer and settings for the supplied ZWave Pine source.
 */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.HPXZWave = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const FIELDS = [{"type":"float","default":2.5,"min":1e-05,"max":100.0,"key":"deviation","label":"Deviasi pembalikan besar (%)","group":"ZigZag"},{"type":"int","default":10,"min":2,"max":200,"key":"depth","label":"Kaki pivot besar","group":"ZigZag"},{"type":"float","default":3.0,"min":1.01,"max":20.0,"key":"factor","label":"Pembagi deviasi child / micro","group":"ZigZag"},{"type":"int","default":4,"min":2,"max":100,"key":"child_depth","label":"Kaki pivot child","group":"ZigZag"},{"type":"int","default":5000,"min":300,"max":5000,"key":"history_bars","label":"Candle selesai yang dianalisis","group":"ZigZag"},{"type":"bool","default":false,"key":"show_zigzag","label":"Gambar ZigZag child","group":"Wave display"},{"type":"bool","default":false,"key":"show_micro","label":"Tampilkan label micro","group":"Wave display"},{"type":"bool","default":true,"key":"show_developing","label":"Tampilkan counting berkembang (?)","group":"Wave display"},{"type":"bool","default":true,"key":"show_panel","label":"Panel status struktur","group":"Wave display"},{"type":"int","default":24,"min":2,"max":100,"key":"visible_major","label":"Jumlah pivot besar yang ditampilkan","group":"Wave display"},{"type":"string","default":"Small","options":["Tiny","Small","Normal","Large","Huge"],"key":"wave_font_size","label":"Large / child wave font size","group":"Wave text"},{"type":"string","default":"Tiny","options":["Tiny","Small","Normal","Large","Huge"],"key":"micro_font_size","label":"Child-of-child wave font size","group":"Wave text"},{"type":"float","default":0.05,"min":0.0,"max":1.0,"key":"lower_wave_gap","label":"Extra spacing below waves (ATR)","group":"Wave text","step":0.05,"tooltip":"Adds space between lower wave labels and candle wicks, scaled by ATR(14). Upper wave labels keep their existing spacing."},{"type":"color","default":"#FF1493","key":"large_wave_text_color","label":"Large wave text color","group":"Wave text"},{"type":"color","default":"#00BCD4","key":"child_wave_text_color","label":"Child wave text color","group":"Wave text"},{"type":"color","default":"#B2B5BE","key":"micro_wave_text_color","label":"Child-of-child wave text color","group":"Wave text"},{"type":"bool","default":true,"key":"show_large_fib","label":"Large ZigZag Fibonacci","group":"Fibonacci"},{"type":"bool","default":true,"key":"show_child_fib","label":"Child ZigZag Fibonacci","group":"Fibonacci"},{"type":"int","default":1,"min":1,"max":5,"key":"child_fib_legs","label":"Recent child swings with Fibonacci","group":"Fibonacci"},{"type":"color","default":"#708090","key":"large_fib_color","label":"Large Fibonacci color","group":"Fibonacci"},{"type":"color","default":"#48D1CC","key":"child_fib_color","label":"Child Fibonacci color","group":"Fibonacci"},{"type":"int","default":1,"min":1,"max":5,"key":"fib_line_width","label":"Fibonacci line width","group":"Fibonacci"},{"type":"string","default":"Dotted","options":["Solid","Dashed","Dotted"],"key":"fib_line_style","label":"Fibonacci line style","group":"Fibonacci"},{"type":"string","default":"Tiny","options":["Tiny","Small","Normal","Large","Huge"],"key":"large_fib_font_size","label":"Large Fibonacci font size","group":"Fibonacci text"},{"type":"string","default":"Tiny","options":["Tiny","Small","Normal","Large","Huge"],"key":"child_fib_font_size","label":"Child Fibonacci font size","group":"Fibonacci text"},{"type":"color","default":"#708090","key":"large_fib_text_color","label":"Large Fibonacci text color","group":"Fibonacci text"},{"type":"color","default":"#48D1CC","key":"child_fib_text_color","label":"Child Fibonacci text color","group":"Fibonacci text"},{"type":"string","default":"Right","options":["Left","Right"],"key":"large_fib_text_alignment","label":"Large Fibonacci text alignment","group":"Fibonacci text","tooltip":"Right places text after the line endpoint with a gap; text stays centered on its exact Fibonacci price."},{"type":"string","default":"Right","options":["Left","Right"],"key":"child_fib_text_alignment","label":"Child Fibonacci text alignment","group":"Fibonacci text","tooltip":"Right places text after the line endpoint with a gap. Coincident ratios are combined."},{"type":"int","default":1,"min":0,"max":20,"key":"fib_text_shift","label":"Fibonacci text shift right (bars)","group":"Fibonacci text"},{"type":"int","default":20,"min":0,"max":100,"key":"fib_right_extension","label":"Fibonacci right extension (bars)","group":"Fibonacci","tooltip":"Finite extension of the latest large and child Fibonacci lines beyond the rightmost visible candle. Right-aligned text begins after the line endpoint. Older child Fibonacci lines stay within their own swing."},{"type":"int","default":80000,"min":10000,"max":200000,"key":"work_limit","label":"Batas kandidat pencarian geometri","group":"Performance","step":10000.0,"tooltip":"Limits candidate edges per refresh. When exhausted, dense structures remain unresolved. This is a display/performance limit, not an Elliott rule."},{"type":"bool","default":true,"key":"show_hidden","label":"Deteksi hidden divergence","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"hidden_large","label":"Hidden divergence Large","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"hidden_child","label":"Hidden divergence Child","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"hidden_micro","label":"Hidden divergence Micro","group":"Hidden MACD divergence"},{"type":"int","default":5,"min":1,"max":4000,"key":"hidden_min_bars","label":"Jarak minimum pivot searah (candle)","group":"Hidden MACD divergence"},{"type":"int","default":500,"min":1,"max":4000,"key":"hidden_max_bars","label":"Jarak maksimum dari anchor awal","group":"Hidden MACD divergence"},{"type":"int","default":100,"min":1,"max":100,"key":"hidden_max_signals","label":"Maksimum sinyal hidden ditampilkan","group":"Hidden MACD divergence","tooltip":"Elliott and Fibonacci drawings keep priority within TradingView's 500-line/label limits."},{"type":"bool","default":false,"key":"hidden_same_side_of_zero","label":"Low di bawah / high di atas MACD nol","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"hidden_use_swing_extremes","label":"Bandingkan ekstrem MACD pada kaki masuk","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"hidden_show_labels","label":"Label HBull/HBear dan degree","group":"Hidden MACD divergence"},{"type":"color","default":"#00BFFF","key":"hidden_bull_color","label":"Hidden bullish color","group":"Hidden MACD divergence"},{"type":"color","default":"#FF9800","key":"hidden_bear_color","label":"Hidden bearish color","group":"Hidden MACD divergence"},{"type":"bool","default":true,"key":"pf_enabled","label":"Fibonacci otomatis dari counting ZWave","group":"Fibonacci PDF - otomatis"},{"type":"string","default":"Child","options":["Child","Large"],"key":"pf_degree","label":"Degree target otomatis","group":"Fibonacci PDF - otomatis"},{"type":"string","default":"Wave aktif/terakhir","options":["Wave aktif/terakhir","Wave berikutnya"],"key":"pf_view","label":"Target yang ditampilkan","group":"Fibonacci PDF - otomatis","tooltip":"Wave aktif/terakhir mengevaluasi wave yang dilabeli. Pada wave 1/A, tampilkan target bersyarat 2/B karena PDF tidak memberi target langsung untuk 1/A. Mode berikutnya berhenti setelah 5/C/E."},{"type":"string","default":"Larry Pull","options":["Larry Pull","Trend Based W3/C"],"key":"pf_method","label":"Metode PDF","group":"Fibonacci PDF - otomatis","tooltip":"Larry: W3/C memakai 0 di origin dan 1 di ujung W1/A. W5 memakai 0 di akhir W4 dan 1 di akhir W3. Trend Based W3/C memproyeksikan panjang W1/A dari W2/B. W5 tetap Larry; istilah Wave1-3 di PDF tidak mendefinisikan anchor dengan tegas."},{"type":"bool","default":true,"key":"pf_tu","label":"Tak umum (Uncommon)","group":"Fibonacci PDF - kategori"},{"type":"bool","default":true,"key":"pf_pu","label":"Paling umum (Most Common)","group":"Fibonacci PDF - kategori"},{"type":"bool","default":true,"key":"pf_u","label":"Umum (Common)","group":"Fibonacci PDF - kategori"},{"type":"bool","default":true,"key":"pf_su","label":"Sangat umum (Very Common, Wave C)","group":"Fibonacci PDF - kategori"},{"type":"bool","default":false,"key":"pf_rare","label":"Langka (Rare, jika tercantum)","group":"Fibonacci PDF - kategori"},{"type":"bool","default":true,"key":"pf_allow_developing","label":"Izinkan counting berkembang (?)","group":"Fibonacci PDF - otomatis"},{"type":"bool","default":true,"key":"pf_hide_swing_fib","label":"Ganti grid Fibonacci swing dengan target PDF","group":"Fibonacci PDF - otomatis"},{"type":"bool","default":true,"key":"pf_shade","label":"Arsir zona target sesuai kategori PDF","group":"Fibonacci PDF - tampilan"},{"type":"bool","default":true,"key":"pf_panel_on","label":"Tampilkan ringkasan target dan anchor","group":"Fibonacci PDF - tampilan"},{"type":"int","default":20,"min":5,"max":100,"key":"pf_forward","label":"Panjang target ke kanan (candle)","group":"Fibonacci PDF - tampilan"},{"type":"color","default":"#607D8B","key":"pf_tu_color","label":"Warna Tak umum","group":"Fibonacci PDF - tampilan"},{"type":"color","default":"#B8860B","key":"pf_pu_color","label":"Warna Paling umum","group":"Fibonacci PDF - tampilan"},{"type":"color","default":"#228B22","key":"pf_u_color","label":"Warna Umum","group":"Fibonacci PDF - tampilan"},{"type":"color","default":"#E67E22","key":"pf_su_color","label":"Warna Sangat umum","group":"Fibonacci PDF - tampilan"},{"type":"bool","default":true,"key":"zt_triangles","label":"Deteksi Triangle ABCDE","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"zt_boundaries","label":"Gambar batas pola otomatis","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"zt_abc","label":"Sertakan batas Flat / Zigzag ABC","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"zt_large","label":"Pindai degree Large","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"zt_child","label":"Pindai degree Child","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"zt_legs","label":"Kaki Triangle dan label ABCDE","group":"Triangle and pattern boundaries"},{"type":"bool","default":false,"key":"zt_strict","label":"Hanya pola dengan bukti subdivisi (S)","group":"Triangle and pattern boundaries","tooltip":"G = geometry candidate. S = all child legs proved. Parent wave 4/B/X placement is not verified. Only settled endpoints with a later opposite pivot are scanned."},{"type":"int","default":20,"min":0,"max":200,"key":"zt_projection","label":"Panjang batas setelah pola (candle)","group":"Triangle and pattern boundaries"},{"type":"int","default":2,"min":1,"max":2,"key":"zt_max","label":"Pola terakhir per keluarga / degree","group":"Triangle and pattern boundaries"},{"type":"float","default":5.0,"min":0.5,"max":10.0,"key":"zt_tolerance","label":"Toleransi barrier Triangle (% wave A)","group":"Triangle and pattern boundaries","step":0.5},{"type":"bool","default":true,"key":"zt_status","label":"Status deteksi pola","group":"Triangle and pattern boundaries"},{"type":"color","default":"#7B1FA2","key":"zt_large_color","label":"Large pattern color","group":"Triangle and pattern boundaries"},{"type":"color","default":"#00796B","key":"zt_child_color","label":"Child pattern color","group":"Triangle and pattern boundaries"},{"type":"bool","default":true,"key":"pj_enabled","label":"Tampilkan proyeksi arah berikutnya","group":"Proyeksi arah berikutnya"},{"type":"string","default":"Ikuti Fibonacci PDF","options":["Ikuti Fibonacci PDF","Child","Large"],"key":"pj_scope","label":"Degree proyeksi","group":"Proyeksi arah berikutnya"},{"type":"string","default":"Paling umum","options":["Tak umum","Paling umum","Umum","Terdekat dari semua kategori"],"key":"pj_class","label":"Kategori target utama","group":"Proyeksi arah berikutnya"},{"type":"bool","default":true,"key":"pj_fallback","label":"Gunakan kategori lain bila target utama terlewati","group":"Proyeksi arah berikutnya"},{"type":"bool","default":true,"key":"pj_developing","label":"Izinkan skenario dari counting (?)","group":"Proyeksi arah berikutnya"},{"type":"bool","default":true,"key":"pj_alternative","label":"Alternatif setelah 5 / C / Triangle E","group":"Proyeksi arah berikutnya"},{"type":"bool","default":true,"key":"pj_show_levels","label":"Tampilkan pemicu dan invalidasi skenario","group":"Proyeksi arah berikutnya"},{"type":"bool","default":true,"key":"pj_show_panel","label":"Panel arah dan status skenario","group":"Proyeksi arah berikutnya"},{"type":"int","default":30,"min":10,"max":100,"key":"pj_horizon","label":"Panjang gambar ke kanan (candle)","group":"Proyeksi arah berikutnya","tooltip":"Jumlah candle hanya panjang gambar, bukan prediksi waktu harga mencapai target. Jalur menunjukkan skenario arah, bukan urutan candle masa depan."},{"type":"float","default":2.0,"min":0.5,"max":5.0,"key":"pj_visual_atr","label":"Panjang panah tanpa target PDF (ATR)","group":"Proyeksi arah berikutnya","step":0.25,"tooltip":"Setelah 5/C/E, gunakan referensi struktur atau panah arah dengan panjang visual ATR. Tidak dianggap target Fibonacci PDF."},{"type":"color","default":"#00897B","key":"pj_bull","label":"Warna proyeksi naik","group":"Proyeksi arah berikutnya"},{"type":"color","default":"#C62828","key":"pj_bear","label":"Warna proyeksi turun","group":"Proyeksi arah berikutnya"}];
  const DEFAULTS = Object.freeze(Object.fromEntries([['enabled',true],...FIELDS.map(f=>[f.key,f.default])]));
  const GROUP_LABELS = {
    'ZigZag':'ZigZag & cakupan analisis',
    'Wave display':'Counting Elliott', 'Wave text':'Teks wave',
    'Fibonacci':'Fibonacci swing', 'Fibonacci text':'Teks Fibonacci swing',
    'Performance':'Batas pencarian', 'Hidden MACD divergence':'Hidden divergence MACD',
    'Fibonacci PDF - otomatis':'Target Fibonacci', 'Fibonacci PDF - kategori':'Kategori warna target',
    'Fibonacci PDF - tampilan':'Tampilan target Fibonacci',
    'Triangle and pattern boundaries':'Triangle & batas pola',
    'Proyeksi arah berikutnya':'Skenario arah berikutnya'
  };
  const FONT_SIZES={Tiny:8,Small:10,Normal:12,Large:15,Huge:18};
  const escape = value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const finite=value=>value!==null&&value!==undefined&&value!==''&&Number.isFinite(Number(value));
  const clamp=(value,min,max)=>Math.min(max,Math.max(min,value));
  const safeColor = value=>typeof value==='string'&&/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(value)?value:'#9fb3ca';
  const displayText = value=>String(value??'').replace(/Fibonacci PDF/gi,'Fibonacci').replace(/\bPDF\b/g,'Fibonacci').replace(/\s+/g,' ').trim();
  const CATEGORY_COLORS={pf_tu:'pf_tu_color',pf_pu:'pf_pu_color',pf_u:'pf_u_color',pf_su:'pf_su_color',pf_rare:null};
  const mergeConfig = value=>({...DEFAULTS,...(value&&typeof value==='object'&&!Array.isArray(value)?value:{})});
  const number=value=>Math.round(Number(value)*100)/100;

  function settingsHTML(config) {
    const cfg=mergeConfig(config),groups=new Map();
    for(const field of FIELDS){if(!groups.has(field.group))groups.set(field.group,[]);groups.get(field.group).push(field);}
    const input=field=>{
      const key=field.key,id='zwave-setting-'+key,value=cfg[key],title=field.tooltip?` title="${escape(displayText(field.tooltip))}"`:'';
      const swatch=Object.hasOwn(CATEGORY_COLORS,key)?`<i aria-hidden="true" style="display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:7px;background:${safeColor(CATEGORY_COLORS[key]?cfg[CATEGORY_COLORS[key]]:'#FF00FF')}"></i>`:'';
      if(field.type==='bool')return `<label class="toggle-setting zwave-toggle"><div><b>${swatch}${escape(displayText(field.label))}</b></div><input id="${id}" data-zwave-setting="${key}" type="checkbox"${value?' checked':''}${title}><span class="switch"></span></label>`;
      let control;
      if(field.options)control=`<select id="${id}" data-zwave-setting="${key}"${title}>${field.options.map(option=>`<option value="${escape(option)}"${value===option?' selected':''}>${escape(displayText(option))}</option>`).join('')}</select>`;
      else if(field.type==='color')control=`<input id="${id}" data-zwave-setting="${key}" type="color" value="${safeColor(value).slice(0,7)}"${title}>`;
      else control=`<input id="${id}" data-zwave-setting="${key}" type="number" value="${escape(value)}"${finite(field.min)?` min="${field.min}"`:''}${finite(field.max)?` max="${field.max}"`:''} step="${field.type==='int'?1:field.step||'any'}" required${title}>`;
      return `<label class="zwave-field${field.type==='color'?' zwave-color-field':''}" for="${id}"><span>${escape(displayText(field.label))}</span>${control}</label>`;
    };
    return `<label class="toggle-setting"><div><b>Tampilkan ZWave</b><small>Counting Elliott, Triangle, Fibonacci, dan hidden divergence.</small></div><input id="zwave-enabled-input" data-zwave-setting="enabled" type="checkbox"${cfg.enabled?' checked':''}><span class="switch"></span></label><p class="field-note">Menggunakan candle selesai. Label ? masih berkembang; G adalah kandidat geometri, S memiliki bukti subdivisi. Posisi parent wave belum diverifikasi. Panah adalah skenario arah, bukan candle masa depan. Kategori target pada chart ditandai dengan warna; penjelasannya tersedia di Panduan Elliott Wave.</p>`+
      [...groups].map(([name,fields])=>`<details class="zwave-setting-group"${name==='ZigZag'?' open':''}><summary>${escape(displayText(GROUP_LABELS[name]||name))}</summary><div class="zwave-settings-fields">${fields.map(input).join('')}</div></details>`).join('');
  }
  function readSettings(host,previous) {
    const cfg=mergeConfig(previous),schema=new Map(FIELDS.map(f=>[f.key,f]));
    for(const input of host.querySelectorAll('[data-zwave-setting]')){
      const key=input.dataset.zwaveSetting,field=schema.get(key);
      if(key==='enabled'||field?.type==='bool')cfg[key]=!!input.checked;
      else if(field?.type==='int'||field?.type==='float')cfg[key]=Number(input.value);
      else if(field)cfg[key]=input.value;
    }
    return cfg;
  }

  /** Return SVG with projected logical indices on the existing candle price scale. */
  function buildOverlay(data,{width,height,plotRight=width-74,plotBottom=height-25,visibleRange,x,y}={}) {
    if(!data||data.enabled===false||!finite(width)||!finite(height)||width<=0||height<=0||typeof x!=='function'||typeof y!=='function')return '';
    const right=clamp(Number(plotRight),0,Number(width)),bottom=clamp(Number(plotBottom),0,Number(height));
    const segment=(firstIndex,firstPrice,lastIndex,lastPrice)=>{
      if(![firstIndex,firstPrice,lastIndex,lastPrice].every(finite))return null;
      const firstX=x(Number(firstIndex)),lastX=x(Number(lastIndex));
      if(![firstX,lastX].every(finite))return null;
      const ax=number(firstX),bx=number(lastX);
      // Most historical annotations are left of the current viewport. Do not
      // ask the native price scale to project those invisible endpoints.
      if(Math.max(ax,bx)<0||Math.min(ax,bx)>right)return null;
      const firstY=y(Number(firstPrice)),lastY=y(Number(lastPrice));
      return finite(firstY)&&finite(lastY)?[{x:ax,y:number(firstY)},{x:bx,y:number(lastY)}]:null;
    };
    const parts=[];
    // Pine's visible-bar times refer to real candles, not the blank future area.
    // The caller clamps this range to its actual candle indices.
    const viewport=visibleRange&&finite(visibleRange.from)&&finite(visibleRange.to)?visibleRange:null;
    const fibEndpoint=item=>item.latest&&viewport?Math.max(Number(item.swing_end),Number(viewport.to))+Number(item.fib_right_extension||0):Number(item.swing_end);
    for(const zone of (Array.isArray(data.zones)?data.zones:[]).slice(0,100)){
      const points=segment(zone.x1,zone.upper,zone.x2,zone.lower);if(!points)continue;const[a,b]=points;
      if(Math.max(a.x,b.x)<0||Math.min(a.x,b.x)>right||Math.max(a.y,b.y)<0||Math.min(a.y,b.y)>bottom)continue;
      const col=safeColor(zone.color),alpha=finite(zone.opacity)?clamp(Number(zone.opacity),0,0.4):0.1;
      parts.push(`<rect x="${number(Math.min(a.x,b.x))}" y="${number(Math.min(a.y,b.y))}" width="${number(Math.max(0.6,Math.abs(b.x-a.x)))}" height="${number(Math.max(0.6,Math.abs(b.y-a.y)))}" fill="${col}" fill-opacity="${alpha}"/>`);
    }
    let lines=0;
    for(const line of (Array.isArray(data.lines)?data.lines:[]).slice(0,500)){
      const endpoint=line.kind==='swing_fibonacci'&&finite(line.swing_end)?fibEndpoint(line):line.x2;
      const points=segment(line.x1,line.y1,endpoint,line.y2);if(!points)continue;const[a,b]=points;
      if(Math.max(a.x,b.x)<0||Math.min(a.x,b.x)>right||Math.max(a.y,b.y)<0||Math.min(a.y,b.y)>bottom)continue;
      const style=String(line.style||'solid').toLowerCase(),dash=style==='dashed'?'6 4':style==='dotted'?'2 3':null;
      parts.push(`<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="${safeColor(line.color)}" stroke-width="${finite(line.width)?clamp(Number(line.width),0.5,5):1}" stroke-opacity="${finite(line.opacity)?clamp(Number(line.opacity),0,1):0.85}"${dash?` stroke-dasharray="${dash}"`:''}${line.arrow?' marker-end="url(#zwave-arrowhead)"':''}/>`);lines++;
    }
    let labels=0;
    for(const label of (Array.isArray(data.labels)?data.labels:[]).slice(0,500)){
      let index=label.index;
      const swingFib=label.kind==='swing_fibonacci'&&finite(label.swing_end);
      if(swingFib&&viewport){
        const end=fibEndpoint(label),shift=Number(label.fib_text_shift||0),extension=Number(label.fib_right_extension||0);
        index=label.align_left?Math.max(Number(label.swing_start??label.index),Number(viewport.from))+shift:end+Math.max(1,shift);
        if(index<viewport.from||index>Number(viewport.to)+extension+shift||index>end+Math.max(1,shift))continue;
      }
      if(!finite(index)||!finite(label.price))continue;
      const horizontal=x(Number(index));if(!finite(horizontal))continue;
      const size=FONT_SIZES[label.size]||10,text=String(label.text??'').slice(0,500);if(!text)continue;
      const textAnchor=swingFib?(label.align_left?'middle':'start'):['start','middle','end'].includes(label.text_anchor)?label.text_anchor:
        label.align==='Right'?'start':label.align==='Left'?'end':label.anchor==='left'?'start':label.anchor==='right'?'end':'middle';
      const dx=finite(label.x_offset)?clamp(Number(label.x_offset),-200,200):0,
        dy=finite(label.y_offset)?clamp(Number(label.y_offset),-200,200):label.position==='above'||label.above===true?-8:label.position==='below'||label.above===false?size+6:0;
      const px=number(number(horizontal)+dx);
      if(px<-100||px>right+100)continue;
      const vertical=y(Number(label.price));if(!finite(vertical))continue;
      const py=number(number(vertical)+dy);
      if(py<-size||py>bottom+size)continue;
      const span=text.split('\n').slice(0,5).map((line,i)=>`<tspan x="${px}"${i?` dy="${size+2}"`:''}>${escape(line)}</tspan>`).join('');
      const baseline=swingFib||String(label.kind||'').includes('fibonacci')?'central':'alphabetic';
      parts.push(`<text x="${px}" y="${py}" fill="${safeColor(label.color)}" text-anchor="${textAnchor}" dominant-baseline="${baseline}" font-family="Segoe UI,Arial,sans-serif" font-size="${size}" font-weight="${label.bold?650:500}">${span}<title>${escape(label.tooltip||text)}</title></text>`);labels++;
    }
    if(!parts.length)return '';
    return `<defs><clipPath id="zwave-plot-clip"><rect width="${right}" height="${bottom}"/></clipPath><marker id="zwave-arrowhead" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs><g clip-path="url(#zwave-plot-clip)" data-zwave-lines="${lines}" data-zwave-labels="${labels}">${parts.join('')}</g>`;
  }
  function status(data,{enabled=true,loading=false,error=''}={}) {
    if(!enabled)return {headline:'Nonaktif',lines:[]};
    if(loading)return {headline:'Menghitung candle selesai…',lines:[]};
    if(error)return {headline:'Belum tersedia',lines:[displayText(error)]};
    if(!data)return {headline:'Menunggu analisis',lines:[]};
    if(data.enabled===false)return {headline:'Nonaktif',lines:[]};
    const lines=(Array.isArray(data.panels)?data.panels:[]).map(line=>displayText(line?.text??line??'')).filter(Boolean);
    if(data.meta?.work_exhausted&&!lines.some(line=>/batas|limit|budget/i.test(line)))lines.push('Batas pencarian tercapai; struktur padat dapat belum terselesaikan.');
    const labelCount=Array.isArray(data.labels)?data.labels.length:0;
    return {headline:data.error?'Belum tersedia':labelCount?`${labelCount} label · candle selesai`:'Belum ada struktur terlabel',lines:data.error?[displayText(data.error),...lines]:lines};
  }
  function colorLegendHTML(data) {
    const legend=Array.isArray(data?.color_legend)?data.color_legend:[];
    if(!legend.length)return '';
    return '<div class="zwave-color-legend" style="display:flex;flex-wrap:wrap;gap:7px 13px;margin:8px 0" aria-label="Kategori warna target Fibonacci">'+legend.map(item=>`<span style="display:inline-flex;align-items:center;gap:6px" title="${escape(item.label)}" aria-label="${escape(item.label+': '+item.ranges)}"><i aria-hidden="true" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${safeColor(item.color)}"></i><span>${escape(item.ranges)}</span></span>`).join('')+'</div>';
  }
  return {FIELDS,DEFAULTS,mergeConfig,settingsHTML,readSettings,buildOverlay,status,colorLegendHTML};
});
