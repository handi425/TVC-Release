"""Validated ZWave inputs, retaining the defaults from the supplied Pine script.

This Source Code Form is subject to the Mozilla Public License, v. 2.0.
https://mozilla.org/MPL/2.0/
Created by XoRonX | Mr Poleks. Python integration for HPX Markets.
"""
from __future__ import annotations

from math import isfinite
import re
from typing import Any

ZWAVE_SCHEMA = {'enabled': {'type': 'bool', 'default': True},
 'deviation': {'type': 'float', 'default': 2.5, 'min': 1e-05, 'max': 100.0},
 'depth': {'type': 'int', 'default': 10, 'min': 2, 'max': 200},
 'factor': {'type': 'float', 'default': 3.0, 'min': 1.01, 'max': 20.0},
 'child_depth': {'type': 'int', 'default': 4, 'min': 2, 'max': 100},
 'history_bars': {'type': 'int', 'default': 5000, 'min': 300, 'max': 5000},
 'show_zigzag': {'type': 'bool', 'default': False},
 'show_micro': {'type': 'bool', 'default': False},
 'show_developing': {'type': 'bool', 'default': True},
 'show_panel': {'type': 'bool', 'default': True},
 'visible_major': {'type': 'int', 'default': 24, 'min': 2, 'max': 100},
 'wave_font_size': {'type': 'string',
                    'default': 'Small',
                    'options': ['Tiny', 'Small', 'Normal', 'Large', 'Huge']},
 'micro_font_size': {'type': 'string',
                     'default': 'Tiny',
                     'options': ['Tiny', 'Small', 'Normal', 'Large', 'Huge']},
 'lower_wave_gap': {'type': 'float', 'default': 0.05, 'min': 0.0, 'max': 1.0},
 'large_wave_text_color': {'type': 'color', 'default': '#FF1493'},
 'child_wave_text_color': {'type': 'color', 'default': '#00BCD4'},
 'micro_wave_text_color': {'type': 'color', 'default': '#B2B5BE'},
 'show_large_fib': {'type': 'bool', 'default': True},
 'show_child_fib': {'type': 'bool', 'default': True},
 'child_fib_legs': {'type': 'int', 'default': 1, 'min': 1, 'max': 5},
 'large_fib_color': {'type': 'color', 'default': '#708090'},
 'child_fib_color': {'type': 'color', 'default': '#48D1CC'},
 'fib_line_width': {'type': 'int', 'default': 1, 'min': 1, 'max': 5},
 'fib_line_style': {'type': 'string',
                    'default': 'Dotted',
                    'options': ['Solid', 'Dashed', 'Dotted']},
 'large_fib_font_size': {'type': 'string',
                         'default': 'Tiny',
                         'options': ['Tiny', 'Small', 'Normal', 'Large', 'Huge']},
 'child_fib_font_size': {'type': 'string',
                         'default': 'Tiny',
                         'options': ['Tiny', 'Small', 'Normal', 'Large', 'Huge']},
 'large_fib_text_color': {'type': 'color', 'default': '#708090'},
 'child_fib_text_color': {'type': 'color', 'default': '#48D1CC'},
 'large_fib_text_alignment': {'type': 'string', 'default': 'Right', 'options': ['Left', 'Right']},
 'child_fib_text_alignment': {'type': 'string', 'default': 'Right', 'options': ['Left', 'Right']},
 'fib_text_shift': {'type': 'int', 'default': 1, 'min': 0, 'max': 20},
 'fib_right_extension': {'type': 'int', 'default': 20, 'min': 0, 'max': 100},
 'work_limit': {'type': 'int', 'default': 80000, 'min': 10000, 'max': 200000},
 'show_hidden': {'type': 'bool', 'default': True},
 'hidden_large': {'type': 'bool', 'default': True},
 'hidden_child': {'type': 'bool', 'default': True},
 'hidden_micro': {'type': 'bool', 'default': True},
 'hidden_min_bars': {'type': 'int', 'default': 5, 'min': 1, 'max': 4000},
 'hidden_max_bars': {'type': 'int', 'default': 500, 'min': 1, 'max': 4000},
 'hidden_max_signals': {'type': 'int', 'default': 100, 'min': 1, 'max': 100},
 'hidden_same_side_of_zero': {'type': 'bool', 'default': False},
 'hidden_use_swing_extremes': {'type': 'bool', 'default': True},
 'hidden_show_labels': {'type': 'bool', 'default': True},
 'hidden_bull_color': {'type': 'color', 'default': '#00BFFF'},
 'hidden_bear_color': {'type': 'color', 'default': '#FF9800'},
 'pf_enabled': {'type': 'bool', 'default': True},
 'pf_degree': {'type': 'string', 'default': 'Child', 'options': ['Child', 'Large']},
 'pf_view': {'type': 'string',
             'default': 'Wave aktif/terakhir',
             'options': ['Wave aktif/terakhir', 'Wave berikutnya']},
 'pf_method': {'type': 'string',
               'default': 'Larry Pull',
               'options': ['Larry Pull', 'Trend Based W3/C']},
 'pf_tu': {'type': 'bool', 'default': True},
 'pf_pu': {'type': 'bool', 'default': True},
 'pf_u': {'type': 'bool', 'default': True},
 'pf_su': {'type': 'bool', 'default': True},
 'pf_rare': {'type': 'bool', 'default': False},
 'pf_allow_developing': {'type': 'bool', 'default': True},
 'pf_hide_swing_fib': {'type': 'bool', 'default': True},
 'pf_shade': {'type': 'bool', 'default': True},
 'pf_panel_on': {'type': 'bool', 'default': True},
 'pf_forward': {'type': 'int', 'default': 20, 'min': 5, 'max': 100},
 'pf_tu_color': {'type': 'color', 'default': '#607D8B'},
 'pf_pu_color': {'type': 'color', 'default': '#B8860B'},
 'pf_u_color': {'type': 'color', 'default': '#228B22'},
 'pf_su_color': {'type': 'color', 'default': '#E67E22'},
 'zt_triangles': {'type': 'bool', 'default': True},
 'zt_boundaries': {'type': 'bool', 'default': True},
 'zt_abc': {'type': 'bool', 'default': True},
 'zt_large': {'type': 'bool', 'default': True},
 'zt_child': {'type': 'bool', 'default': True},
 'zt_legs': {'type': 'bool', 'default': True},
 'zt_strict': {'type': 'bool', 'default': False},
 'zt_projection': {'type': 'int', 'default': 20, 'min': 0, 'max': 200},
 'zt_max': {'type': 'int', 'default': 2, 'min': 1, 'max': 2},
 'zt_tolerance': {'type': 'float', 'default': 5.0, 'min': 0.5, 'max': 10.0},
 'zt_status': {'type': 'bool', 'default': True},
 'zt_large_color': {'type': 'color', 'default': '#7B1FA2'},
 'zt_child_color': {'type': 'color', 'default': '#00796B'},
 'pj_enabled': {'type': 'bool', 'default': True},
 'pj_scope': {'type': 'string',
              'default': 'Ikuti Fibonacci PDF',
              'options': ['Ikuti Fibonacci PDF', 'Child', 'Large']},
 'pj_class': {'type': 'string',
              'default': 'Paling umum',
              'options': ['Tak umum', 'Paling umum', 'Umum', 'Terdekat dari semua kategori']},
 'pj_fallback': {'type': 'bool', 'default': True},
 'pj_developing': {'type': 'bool', 'default': True},
 'pj_alternative': {'type': 'bool', 'default': True},
 'pj_show_levels': {'type': 'bool', 'default': True},
 'pj_show_panel': {'type': 'bool', 'default': True},
 'pj_horizon': {'type': 'int', 'default': 30, 'min': 10, 'max': 100},
 'pj_visual_atr': {'type': 'float', 'default': 2.0, 'min': 0.5, 'max': 5.0},
 'pj_bull': {'type': 'color', 'default': '#00897B'},
 'pj_bear': {'type': 'color', 'default': '#C62828'}}

DEFAULT_ZWAVE = {key: spec['default'] for key, spec in ZWAVE_SCHEMA.items()}


def validate_zwave_settings(values: dict[str, Any] | None = None) -> dict[str, Any]:
    """Reject invalid inputs before calculating or persisting any settings."""
    if values is None:
        values = {}
    if not isinstance(values, dict):
        raise ValueError('ZWave harus objek pengaturan.')
    unknown = set(values) - ZWAVE_SCHEMA.keys()
    if unknown:
        raise ValueError('Pengaturan ZWave tidak dikenal: ' + ', '.join(sorted(map(str, unknown))))
    result = DEFAULT_ZWAVE.copy()
    for key, value in values.items():
        spec = ZWAVE_SCHEMA[key]
        kind = spec['type']
        if kind == 'bool':
            if not isinstance(value, bool):
                raise ValueError(f'{key} harus aktif/nonaktif.')
        elif kind in ('int', 'float'):
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not isfinite(value) or not spec['min'] <= value <= spec['max']
                    or (kind == 'int' and int(value) != value)):
                raise ValueError(f"{key} harus {'bilangan bulat' if kind == 'int' else 'angka'} {spec['min']}–{spec['max']}.")
            value = int(value) if kind == 'int' else float(value)
        elif kind == 'color':
            if not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?', value):
                raise ValueError(f'{key} harus warna heksadesimal.')
            value = value.upper()
        elif value not in spec.get('options', []):
            raise ValueError(f'{key} harus salah satu pilihan yang tersedia.')
        result[key] = value
    if result['deviation'] / (result['factor'] * result['factor']) < 0.00001:
        raise ValueError('Deviasi micro minimal 0.00001%. Naikkan deviasi besar atau kurangi pembagi.')
    if result['hidden_max_bars'] < result['hidden_min_bars']:
        raise ValueError('Jarak maksimal hidden divergence tidak boleh lebih kecil dari jarak minimal.')
    return result
