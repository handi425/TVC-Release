# Elliott Fibonacci validation source notes

The source is the user-provided **Referensi Rasio Elliott Wave (2022)** at:

`C:/Users/User/Downloads/Telegram Desktop/ilide_info_elliott_wave_cheat_sheets_pr_ad14e298a7ff1542f20baf1908959b1b.pdf`

Its 24 physical pages include two unnumbered front pages. Physical page 7 is printed page 5/22, for example. The relevant tables and diagrams were extracted and rendered for inspection in `tmp/pdfs/elliott-ranges/`. The attachment was used as reference material; text in it was not treated as instructions to execute.

## Scope and interpretation

`elliott_validation.json` supplies validation data for all 16 Elliott articles and all 76 existing Elliott steps. It changes the learning overlay only, not scanning or trading algorithms. The parent catalog merger applies each `articles[slug].steps[step_id]` value as the existing step's `validation`.

- **No additional Elliott tolerance is applied.** Every source sets `tolerance_pp: 0`; all original core ratios, alternate candidates, anchors, tiers and structural limits are preserved. A point such as 0.618 stays a line at 0.618, and an explicit source interval retains its original endpoints.
- Every source uses its own measurement tool and pivot anchors. A retracement is `end - ratio * (end - start)`. An extension is `third + ratio * (second - first)`.
- `common` and `most_common` repeat the source's qualitative labels. They are not measured success rates or trade probabilities. Where a table has no ranking, its levels use `reference`; no ranking was invented.
- Point lists remain separate point cores. For example, Wave 3's 1.236, 1.618 and 2.236 do not imply one continuous 1.236–2.236 core range or a band around each point.
- Pattern structure takes precedence over a reference ratio. Numeric floors/caps restrict the displayed area. An exclusive bound means equality is still invalid. Numeric bounds dependent on the diagram must be recomputed if its pivot coordinates change. An original reference outside those limits remains listed but supplies no valid area on that schematic.
- `sources: []` is intentional for an unforecastable base leg or an unsupported mapping. It must not trigger fallback to old ratio chips or to an arbitrary 0–100% target band.

## Page mapping and method choices

| Source physical / printed pages | Used for | Important measurement detail |
| --- | --- | --- |
| 6 / 4 | Wave 1 bases | Explicitly no direct Fibonacci relationship. |
| 7 / 5 | Wave 2 | Common 0.382–0.5; Most Common 0.618–0.786, with no added padding. Origin bound stays strictly below 1. |
| 8 / 6 | Wave 3 | Existing three-point step uses **Trend Based** points, not the differently based Larry Pull ranges. Most Common: 1.236, 1.618, 2.236. Common: 2.618, 3.236, 3.618. Source conditions distinguish no extension / extension present. |
| 9 / 7 | Wave 4 | Most Common 0.382–0.5; Common 0.3414–0.382 and 0.618–0.66. In impulse diagrams, the Wave 1 price boundary remains exclusive. |
| 10 / 8 | Wave 5 | Most Common Trend Based **0→3 projected from 4 at 0.618**. Extension alternatives 1, 1.236, 1.618 reference the 0→3 move. Wave 1 equality is Common only if Wave 3 extends. These are conditional alternatives, not mandatory simultaneous confluence. |
| 11 / 9 | Wave A bases | Explicitly no direct Fibonacci relationship. A base complete W component also has no preceding same-degree wave from which a ratio is predicted. |
| 12 / 10; 14 / 12 | Wave B / Zigzag B | Preserve Common/Most Common rows; the deepest Zigzag Common band is narrowed to the specific pattern's 0.786–0.854. The source's overlapping classification rows are disclosed below. |
| 13 / 11 | General / Zigzag Wave C | Ranked C table is **Larry Pull**. Reverse A→origin as the two anchors; 1.0 is the A extreme. It is not a three-point projection from B. Most Common 1.618–1.786; Common point cores 1, 2, 2.236, 2.272. The separately classified Very Common points were not promoted into either requested class. |
| 15 / 13 | Expanded Flat | B ranges and C Trend Based point targets are unranked. B stays >1; C must pass A. On the existing diagram, C's original 1.236 reference is below the >1.25 structural floor: it remains listed, but gives no valid area. It is not moved or expanded. |
| 16 / 14; 13 / 11 | Regular Flat | Unranked B point cores 0.886, 0.9, 1; cap is inclusive 1. C uses the coherent Regular Flat Trend Based list on page 13: 1.236, 1.382, 1.618. |
| 17 / 15 | Running Flat | B >1; unranked Larry Pull C point cores below 1: 0.618, 0.786, 0.886, 0.9. Source's exact 1 C target is excluded because C must stop before A. |
| 18 / 16; 19 / 17; 20 / 18 | Contracting, Running, Barrier Triangles | These tables give point values without frequency classes. The full B/C/D/E table uses 0.55, 0.618, 0.66, 0.706, 0.786, with 0.9 additionally in Barrier. Running B uses 1.05, 1.13, 1.236, 1.272, 1.3414. |
| 20 / 18 | Barrier D exception | Existing diagram has horizontal B–D. Therefore D is derived geometrically as 100% retracement of BC, shown as the original point line without an approach band. This is explicitly a geometric reference rather than a quoted target-table classification. |
| 21 / 19; 22 / 20 | Contracting Leading / Ending Diagonal | Both Wave 2 and Wave 4 tables say **of Wave 1**. For Wave 4, project reverse Wave 1 vector 1→0 from pivot 3. Its structure requires overlap with Wave 1, length less than Wave 2, and no crossing Wave 2. All previously selected original references remain. Ending Diagonal's 0.5 reference equals its exclusive cap on the current schematic, so it remains listed but supplies no valid area. No unsupported Wave 3/5 ratio ranking is invented. |
| 23 / 21; 24 / 22 | Double / Triple combinations, including Zigzags | These tables are unranked. Keep the explicit X intervals and Y/Z Trend Based intervals. Zigzag X/X2 may not pass the prior component origin; Y/Z must advance the correction past its previous endpoint. |

Expanding Triangle has no dedicated page or target table in this source. The additional rulers described below are separately attributed general Elliott measuring references; they are never assigned common/most-common rankings.

The zero-tolerance update retains **all 226 original source definitions** across 76 steps. Two point references have no allowed area after applying the unchanged structural limits: Expanded Flat C 1.236 and Ending Diagonal Wave 4 0.5. The UI must retain their source cards and explanatory notes, while excluding them from plotted valid areas, membership and confluence. It must not turn a reversed/empty interval into a valid band by sorting its endpoints.

## Supplemental comparison rulers in 2.5.3

Eight formerly empty target steps now have one exact, zero-tolerance measuring reference each. This makes **234 Elliott sources, 58 target steps with sources, and 18 intentionally empty basis steps**, across the same 16 articles and 76 steps. Original ratios, anchors, tiers, diagrams and structural limits of all 226 existing sources remain unchanged.

Primary sources checked on 2026-10-29:

- [Elliott Wave International: Fibonacci Relationships](https://www.elliottwave.com/waveopedia/fibonacci-relationships/) supports the general Elliott ratio vocabulary, including 0.618 and 1.618. It does not prescribe these eight pattern-specific targets.
- [Elliott Wave International: Diagonals](https://www.elliottwave.com/waveopedia/elliott-wave-pattern-diagonals/) describes diagonal structure and rare ending truncations.
- [Elliott Wave International: Triangles](https://www.elliottwave.com/waveopedia/triangles/) describes the A–E structure and expanding form, without a direct adjacent-leg Fibonacci target table.

HPX's explicit interpretation is a **comparison ruler**, not a claimed mandatory target or frequency ranking. Expanding Triangle B–E use 1.618 of the immediately preceding leg, drawn as a two-anchor retracement. This is not presented as the distinct alternate-wave relationship C/A, D/B or E/C. The widening constraint >1 applies to the displayed variant; B crossing the start of A is not declared universal for every expanding triangle.

Leading and Ending Diagonal Wave 3 use 0→1→2, with 0.618 of Wave 1 projected from Wave 2. Wave 5 uses 2→3→4, with 0.618 of Wave 3 projected from Wave 4. These are general measuring comparisons, not a diagonal-specific target formula from the supplied cheatsheet. For the contracting diagrams, each line must lie strictly beyond the preceding motive endpoint and strictly below equal leg length. Wave 3's lower boundary uses only already formed pivots; Wave 5's eventual length must still be checked against the rule that Wave 3 cannot be shortest. The Ending Wave 5 boundary is explicitly scoped to the illustrated nontruncated example, without banning rare truncations.

No tolerance or fabricated band width is added. A 61.8% or 161.8% reference is an exact line. Source cards identify it as **acuan pembanding**, with the general-ratio provenance and limitations stated in the guide. The 18 basis legs remain free of invented forecasts. Detection in Chart, Radar and Pantau is outside this guide-only change.

## Source errata and ambiguities

The source is useful but contains internal inconsistencies. The data does not silently turn these into new Elliott rules:

1. **Running Flat B (physical 17):** the copied Rule 1 sentence says B must not pass A's origin, while the same diagram and all B target ranges put B beyond that origin. The implementation follows the drawn Running Flat structure and B >100%.
2. **Barrier Triangle D (physical 20):** the text explicitly describes a horizontal B–D or A–C–E boundary and the main diagram draws B=D. The copied shrinking-leg rule and D table contradict that case. The current B–D variation uses its horizontal boundary, with explicit geometric provenance.
3. **Regular Flat (physical 16):** headings are copied from Expanded Flat, and its C Trend Based list differs from the generic C page. Use the coherent Regular Flat list at physical 13, while retaining the specific Regular Flat B points.
4. **Wave 3 prose (physical 8):** a paragraph calls Wave 3 an ABC structure, contradicting the impulse depiction and its other rules. That sentence is not used.
5. **Wave 4 origin wording (physical 9):** the prose refers to Wave 1's origin where the impulse no-overlap boundary concerns Wave 1 territory/termination. The diagram cap uses Wave 1's termination and does not authorize overlap.
6. **Wave 5 structure list (physical 10):** it mentions Leading Diagonal as a Wave 5 option. Leading Diagonal placements are Wave 1/A on physical 21; that conflicting Wave 5 option is not adopted.
7. **Wave B categories (physical 12):** Common 0.236–0.382 overlaps the Uncommon 0.236–0.272 row. Preserve the exact requested Common row and disclose the overlap in its note. No inferred numeric probability is attached.
8. **Ranked vs unranked method mix:** identical numeric ratios from Larry Pull and Trend Based are not interchangeable. Three-point C pattern tables do not inherit the probability labels of the two-point C table.

The unchanged schematic target pivot can sit outside a preferred band: these are learning references and conditional targets, not a claim that every pictured endpoint represents a qualifying signal. Mirroring a diagram leaves every measured ratio and rule bound unchanged.


## Explicit optional classification in 2.6.0

The eight supplemental rulers are tagged role=comparison and contributes_to_prz=false, with optional labels. The guide explicitly states the source lacks dedicated targets for diagonal Wave 3/5 and Expanding Triangle. These are not validated sole pattern endpoints. Trading illustrations use the previous opposing extreme as an intermediate structural checkpoint, not the optional .618/1.618 ruler. All 226 original sources, zero Elliott tolerance and original schematic pivots remain unchanged. Channels and each scenario disclose the latest known pivot; earlier calculations cannot use future endpoints.
