# Sumber dan catatan editorial Panduan HPX

Diperiksa pada 28 Oktober 2026. Konten berbahasa Indonesia ditulis ulang untuk pembelajaran, dengan contoh angka dan diagram skematis buatan sendiri. Dua kategori: Harmonic (12 halaman) dan Elliott Wave (16 halaman). Setiap pola memiliki halaman sendiri.

## Cara membaca rujukan

Sumber primer mendasari definisi bentuk dan hubungan rasio. Bagian contoh, prosedur pemeriksaan, skenario reaksi bersyarat, dan batas interpretasi merupakan penjelasan editorial. Keterangan kemampuan aplikasi mengikuti implementasi lokal yang disebut per halaman. Diagram menunjukkan anchor; garis utama tidak membuktikan pembagian internal dan bukan prediksi harga. Tidak ada klaim persentase keberhasilan atau janji profit.

## Perbedaan acuan dan implementasi

- Stingray adalah varian rute alternatif HPX, bersumber hanya pada kode lokal. Ia tidak diklaim sebagai pola standar Carney.
- B Bat pada HPX diterima sampai 0,618 dengan toleransi; acuan Carney menekankan B di bawah 0,618. Alternate Bat turunan Bat dapat menggunakan kelayakan B jalur asal.
- Butterfly lokal memakai D 1,27 XA dan CD/BC 1,618–2,24. Gartley lokal menerima CD/BC 1,13–1,618. Deep Crab lokal menerima CD/BC 2,0–3,618. Rentang ini dinyatakan sebagai batas engine, bukan pengganti definisi acuan.
- Shark memiliki empat kind internal dalam satu keluarga. Notasi HPX XABCD tidak boleh dipindahkan begitu saja ke notasi OXABC pada referensi lain.
- Cypher kind 10 mengikuti D 0,786 XC. Kind 11 memakai struktur berbeda dan dijelaskan sebagai varian implementasi; nama keluarga saja tidak membuktikan Cypher standar.
- AB=CD dan alternatif 1,272/1,618 tersedia sebagai level pendamping. 5-0 dan Three Drives dibahas untuk pembelajaran; tidak diklaim sebagai keluarga scanner mandiri.
- Impulse lokal mensyaratkan wave 5 melampaui wave 3; truncated fifth tidak diklaim tercakup dalam pencarian tersebut.
- Triangle/ABC memiliki modul tambahan. G adalah kandidat geometri; S berarti setiap child leg terbukti pada stream lebih kecil. Strict hanya menerima S. Endpoint harus settled oleh pivot berlawanan sesudahnya. Envelope lokal dan toleransi membatasi bentuk yang diterima. Posisi parent wave 4/B/X belum diverifikasi.
- Leading/ending diagonal, koreksi WXY/WXYXZ, serta derajat klasik di luar Large/Child/Micro memerlukan telaah manual.
- Warna frekuensi adalah klasifikasi bawaan indikator yang dapat diubah pengguna; ia bukan probabilitas statistik.

## Sumber primer per halaman

- [Scott Carney — Alternate Bat Pattern](https://harmonictrader.com/harmonic-patterns/alternate-bat-pattern/)
- [Scott Carney — Bat Pattern](https://harmonictrader.com/harmonic-patterns/bat-pattern/)
- [Scott Carney — Butterfly Pattern](https://harmonictrader.com/harmonic-patterns/butterfly-pattern/)
- [Scott Carney — Crab Pattern](https://harmonictrader.com/harmonic-patterns/crab-pattern/)
- [Scott Carney — Gartley Pattern](https://harmonictrader.com/harmonic-patterns/gartley-pattern/)
- [Scott Carney — Deep Crab Pattern](https://harmonictrader.com/harmonic-patterns/deep-crab-pattern/)
- [Scott Carney — Shark Pattern](https://harmonictrader.com/harmonic-patterns/shark-pattern/)
- [TradingView — Cypher harmonic pattern drawing tool](https://www.tradingview.com/support/solutions/43000791680-cypher-harmonic-pattern-drawing-tool/)
- [Scott Carney — AB=CD Pattern](https://harmonictrader.com/harmonic-patterns/abcd-pattern/)
- [Scott Carney — Alternate AB=CD Pattern](https://harmonictrader.com/harmonic-patterns/alternate-abcd-pattern/)
- [Scott Carney — 5-0 Pattern](https://harmonictrader.com/harmonic-patterns/5-0/)
- [TradingView — Three drives pattern drawing tool](https://www.tradingview.com/support/solutions/43000570172-three-drives-pattern-drawing-tool/)
- [Elliott Wave International — Waveopedia](https://www.elliottwave.com/waveopedia/)
- [Elliott Wave International — Fibonacci Relationships](https://www.elliottwave.com/waveopedia/fibonacci-relationships/)
- [Elliott Wave International — Impulse](https://www.elliottwave.com/waveopedia/impulse/)
- [Elliott Wave International — Motive Waves](https://www.elliottwave.com/waveopedia/motive-waves/)
- [Elliott Wave International — Diagonals](https://www.elliottwave.com/waveopedia/elliott-wave-pattern-diagonals/)
- [Elliott Wave International — Zigzags](https://www.elliottwave.com/waveopedia/zigzags/)
- [Elliott Wave International — Combinations](https://www.elliottwave.com/waveopedia/combinations/)
- [Elliott Wave International — Flats](https://www.elliottwave.com/waveopedia/flats/)
- [Elliott Wave International — Triangles](https://www.elliottwave.com/waveopedia/triangles/)

## Implementasi lokal

- `backend/hpx.py`: nama keluarga, eligible/extra_eligible, parameter rasio, pembentukan PRZ, jalur turunan, trigger, status, dan level AB=CD.
- `backend/zwave_core.py`: stream pivot candle tertutup, geometri impulse/ABC, pembuktian, skor, serta Large/Child/Micro.
- `backend/zwave_patterns.py`: Triangle Contracting/Barrier/Running contracting/Expanding, ABC boundaries, envelope, G/S, strict, dan settled endpoints.
- `backend/zwave.py`: integrasi keluaran ZWave dan modul pola.

## Validasi data

- 28 slug unik, kategori tepat `harmonic` dan `elliott`.
- Setiap halaman mempunyai diagram dengan jumlah label dan koordinat yang sama, minimal lima bagian, cakupan HPX, serta daftar sumber.
- Isi bagian per artikel 355–457 kata pada penulisan akhir, total 10.910 kata; metadata dan pengulangan coverage tidak dihitung.
- Semua contoh angka harmonic diperiksa terhadap denominator yang dinyatakan. Diagram Alternate Bat, Crab, dan leading diagonal dikoreksi melalui audit silang.
- Seluruh referensi lokal ada di checkout; teks memakai Unicode tanpa replacement character.

## Video kursus pengguna

Diperiksa 28 Oktober 2026 melalui metadata YouTube. [Kursus Harmonic Pattern](https://www.youtube.com/playlist?list=PLKKbgg5Qw-10) berisi 16 video; [Kursus Elliott Wave](https://www.youtube.com/playlist?list=PLEPyfeGewSG4) berisi 28 video, keduanya dari MR Poleks. Dua puluh sembilan video unik yang dipakai tersedia dan mengizinkan embed saat diperiksa. Tidak ada berkas video yang diunduh atau dimasukkan ke APK/EXE.

Pemetaan lengkap, identitas video, bukti metadata, dan tanggal pemeriksaan ada di `video_sources.json`. Dua puluh enam artikel memakai materi sesuai pola atau bab; Stingray dan Expanding Triangle memakai materi pendukung yang diberi keterangan. Impulse memiliki lima bagian Wave 1–5; Alternate Bat dimulai 02:33.
