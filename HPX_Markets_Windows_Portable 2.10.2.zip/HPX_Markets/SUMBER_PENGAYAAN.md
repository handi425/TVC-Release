# Sumber pengayaan panduan HPX 2.6.3

`enrichment_content.json` dan `elliott_trading_reference.json` berisi tambahan orisinal berbahasa Indonesia untuk 28 artikel: 12 Harmonic dan 16 Elliott. Trading Elliott mengikuti 12 lembar trading baru yang diberikan pengguna. Kontrol Channel dihapus dari seluruh diagram; Rencana Trading hanya berisi setup Elliott bersumber; penarikan Fibonacci, AB=CD/ALT, reciprocal dan teori lanjutan dipertahankan. Berkas sumber dan gambar buku tidak dimasukkan dalam aplikasi.

Tambahan materi tidak mengubah mesin Chart/Radar/Pantau, klasifikasi pola, parameter indikator, rasio inti yang sudah diverifikasi, maupun toleransi panduan yang telah dipilih pengguna. Keterangan sumber disertakan per bagian. Bagian yang merupakan penerapan pengajaran HPX dinyatakan sebagai sintesis, bukan aturan baru yang diklaim berasal dari buku.

## Berkas rujukan dan lokasi materi

Nomor berikut adalah halaman berkas, dengan nomor cetak ditambahkan jika berbeda. Nama berkas merujuk lampiran pengguna; berkas sumbernya tidak dimasukkan dalam paket aplikasi.

| Rujukan | Halaman berkas | Materi yang dipakai |
| --- | --- | --- |
| Scott M. Carney, Harmonic Trading: Volume One (`Harmonic vol 1.pdf`) | 45 | AB=CD dan tabel pasangan C/BC; dipisahkan dari invers matematika eksak. |
| Volume One | 69–72 | Alternate AB=CD dan Perfect AB=CD; peran panjang AB yang diproyeksikan dari C. |
| Volume One | 169–172; 203–206 | Identifikasi/eksekusi, target, stop, pengelolaan reaksi dan garis tren. |
| Volume One | 233–235 dan lanjutan bab | Pola gagal dan perlunya setup baru sebelum mengambil arah sebaliknya. |
| Scott M. Carney, Harmonic Trading: Volume Two (`Harmonic vol 2.pdf`) | 67–70 / cetak 58–61 | 1,13 Failed Wave sebagai failed breakout/breakdown Harmonic. |
| Volume Two | 82–88 / cetak 73–79 | 5-0, Reciprocal AB=CD dan D sebagai 50% BC; perbedaan C yang memperpanjang tren dengan retracement C klasik. |
| Volume Two | 150–169 / cetak 141–160 | BAMM, persyaratan susunan Bat, trigger CD melewati B dan perjalanan menuju PRZ. |
| Volume Two | mulai 170 / cetak 161 | RSI BAMM sebagai metode dengan urutan tersendiri. |
| Scott M. Carney, Harmonic Trading Volume 3: Reaction vs. Reversal (`Harmonic vol 3.pdf`) | 83 / cetak 76; 87 / cetak 80; 94–97 / cetak 87–90 | AB=CD, pasangan pengukuran dan variasi alternate. |
| Volume 3 | 137–138 / cetak 130–131 | Reciprocal AB=CD dan diagram 5-0 lengkap. |
| Volume 3 | 157–162; 174 / cetak 150–155; 167 | Terminal Bar, konfirmasi dan Permissible Execution Zone (PEZ). |
| Volume 3 | 181 / cetak 174 | Rujukan stop operasional khusus pola; konteks dan notasi perlu diperiksa. |
| Volume 3 | 182–189 / cetak 175–182 | Kegagalan harmonic dan respons pada area terminal. |
| Volume 3 | 190–217 / cetak 183–210 | Type-I reaction dan Type-II retest, dengan konfirmasi yang sesuai. |
| Volume 3 | 243–246 / cetak 236–239; 270–273 / cetak 263–266 | RSI BAMM dan HSI sebagai konsep lanjutan, bukan klaim fitur indikator HPX yang sudah dihitung. |
| Volume 3 | 290–296; 301–312; 324–338 / cetak 283–289; 294–305; 317–331 | Garis tren, pengelolaan posisi, sasaran reaksi dan koordinasi timeframe. |
| Referensi Harmonic II | 115–117; 140; 149–159 | Penarikan extension dan pasangan pengukuran AB=CD/BC. |
| Referensi Harmonic II | 129–130 / cetak 83–84 | Pengantar hubungan dengan struktur Elliott, bukan tabel pemetaan baku tiap pola. |
| Referensi Harmonic II | 274–303; 317–333 | Failed Wave, Harmonic Impulse Wave, Reciprocal AB=CD dan 5-0. |
| Referensi Harmonic II | 354–355; 357 | Perbedaan klasifikasi metode Referensi Harmonic II dengan Carney serta peran AB=CD menurut keluarga. |
| Referensi Harmonic II | 358–384 | BAMM dan pengembangan pendampingnya; arah/anchor harus diperiksa. |
| Referensi Harmonic II | 389–396; 444 | Tahap eksekusi, konfirmasi timeframe lebih rendah dan pilihan stop. |
| Referensi Harmonic II | 478–484; 485; 496; 500; 502 | IPO/PPZ/SLZ, trailing dan perbedaan asal ukur target reaksi menurut keluarga. |
| Referensi Harmonic II | 511–519 | Pelanggaran pola dan perubahan peran bekas PRZ. |
| Referensi Rasio Elliott Wave (2022) | 6–24 / cetak 4–22 | Rasio/struktur yang sudah dipetakan di `elliott_validation_sources.md`; keterbatasan diagonal dan Expanding Triangle dijelaskan. |
| Referensi Setup Elliott Wave (12 lembar) | 1–12 | Lembar trading Wave 3, Wave 5, Wave C, masing-masing konservatif/agresif dan buy/sell; sumber terpisah dari lembar rasio 24 halaman. |

Rujukan primer tambahan untuk struktur Elliott:

- [Waveopedia: Channeling](https://www.elliottwave.com/waveopedia/channeling/)
- [Waveopedia: Diagonals](https://www.elliottwave.com/waveopedia/elliott-wave-pattern-diagonals/)
- [Waveopedia: Triangles](https://www.elliottwave.com/waveopedia/triangles/)
- [Waveopedia: Truncation](https://www.elliottwave.com/waveopedia/truncation/)
- [Waveopedia: Fibonacci Relationships](https://www.elliottwave.com/waveopedia/fibonacci-relationships/)

## Kontrak pengukuran yang harus dipertahankan

### AB=CD, ALT dan reciprocal

Untuk harga A, B dan C yang sudah terbentuk, proyeksi tiga anchor ialah:

`D = C + k × (B − A)`

Nilai `k=1` adalah equal AB=CD; pembanding `k=1.272` dan `k=1.618` diberi label ALT AB=CD masing-masing. Ketiganya adalah garis terpisah, bukan pernyataan bahwa semua rasio di antara dua batas ALT merupakan rasio inti wajib. Buku terkadang membulatkan 1.272 menjadi 1.27; aplikasi tetap menampilkan nilai yang sedang dipakai.

Dengan `r = |BC| / |AB|`, proyeksi BC yang koheren ialah `q = |CD| / |BC| = k/r`. Untuk equal, `q=1/r`. Tanda `≈` menyatakan pembulatan matematika, bukan izin toleransi baru.

Tabel Volume One halaman 45 mencantumkan C 0.382 dengan BC 2.24 atau 2.618. Hanya sekitar 2.618 merupakan invers matematis 0.382. Referensi Harmonic II halaman 140 memperluas daftar sampai 3.14, dan Volume 3 halaman 87 juga mencampur pasangan konvensional. Panduan tidak menyebut semua angka tersebut sebagai hasil eksak `1/r`.

Reciprocal AB=CD adalah nama pola yang berbeda dari operasi reciprocal. Bentuknya dua countermove AB/CD dengan BC memanjang searah tren; C dapat melewati A. Hubungannya dengan 5-0 tidak mengubah completion 5-0 dari 50% BC menjadi 50% XA.

Ilustrasi pendamping orisinal pada bagian Reciprocal memakai A=1, B=0.5, C=1.5, D=1 dalam harga skematis. Dengan demikian |AB|=|CD|=0.5, |BC|=1, BC/AB=2 dan CD/BC=0.5. Ilustrasi ini memperjelas C melampaui A tanpa mengubah diagram AB=CD klasik yang sudah ada, dan tidak mengklaim angka contoh sebagai rentang universal.

### Pemetaan pivot

- XABCD dan OXABCD memakai A→B→C untuk pemindahan AB dari C.
- Three Drives mempertahankan label O, 1, A, 2, C, 3. Penggaris ABCD lokal menggunakan A→2→C dan endpoint 3. Label B/D lokal tidak mengganti label utama.
- Shark dalam buku sering OXABC, sedangkan gambar HPX memakai XABCD. Jangan menyalin nama ruas tanpa memetakan pivot.
- Untuk Elliott 0–A–B–C, padanan Harmonic A/B/C/D ialah 0/A/B/C Elliott. Proyeksi kesetaraan Wave A/C menggunakan 0→A→B. Pada koreksi setelah Wave 5 dalam halaman dasar, origin lokalnya 5, sehingga penarikannya 5→A→B.
- Connector kombinasi dan zigzag berikutnya memiliki origin sendiri. Contoh C kedua pada Double Zigzag memakai X→A(y)→B(y), bukan origin zigzag pertama.

### Trading Elliott: order, SL dan target

Sumber trading baru adalah 12 lembar Referensi Setup Elliott Wave yang diberikan pengguna. Nomor halaman di bawah adalah nomor berkas. Pengguna tidak meminta perubahan rasio validasi sebelumnya, sehingga sumber trading berada pada pelajaran Rencana Trading tersendiri dan tidak mengganti 226 sumber validasi Elliott.

| Setup | Entry order bersyarat | SL sumber | Target sumber | Halaman buy/sell |
| --- | --- | --- | --- | --- |
| Wave 3 konservatif | Retracement 0→1 = 50% | Origin Wave 1 (0) | Extension 0→1→2 = 100% dan 161,8% | 1/2 |
| Wave 3 agresif | Dua order terpisah pada 50% dan 61,8% Wave 1 | Origin Wave 1 (0) | Sama seperti konservatif | 7/8 |
| Wave 5 konservatif | Retracement 2→3 = 38,2%; varian 23,6% hanya bila Wave 3 extended | Retracement 2→3 = 50% | Inverse Wave 4: retracement 3→4 = 161,8% | 3/4 |
| Wave 5 agresif | Dua order terpisah pada 23,6% dan 38,2% Wave 3 | Retracement 2→3 = 50% | Inverse Wave 4: retracement 3→4 = 123,6% dan 161,8% | 9/10 |
| Wave C konservatif | Retracement origin→A = 50% | Origin Wave A | Extension origin→A→B = 100% | 5/6 |
| Wave C agresif | Dua order terpisah pada 50% dan 61,8% Wave A | Origin Wave A | Sama seperti konservatif | 11/12 |

Inverse Wave 4 menggunakan P4 + r × (P3 − P4). Ini bukan extension panjang Wave 3 dari titik 4. Penerapan Wave C memerlukan A lima subwave, sehingga sesuai konteks Zigzag; jangan menyalinnya ke Flat yang Wave A-nya tiga atau Triangle/Diagonal. Pada komponen Zigzag, origin/A/B/C lokal dipetakan ke label utama yang sudah ada.

Level entry dan SL dapat direncanakan sesudah Wave 1/3/A selesai, sebelum pivot akhir koreksi 2/4/B diketahui. Target yang memakai 2/4/B baru dievaluasi setelah titik itu tersedia. Aplikasi menyebut kedua tahap itu secara eksplisit; level order tidak berarti fill sudah terjadi. Bila koreksi pada diagram tidak menyentuh level, order itu tetap belum terisi. Titik diagram tidak dipindahkan agar tampak cocok. Semua angka tetap skematis.

Tidak ada offset konfirmasi 10%, buffer stop 5%, tambahan toleransi Elliott, atau ukuran posisi otomatis. Angka risiko dari sumber dijelaskan sebagai isi sumber, bukan preset akun. Trade stop, pembatalan counting, dan target pedoman dijelaskan terpisah. Pada Wave 3, sumber menyebut break-even setelah TP1 dan evaluasi lima subwave; pada Wave 5/C setelah ekstrem Wave 3/A dilewati searah transaksi. Dua typo arah pada lembar sell dinormalisasi menurut simetri buy/sell dan geometri, bukan disalin sebagai aturan yang bertentangan.

Harmonic tidak mempunyai overlay Rencana Trading. Kontrol Channel dihapus dari seluruh diagram. SL yang sudah ada dalam pelajaran Fibonacci final D tetap merupakan bagian validasi keluarga pola; ia tidak diubah oleh lembar trading Elliott.

### Channeling dan struktur Elliott

- Impulse: 1–3 dengan paralel melalui 2 untuk konteks Wave 4. Sesudah 4 tersedia, 2–4 dengan paralel melalui 3 memberi konteks Wave 5; paralel melalui 1 adalah pedoman alternatif ketika 3 sangat kuat.
- Zigzag: origin A–akhir B dengan paralel melalui akhir A, yaitu 0–B/paralel A pada label 0ABC.
- Diagonal: batas wedge 1–3 dan 2–4. Triangle: batas A–C dan B–D. Bentuk tersebut tidak dipaksa menjadi kanal sejajar.
- Sudut 45°/60° pada layar bukan syarat harga karena bergantung skala dan zoom.
- Leading/Ending Diagonal halaman 21/22 cheatsheet hanya memberi tabel khusus Wave 2/4. Tidak ada tabel Wave 3/5 dan tidak ada halaman khusus Expanding Triangle. Penggaris pembanding tambahan tidak dipromosikan menjadi target baku pola.
- Untuk contracting diagonal, panjang motif 1>3>5. Sebuah proyeksi 1.618×Wave 1 untuk Wave 3 bertentangan dengan varian ini; rasio tanpa denominator/anchor tidak bermakna.
- Ending dapat memiliki truncation yang jarang; contoh tanpa truncation bukan larangan universal. Failed Wave Harmonic tidak memperbolehkan impulse Wave 3 gagal melewati ujung 1.

## Penyaringan inkonsistensi sumber

1. Ketidaksesuaian notasi 5-0 pada pengantar/tabel Volume 3 tidak mengubah geometri D sebagai 50% BC yang dijelaskan Volume Two dan diagram lengkap.
2. Rentang besar pada diagram Reciprocal AB=CD tidak dianggap sebagai pasangan reciprocal yang serentak untuk semua nilai.
3. Klasifikasi B yang disederhanakan Referensi Harmonic II halaman 354–355 tidak mengganti toleransi B dari acuan panduan yang sudah diterapkan.
4. Typo arah bearish BAMM pada Referensi Harmonic II halaman 375 tidak disalin; arah ditentukan dari geometri dan halaman lanjutan.
5. Stingray tetap varian HPX. Tidak ada klaim bahwa Carney menetapkan rasio/stop varian tersebut.
6. Istilah HOP tidak ditemukan dengan definisi terverifikasi pada empat berkas yang dibaca. Materi menggunakan konsep PEZ yang jelas didefinisikan Volume 3 halaman 174, dan tidak menciptakan formula HOP dari buffer. RSI BAMM/HSI dijelaskan sebagai metode tersendiri; RSI Divergence HPX tidak diklaim telah menghitungnya.
7. Pola yang telah gagal tetap dicatat gagal. Skenario/morphing berikutnya tidak menghapus keputusan atau SL sebelumnya.

## Cara materi digabung dan ditautkan

Setiap bagian mempunyai `id` stabil. Tautan memakai bentuk `/panduan/{kategori}/{slug}/#{id}`, diperiksa terhadap daftar 28 artikel dan ID bagian target. Penggabungan harus mengganti tambahan dengan ID yang sama agar proses berulang tidak menggandakan isi. Semua paragraf dan isi tabel tetap di-escape oleh generator HTML.

Materi tersedia offline, sedangkan situs bacaan lanjutan/video memerlukan internet. Konten tambahan menggunakan diagram aplikasi yang ada dan overlay asli; tidak memasukkan halaman buku atau menampilkan watermark pribadi sebagai ilustrasi produk.

Level Entry, SL dan TP pada Rencana trading ditampilkan dengan rasio Fibonacci dan urutan anchor pengukurannya. Harga skema menjadi keterangan pendamping; sumber rasio dan titik asli tidak berubah. Tidak ada pilihan tanpa setup pada dropdown.
