# Dasar penarikan Fibonacci dan istilah price action

Diperiksa 28 Oktober 2026. Seluruh 28 diagram lama dipertahankan, termasuk urutan titik dan nilainya. SHA-256 daftar pasangan slug/diagram sebelum penambahan metadata: `4569b9bb0bc38c69bf8b7ebff079895a420c71e9634a90d8364ec0e6fefbbf34`.

## Konvensi koordinat

Panel memakai harga linear dan titik pivot asli pada diagram. Untuk dua anchor P1 lalu P2, level retracement dihitung `P2 − r × (P2 − P1)`: nol berada di P2, satu kembali ke P1, dan angka di atas satu melewati P1. Untuk tiga anchor P1/P2/P3, proyeksi dihitung `P3 + r × (P2 − P1)`. Angka satu menyalin panjang dan arah P1–P2 dari P3. Bentuk cermin mengubah harga menjadi `k − harga` tetapi tidak mengubah rasionya.

Diagram bersifat skematis. Titik target diukur terpisah terhadap anchor yang dipilih; ia tidak dipindah agar tepat pada rasio acuan. Karena itu rasio aktual skema bisa berbeda dari garis 0,618 atau 1,618 yang dipakai sebagai pembanding. Ini mempertahankan materi dan mencegah kesan bahwa semua gambar sengaja cocok dengan semua rasio sekaligus.

- [TradingView: Fibonacci Retracement](https://www.tradingview.com/support/solutions/43000518158-fibonacci-retracement-drawing-tool/) menjelaskan alat dua ekstrem.
- [TradingView: Trend-Based Fib Extension](https://www.tradingview.com/support/solutions/43000518137-trend-based-fib-extension-drawing-tool/) menjelaskan urutan awal gerak, akhir gerak, lalu akhir retracement.
- [Elliott Wave International: Fibonacci Relationships](https://www.elliottwave.com/waveopedia/fibonacci-relationships/) mendasari pembandingan koreksi dan gerak motive pada derajat yang sesuai. Rasio Elliott diperlakukan sebagai pedoman, bukan hukum rasio wajib.
- [Elliott Wave International: Triangles](https://www.elliottwave.com/waveopedia/triangles/) membedakan contracting, barrier, expanding, dan running; menyatakan bahwa E dapat melampaui atau berhenti sebelum garis batas. Penempatan parent tetap harus diperiksa.

## Harmonic dan variasi HPX

Rasio setiap keluarga mengikuti tabel yang sudah ada di artikelnya serta catatan perbedaan engine dalam SOURCES.md. Cypher standar memakai seluruh XC untuk retracement D; 5-0 memakai BC untuk pullback 50%; AB=CD menyalin AB dari C. Shark pada gambar mengikuti notasi dan varian HPX yang dinyatakan, bukan pemindahan sembarang anchor ke notasi OXABC. Stingray mengikuti kode HPX khusus, tanpa klaim definisi kanonis dari sumber luar. Pengukuran CD/BC pada Stingray tidak diperkenalkan sebagai syarat baru.

- [Harmonic Trader: 5-0](https://harmonictrader.com/harmonic-patterns/5-0/) mendasari BC/AB serta CD/BC dan pembanding reciprocal AB=CD.
- [Harmonic Trader: Shark](https://harmonictrader.com/harmonic-patterns/shark-pattern/) mendasari perbedaan struktur ekstrem dengan bentuk M/W biasa.
- Sumber tiap keluarga lain tetap dicantumkan di halaman masing-masing.

## Istilah price action

Nama besar berwarna oranye dibagi berdasarkan hubungan yang dijelaskan, bukan dianggap sinonim sempurna. Expanding triangle diberi padanan bentuk **BROADENING FORMATION / MEGAPHONE**. **BROADENING WEDGE** ditampilkan sebagai sebutan terkait yang bersyarat: dua batas sama-sama miring ke satu arah dan melebar. Skema yang batas atasnya naik sementara batas bawah turun tidak otomatis merupakan broadening wedge.

Diagonal contracting dapat menyerupai rising/falling wedge, tetapi posisi wave 1/A atau 5/C dan subdivisi tetap membedakan Elliott. Konteks false breakout pada flat tidak digunakan untuk mengklaim niat pelaku pasar atau stop hunting. Siluet M/W Harmonic tidak otomatis disebut double top/bottom.

- [StockCharts ChartSchool: Broadening Top or Megaphone Top](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/broadening-top-or-megaphone-top)
- [StockCharts ChartSchool: Rising Wedge](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/rising-wedge)
- [StockCharts ChartSchool: Measured Move](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/measured-move-bullish)

Tes `test_guide_fibonacci_data.py` memeriksa seluruh anchor/target, invariansi bentuk cermin, rujukan XC/BC yang kritis, titik ketiga projection, origin komponen kompleks, dan perbedaan broadening formation dengan wedge.
