# RSI dan Stochastic Divergence — HPX 2.2.1

HPX Android **2.2.1 / versionCode 22001** dan HPX Windows **2.2.1** mengganti RSI serta Stochastic lama dengan port dari **RSIDiv.mq5 v3.00** dan **Stochastic_Div.mq5 v3.10** yang Anda berikan. Keduanya mendukung regular bullish/bearish dan hidden bullish/bearish divergence. EMA, ZWave, serta mesin harmonic HPX tetap memakai pengaturannya masing-masing.

## Memakai indikator

1. Pada **Chart**, pilih instrumen dan timeframe. Di tampilan ponsel, buka **Indikator & observasi sumber** untuk melihat panel **RSI Divergence** dan **Stochastic Div**.
2. Buka **Pengaturan → Indikator teknikal**, lalu bagian **Divergence & hidden divergence** untuk RSI atau Stochastic. Aktifkan **Garis divergence**, pilih regular bullish/bearish, dan nyalakan **Hidden divergence** bila diperlukan.
3. Atur pivot kiri/kanan, jarak maksimum antar-pivot harga, jumlah garis **per tipe**, label, warna, dan ketebalan. Tekan **Simpan** agar pilihan dipakai kembali saat aplikasi dibuka.
4. Ekspor PNG menyertakan garis dan label divergence pada panel indikator yang sedang terlihat. Buka panel sebelum mengekspor bila ingin menyertakannya.

Garis regular memakai gaya **utuh**: bearish berwarna merah dan bullish hijau. Garis hidden memakai gaya **putus-putus**: bearish oranye dan bullish aqua. Warna dapat diubah. Label RSI menunjukkan arah; Stochastic menggunakan **DIV** atau **HDIV**.

## Nilai awal dan sumber harga

- **RSI:** periode **14**, sumber **Close**, level **70 / 50 / 30**, maksimum **3 garis per tipe**, ketebalan **2**. Regular bullish/bearish aktif; **hidden awalnya nonaktif**, mengikuti source lampiran. Nyalakan sakelar Hidden pada pengaturan RSI untuk menampilkannya.
- **Stochastic:** **K 5 / D 3 / Slowing 3**, level **80 / 50 / 20**, maksimum **5 garis per tipe**, ketebalan **1**. Regular dan **hidden aktif** sejak awal. Kurva Main berwarna LightSeaGreen dan Signal merah bertitik.
- Sumber RSI tersedia dalam tujuh pilihan: **Close, Open, High, Low, Median (H+L)/2, Typical (H+L+C)/3, dan Weighted (H+L+2C)/4**.

RSI memakai smoothing Wilder dengan seed SMA; harga datar menghasilkan **50**. Main Stochastic mengikuti source: **100 × jumlah(close − lowest K) / jumlah(highest K − lowest K)** sepanjang Slowing, lalu Signal adalah SMA Main. Rentang datar menghasilkan **100**. Hasil dapat berbeda dari Stochastic HPX lama yang merata-ratakan persentase mentah.

## Membaca garis dan waktu konfirmasi

Regular bearish membandingkan harga yang membentuk higher high dengan oscillator lower high; regular bullish membandingkan lower low harga dengan higher low oscillator. Hidden bearish membandingkan lower high harga dengan higher high oscillator; hidden bullish membandingkan higher low harga dengan lower low oscillator.

Pivot harga dan oscillator dicari terpisah, lalu dipasangkan dengan pivot oscillator terdekat dalam toleransi **2 × pivot kanan**. Nilai yang sama pada tetangga kiri/kanan menggagalkan pivot. Garis hanya diterima bila tidak menembus kurva oscillator di antara kedua titiknya; sentuhan tepat pada garis diperbolehkan.

Titik garis ditempatkan pada candle pivot asal, tetapi baru diketahui setelah candle konfirmasi selesai. Pilihan awal pivot **kiri 5 / kanan 1** memerlukan sedikitnya satu candle selesai di kanan pivot. Metadata **known_at** adalah waktu pembukaan candle konfirmasi; sinyal tersedia setelah candle itu ditutup, bukan sejak candle pivot. Kurva dapat menampilkan candle berjalan, sementara divergence memakai candle selesai.

## Pembaruan pengaturan lama

Migrasi satu kali mengubah Stochastic lama **14/3/3 → 5/3/3** hanya bila pengaturan masih memakai format lama tanpa penanda model baru dan tanpa pengaturan divergence. Kombinasi periode Stochastic khusus tetap dipertahankan. Pengaturan RSI, EMA, level overbought/oversold, serta pilihan lain tetap dipertahankan; parameter divergence yang baru diisi dengan nilai awal di atas. Sesudah migrasi, perubahan periode yang Anda simpan tidak direset lagi oleh migrasi tersebut.

Untuk Android, pasang APK sebagai pembaruan **tanpa mencopot aplikasi lama**. Untuk Windows, tutup HPX lama, ganti EXE di folder yang sama, dan pertahankan folder **data**. Favorit browser juga memerlukan penyimpanan browser pada alamat localhost yang sama.

## Catatan port dan source

Port membatasi jumlah garis tepat sesuai pengaturan dan menghindari gambar berulang untuk endpoint yang sama. Source MT5 memangkas sebelum menambah objek sehingga dapat menyisakan satu garis lebih banyak. Nilai warmup Stochastic yang bergantung pada buffer ekstrem awal yang belum diisi tidak dipakai; validasi garis memeriksa seluruh interval, termasuk saat pivot kanan sangat besar melampaui ring history source. Penyesuaian ini dicatat pada metadata hasil.

Pembaruan ini mencakup perhitungan, konfigurasi, dan overlay RSI/Stochastic. Notifikasi pemantauan HPX tetap menggunakan fitur PRZ; pengiriman push melalui terminal MT5 tidak dipindahkan ke port ini. Kesamaan keluaran penuh dengan MT5 pada feed yang sama belum diverifikasi. Feed, panjang riwayat, dan pembentukan candle dapat memengaruhi hasil. Laporan verifikasi yang disertakan pada paket mencatat pengujian aktual beserta batasnya.

Pemberitahuan source **“Converted from TradingView Pine Script”** dipertahankan. Hash SHA-256 berkas lampiran:

- **RSIDiv.mq5:** `997fb5c0c23a2849b7478092e8ce433efafe28c13d55887ebfe0185d00d5cfec`
- **Stochastic_Div.mq5:** `cbc2e34e373b8545a806ea2e251ffda66dc8da3d8791bc936ac9014327c1bcca`
