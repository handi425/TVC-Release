# Panduan pola dan sakelar Harmonic

HPX Markets 2.5.2 menyediakan **Panduan** di navigasi Android dan bagian atas aplikasi Windows. Terdapat dua kategori: **Harmonic** dan **Elliott Wave**. Setiap pola memiliki alamat halaman tersendiri dengan diagram, karakter, aturan/rasio, reaksi bersyarat, pembatalan, kesalahan umum, serta referensi. Materi tersedia tanpa koneksi internet; tautan sumber luar memerlukan internet.

Kategori Harmonic mencakup sembilan keluarga deteksi HPX serta materi AB=CD, 5-0, dan Three Drives. Kategori Elliott menjelaskan fondasi, impulse, diagonal, zigzag, flat, triangle, dan kombinasi. Halaman menyatakan cakupan deteksi HPX agar materi belajar tidak dianggap sebagai fitur deteksi otomatis. Stingray dijelaskan sebagai definisi khusus HPX.

Pada **Chart**, tekan **Harmonic Aktif/Nonaktif** untuk menampilkan atau menyembunyikan pola, proyeksi, ringkasan, dan level Harmonic. Pilihan disimpan di perangkat. Tombol **Atur** membuka parameter Harmonic. Candle, RSI, Stochastic, dan ZWave tetap mengikuti pengaturan masing-masing. Radar dan pemantauan PRZ memakai pengaturan pemindaian sendiri sehingga tetap memeriksa pola ketika tampilan Harmonic Chart dinonaktifkan.

Label target Fibonacci menampilkan wave, rasio, dan harga. Kategori kelaziman dibedakan oleh warna garis/area, tanpa kata kategori pada target chart. Pilihan kategori dan warna tetap tersedia di Pengaturan agar dapat dipahami dan disesuaikan.

Materi disusun ulang dalam bahasa Indonesia dengan diagram lokal. Referensi primer dicantumkan pada setiap halaman. Rasio adalah aturan atau pedoman sesuai pola, bukan peluang keberhasilan atau janji pergerakan harga.

## Video kursus di atas setiap artikel

Setiap halaman menampilkan video dari kursus MR Poleks yang sesuai. Tekan **Putar video** untuk memuat pemutar YouTube; internet diperlukan untuk menonton. Materi teks dan diagram tetap tersedia tanpa internet. Tombol **Buka di YouTube** menjadi pilihan bila pemutar tidak tersedia.

Halaman Impulse menyediakan lima pilihan episode Wave 1–5. Alternate Bat dibuka pada bagian 02:33 dalam video Bat & Alt Bat. Stingray dan Expanding Triangle memakai dua video khusus terbaru yang diberikan pengguna. Judul video diverifikasi agar tidak tertukar dengan Expanded Flat.

## Fibonacci per wave dan per leg

Di bawah diagram **Bentuk pola**, tekan **Fibonacci** lalu pilih wave atau leg. Nomor 1–2 menunjukkan awal dan akhir ayunan untuk retracement; nomor 1–2–3 menunjukkan awal gerak, akhir gerak, lalu origin proyeksi untuk extension. Garis dan rasio dianimasikan pada titik diagram yang sama. Area rasio dan batas toleransi tampil otomatis; tekan **Ulangi animasi** untuk mengulang urutan titik. Bentuk cermin mempertahankan hubungan ukuran. Tersedia 141 langkah pada 28 artikel.

Panel membedakan rasio pembanding dengan rasio aktual pada skema. Titik pola tidak dipindahkan agar tampak cocok dengan rasio tertentu. Animasi mengikuti pengaturan pengurangan gerakan perangkat.

Sebutan price action ditulis dengan huruf kapital tebal berwarna oranye. Hubungan bentuk atau konteks dijelaskan di bawahnya. Expanding Triangle memiliki sebutan bentuk **BROADENING FORMATION / MEGAPHONE**; **BROADENING WEDGE** dijelaskan sebagai bentuk terkait dengan dua batas miring searah yang melebar. Nama price action tidak menggantikan aturan Harmonic atau Elliott.

## Area otomatis dan konfluensi

Pilihan rasio satu per satu diganti dengan area otomatis. Pada Harmonic, toleransi hanya diberikan pada B yang disebutkan oleh buku: BAT 5 poin pada acuan 50% (batas bawah tetap 38,2%, batas atas 55%), Gartley/Butterfly ±3 poin, dan Alternate BAT −3 poin. Pola tanpa toleransi B yang dinyatakan tidak diberi tambahan. C dan D memakai rasio/rentang asli tanpa pelebaran, termasuk semua sumber XA, BC, dan AB=CD pada langkah D terakhir. Nilai tunggal tetap berupa garis; irisan kosong tidak diperlebar agar terlihat berkonfluensi. SL skematis tetap terpisah dari toleransi validasi. Mesin deteksi Chart/Radar/Pantau tetap mengikuti parameter indikator HPX. Rasio Elliott tetap memakai acuan Elliott asli tanpa tambahan toleransi. Kategori Umum/Paling umum dipakai bila sumber memberikan peringkat; tabel tanpa peringkat disebut acuan. Batas struktur tetap berlaku. Lihat VALIDASI_FIBONACCI.md untuk metode, halaman referensi, serta catatan toleransi dan SL.
