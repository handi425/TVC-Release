﻿//+------------------------------------------------------------------+
//|                                              RSI Divergence.mq5  |
//|                          Converted from TradingView Pine Script  |
//|              RSI Divergence Lines v3 - Auto Line with Validation |
//+------------------------------------------------------------------+
//  Fitur:
//    - Deteksi Regular Bearish / Bullish Divergence
//    - Deteksi Hidden Bearish / Bullish Divergence
//    - Validasi: garis divergence TIDAK boleh menembus kurva RSI
//      di antara dua pivot yang dihubungkan
//    - Garis lama otomatis dihapus saat melebihi batas maksimum
//+------------------------------------------------------------------+
#property copyright "Converted from TradingView Pine Script"
#property link      ""
#property version   "3.00"
#property indicator_separate_window
#property indicator_buffers 1
#property indicator_plots   1
#property indicator_minimum 0
#property indicator_maximum 100

//--- RSI Plot
#property indicator_label1  "RSI"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrMediumPurple
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- Level Lines
#property indicator_level1  70
#property indicator_level2  50
#property indicator_level3  30
#property indicator_levelcolor clrGray
#property indicator_levelstyle STYLE_DOT

//+------------------------------------------------------------------+
//| Enums                                                             |
//+------------------------------------------------------------------+
enum ENUM_DIV_TYPE
{
   DIV_BEAR   = 0,  // Bearish
   DIV_BULL   = 1,  // Bullish
   DIV_HBEAR  = 2,  // Hidden Bearish
   DIV_HBULL  = 3   // Hidden Bullish
};

//+------------------------------------------------------------------+
//| Input Parameters                                                  |
//+------------------------------------------------------------------+
input string sep_rsi        = "═══════ Pengaturan RSI ═══════";       // ──────────────────
input int    InpRSILength   = 14;                                      // Panjang RSI
input ENUM_APPLIED_PRICE InpRSIPrice = PRICE_CLOSE;                    // Sumber RSI
input int    InpOverbought  = 70;                                      // Overbought Level
input int    InpOversold    = 30;                                      // Oversold Level

input string sep_pivot      = "═══════ Pengaturan Pivot ═══════";     // ──────────────────
input int    InpPivotLeft   = 5;                                       // Pivot Lookback Kiri
input int    InpPivotRight  = 1;                                       // Pivot Lookback Kanan

input string sep_div        = "═══════ Pengaturan Divergence ═══════";// ──────────────────
input int    InpMaxLookback = 60;                                      // Maks Jarak Candle
input int    InpMaxLines    = 3;                                       // Maks Garis per Tipe
input bool   InpShowBearish = true;                                    // Tampilkan Bearish Divergence
input bool   InpShowBullish = true;                                    // Tampilkan Bullish Divergence
input bool   InpShowHidden  = false;                                   // Tampilkan Hidden Divergence

input string sep_display    = "═══════ Tampilan ═══════";             // ──────────────────
input color  InpColorBear   = clrRed;                                  // Warna Bearish
input color  InpColorBull   = clrLime;                                 // Warna Bullish
input color  InpColorHBear  = clrOrange;                               // Warna Hidden Bearish
input color  InpColorHBull  = clrAqua;                                 // Warna Hidden Bullish
input int    InpLineWidth   = 2;                                       // Ketebalan Garis
input bool   InpShowLabel   = true;                                    // Tampilkan Label

input string sep_notify     = "Push Notification";
input bool   InpEnablePush  = true;                                    // Aktifkan push notification
input bool   InpNotifyOverbought = true;                               // Push saat RSI masuk overbought
input bool   InpNotifyOversold   = true;                               // Push saat RSI masuk oversold

//+------------------------------------------------------------------+
//| Buffers                                                           |
//+------------------------------------------------------------------+
double RSI_Buffer[];

//--- RSI indicator handle
int hRSI = INVALID_HANDLE;

//--- Indicator sub-window index
int subWindowIndex = -1;

//+------------------------------------------------------------------+
//| Pivot Storage Structures                                          |
//+------------------------------------------------------------------+
#define MAX_PIVOT 50

struct SPivotData
{
   double val[];
   int    bar[];
   int    count;
   
   void Init()
   {
      ArrayResize(val, MAX_PIVOT);
      ArrayResize(bar, MAX_PIVOT);
      count = 0;
   }
   
   void Push(double v, int b)
   {
      if(count >= MAX_PIVOT)
      {
         // Shift left
         for(int i = 0; i < MAX_PIVOT - 1; i++)
         {
            val[i] = val[i + 1];
            bar[i] = bar[i + 1];
         }
         count = MAX_PIVOT - 1;
      }
      val[count] = v;
      bar[count] = b;
      count++;
   }
};

//--- Pivot arrays
SPivotData g_phPrice;   // Pivot High - Price
SPivotData g_phRsi;     // Pivot High - RSI
SPivotData g_plPrice;   // Pivot Low  - Price
SPivotData g_plRsi;     // Pivot Low  - RSI

//--- RSI history for line validation
double g_rsiHist[];
int    g_rsiHistBar[];
int    g_rsiHistCount;
int    g_rsiHistMaxSize;

//--- Divergence line/label tracking
struct SDivLines
{
   string names[];
   int    count;
   
   void Init()
   {
      ArrayResize(names, 0);
      count = 0;
   }
   
   void AddName(string name)
   {
      count++;
      ArrayResize(names, count);
      names[count - 1] = name;
   }
   
   void TrimToMax(int maxCount)
   {
      // Each divergence = 1 line + possibly 1 label = up to 2 objects
      // But we track lines and labels separately in names
      while(count > maxCount)
      {
         ObjectDelete(0, names[0]);
         for(int i = 0; i < count - 1; i++)
            names[i] = names[i + 1];
         count--;
         ArrayResize(names, count);
      }
   }
};

SDivLines g_linesBear, g_linesBull, g_linesHBear, g_linesHBull;
SDivLines g_lblsBear,  g_lblsBull,  g_lblsHBear,  g_lblsHBull;

//--- Unique object counter
int g_objCounter = 0;

//--- Track last processed bar to avoid duplicates
int g_lastProcessedBar = -1;
int g_lastOverboughtNotifyBar = -1;
int g_lastOversoldNotifyBar = -1;
bool g_pushWarningLogged = false;

//+------------------------------------------------------------------+
//| Custom indicator initialization function                          |
//+------------------------------------------------------------------+
int OnInit()
{
   //--- Validate inputs
   if(InpRSILength < 1)
   {
      Print("RSI Length must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(InpPivotLeft < 1 || InpPivotRight < 1)
   {
      Print("Pivot lookback must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   
   //--- Set buffer
   SetIndexBuffer(0, RSI_Buffer, INDICATOR_DATA);
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   
   //--- Custom levels for OB/OS
   IndicatorSetInteger(INDICATOR_LEVELS, 3);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 0, InpOverbought);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 1, 50);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 2, InpOversold);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 0, clrRed);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 1, clrGray);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 2, clrLime);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 0, STYLE_DASH);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 1, STYLE_DOT);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 2, STYLE_DASH);
   
   //--- Create RSI handle
   hRSI = iRSI(_Symbol, PERIOD_CURRENT, InpRSILength, InpRSIPrice);
   if(hRSI == INVALID_HANDLE)
   {
      Print("Failed to create RSI handle");
      return INIT_FAILED;
   }
   
   //--- Init pivot data
   g_phPrice.Init();
   g_phRsi.Init();
   g_plPrice.Init();
   g_plRsi.Init();
   
   //--- Init RSI history
   g_rsiHistMaxSize = InpMaxLookback + 50;
   ArrayResize(g_rsiHist, g_rsiHistMaxSize);
   ArrayResize(g_rsiHistBar, g_rsiHistMaxSize);
   g_rsiHistCount = 0;
   
   //--- Init line tracking
   g_linesBear.Init();  g_linesBull.Init();
   g_linesHBear.Init(); g_linesHBull.Init();
   g_lblsBear.Init();   g_lblsBull.Init();
   g_lblsHBear.Init();  g_lblsHBull.Init();
   
   g_objCounter = 0;
   g_lastProcessedBar = -1;
   g_lastOverboughtNotifyBar = -1;
   g_lastOversoldNotifyBar = -1;
   g_pushWarningLogged = false;
   
   //--- Set indicator name
   IndicatorSetString(INDICATOR_SHORTNAME, "RSI Div v3");
   
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Custom indicator deinitialization                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(hRSI != INVALID_HANDLE)
      IndicatorRelease(hRSI);
   
   //--- Hapus semua objek milik indikator
   ObjectsDeleteAll(0, "RSIDiv_");
}

//+------------------------------------------------------------------+
//| Detect pivot high in array data                                   |
//| Returns the pivot value or EMPTY_VALUE if no pivot found          |
//+------------------------------------------------------------------+
double PivotHigh(const double &data[], int index, int leftBars, int rightBars, int totalBars)
{
   // Pivot is at index - rightBars (confirmed after rightBars bars)
   int pivotIdx = index - rightBars;
   if(pivotIdx < leftBars || pivotIdx >= totalBars - rightBars)
      return EMPTY_VALUE;
   
   double pivotVal = data[pivotIdx];
   
   // Check left side
   for(int i = 1; i <= leftBars; i++)
   {
      int checkIdx = pivotIdx - i;
      if(checkIdx < 0) return EMPTY_VALUE;
      if(data[checkIdx] >= pivotVal) return EMPTY_VALUE;
   }
   
   // Check right side  
   for(int i = 1; i <= rightBars; i++)
   {
      int checkIdx = pivotIdx + i;
      if(checkIdx >= totalBars) return EMPTY_VALUE;
      if(data[checkIdx] >= pivotVal) return EMPTY_VALUE;
   }
   
   return pivotVal;
}

//+------------------------------------------------------------------+
//| Detect pivot low in array data                                    |
//+------------------------------------------------------------------+
double PivotLow(const double &data[], int index, int leftBars, int rightBars, int totalBars)
{
   int pivotIdx = index - rightBars;
   if(pivotIdx < leftBars || pivotIdx >= totalBars - rightBars)
      return EMPTY_VALUE;
   
   double pivotVal = data[pivotIdx];
   
   // Check left side
   for(int i = 1; i <= leftBars; i++)
   {
      int checkIdx = pivotIdx - i;
      if(checkIdx < 0) return EMPTY_VALUE;
      if(data[checkIdx] <= pivotVal) return EMPTY_VALUE;
   }
   
   // Check right side
   for(int i = 1; i <= rightBars; i++)
   {
      int checkIdx = pivotIdx + i;
      if(checkIdx >= totalBars) return EMPTY_VALUE;
      if(data[checkIdx] <= pivotVal) return EMPTY_VALUE;
   }
   
   return pivotVal;
}

//+------------------------------------------------------------------+
//| Push RSI history value                                            |
//+------------------------------------------------------------------+
void PushRSIHistory(double rsiVal, int barIdx)
{
   if(g_rsiHistCount >= g_rsiHistMaxSize)
   {
      // Shift left
      for(int i = 0; i < g_rsiHistMaxSize - 1; i++)
      {
         g_rsiHist[i] = g_rsiHist[i + 1];
         g_rsiHistBar[i] = g_rsiHistBar[i + 1];
      }
      g_rsiHistCount = g_rsiHistMaxSize - 1;
   }
   g_rsiHist[g_rsiHistCount] = rsiVal;
   g_rsiHistBar[g_rsiHistCount] = barIdx;
   g_rsiHistCount++;
}

//+------------------------------------------------------------------+
//| Convert timeframe enum to compact text                            |
//+------------------------------------------------------------------+
string TimeframeToString(ENUM_TIMEFRAMES timeframe)
{
   switch(timeframe)
   {
      case PERIOD_M1:  return "M1";
      case PERIOD_M2:  return "M2";
      case PERIOD_M3:  return "M3";
      case PERIOD_M4:  return "M4";
      case PERIOD_M5:  return "M5";
      case PERIOD_M6:  return "M6";
      case PERIOD_M10: return "M10";
      case PERIOD_M12: return "M12";
      case PERIOD_M15: return "M15";
      case PERIOD_M20: return "M20";
      case PERIOD_M30: return "M30";
      case PERIOD_H1:  return "H1";
      case PERIOD_H2:  return "H2";
      case PERIOD_H3:  return "H3";
      case PERIOD_H4:  return "H4";
      case PERIOD_H6:  return "H6";
      case PERIOD_H8:  return "H8";
      case PERIOD_H12: return "H12";
      case PERIOD_D1:  return "D1";
      case PERIOD_W1:  return "W1";
      case PERIOD_MN1: return "MN1";
   }
   return EnumToString(timeframe);
}

//+------------------------------------------------------------------+
//| Send push notification if MT5 terminal is configured              |
//+------------------------------------------------------------------+
bool SendPushMessage(const string message)
{
   if(!InpEnablePush)
      return false;

   if(MQLInfoInteger(MQL_TESTER))
      return false;

   if(!TerminalInfoInteger(TERMINAL_NOTIFICATIONS_ENABLED))
   {
      if(!g_pushWarningLogged)
      {
         Print("Push notifications disabled. Enable them in Tools > Options > Notifications.");
         g_pushWarningLogged = true;
      }
      return false;
   }

   ResetLastError();
   if(!SendNotification(message))
   {
      PrintFormat("SendNotification failed (%d): %s", GetLastError(), message);
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Notify only when RSI enters OB/OS zone on a closed candle         |
//+------------------------------------------------------------------+
void CheckZoneNotifications(const int barIndex, const datetime &time[])
{
   if(barIndex <= 0)
      return;

   double prevRsi = RSI_Buffer[barIndex - 1];
   double currRsi = RSI_Buffer[barIndex];
   if(prevRsi == EMPTY_VALUE || currRsi == EMPTY_VALUE)
      return;

   string timeframe = TimeframeToString((ENUM_TIMEFRAMES)_Period);
   string barTime = TimeToString(time[barIndex], TIME_DATE | TIME_MINUTES);

   if(InpNotifyOverbought &&
      prevRsi < InpOverbought &&
      currRsi >= InpOverbought &&
      g_lastOverboughtNotifyBar != barIndex)
   {
      string message = StringFormat("[RSI Div] %s %s overbought: RSI %.2f at %s",
                                    _Symbol, timeframe, currRsi, barTime);
      if(SendPushMessage(message))
         g_lastOverboughtNotifyBar = barIndex;
   }

   if(InpNotifyOversold &&
      prevRsi > InpOversold &&
      currRsi <= InpOversold &&
      g_lastOversoldNotifyBar != barIndex)
   {
      string message = StringFormat("[RSI Div] %s %s oversold: RSI %.2f at %s",
                                    _Symbol, timeframe, currRsi, barTime);
      if(SendPushMessage(message))
         g_lastOversoldNotifyBar = barIndex;
   }
}

//+------------------------------------------------------------------+
//| Validate divergence line - check if line crosses RSI curve        |
//| divType: DIV_BEAR/DIV_HBEAR → line must be >= RSI (above RSI)    |
//|          DIV_BULL/DIV_HBULL → line must be <= RSI (below RSI)     |
//| Returns true if line is CLEAR (does not cross RSI)                |
//+------------------------------------------------------------------+
bool IsLineClear(int x1, double y1, int x2, double y2, ENUM_DIV_TYPE divType)
{
   int span = x2 - x1;
   if(span <= 1) return true;
   
   for(int j = 0; j < g_rsiHistCount; j++)
   {
      int b = g_rsiHistBar[j];
      
      // Only check bars BETWEEN x1 and x2 (exclusive)
      if(b > x1 && b < x2)
      {
         double rsiAtBar = g_rsiHist[j];
         
         // Linear interpolation: value of line at bar b
         double t = (double)(b - x1) / (double)span;
         double lineVal = y1 + t * (y2 - y1);
         
         // Bearish/Hidden Bearish: RSI must not go above the line
         if((divType == DIV_BEAR || divType == DIV_HBEAR) && rsiAtBar > lineVal)
            return false;
         
         // Bullish/Hidden Bullish: RSI must not go below the line
         if((divType == DIV_BULL || divType == DIV_HBULL) && rsiAtBar < lineVal)
            return false;
      }
   }
   
   return true;
}

//+------------------------------------------------------------------+
//| Find matching RSI pivot closest to a price pivot bar              |
//+------------------------------------------------------------------+
bool FindMatchingRSI(const SPivotData &rsiData, int targetBar,
                     int &matchBar, double &matchVal)
{
   matchBar = -1;
   matchVal = EMPTY_VALUE;
   int minDist = 999;
   
   if(rsiData.count < 2) return false;
   
   for(int i = rsiData.count - 1; i >= 0; i--)
   {
      int b = rsiData.bar[i];
      double v = rsiData.val[i];
      int d = MathAbs(b - targetBar);
      
      if(d <= InpPivotRight * 2 && d < minDist)
      {
         minDist = d;
         matchVal = v;
         matchBar = b;
      }
   }
   
   return (matchBar >= 0 && matchVal != EMPTY_VALUE);
}

//+------------------------------------------------------------------+
//| Get sub-window index (lazy init)                                  |
//+------------------------------------------------------------------+
int GetSubWindow()
{
   if(subWindowIndex < 0)
   {
      subWindowIndex = ChartWindowFind(0, "RSI Div v3");
      if(subWindowIndex < 0) subWindowIndex = 0;
   }
   return subWindowIndex;
}

//+------------------------------------------------------------------+
//| Helper: Trim lines by divergence type                             |
//+------------------------------------------------------------------+
void TrimLinesByType(ENUM_DIV_TYPE divType, int maxCount)
{
   switch(divType)
   {
      case DIV_BEAR:  g_linesBear.TrimToMax(maxCount); g_lblsBear.TrimToMax(maxCount); break;
      case DIV_BULL:  g_linesBull.TrimToMax(maxCount); g_lblsBull.TrimToMax(maxCount); break;
      case DIV_HBEAR: g_linesHBear.TrimToMax(maxCount); g_lblsHBear.TrimToMax(maxCount); break;
      case DIV_HBULL: g_linesHBull.TrimToMax(maxCount); g_lblsHBull.TrimToMax(maxCount); break;
   }
}

//+------------------------------------------------------------------+
//| Helper: Add line object name to tracking                          |
//+------------------------------------------------------------------+
void AddLineName(ENUM_DIV_TYPE divType, string name)
{
   switch(divType)
   {
      case DIV_BEAR:  g_linesBear.AddName(name); break;
      case DIV_BULL:  g_linesBull.AddName(name); break;
      case DIV_HBEAR: g_linesHBear.AddName(name); break;
      case DIV_HBULL: g_linesHBull.AddName(name); break;
   }
}

//+------------------------------------------------------------------+
//| Helper: Add label object name to tracking                         |
//+------------------------------------------------------------------+
void AddLblName(ENUM_DIV_TYPE divType, string name)
{
   switch(divType)
   {
      case DIV_BEAR:  g_lblsBear.AddName(name); break;
      case DIV_BULL:  g_lblsBull.AddName(name); break;
      case DIV_HBEAR: g_lblsHBear.AddName(name); break;
      case DIV_HBULL: g_lblsHBull.AddName(name); break;
   }
}

//+------------------------------------------------------------------+
//| Draw divergence line and label                                    |
//+------------------------------------------------------------------+
void DrawDivergence(ENUM_DIV_TYPE divType,
                    int x1, double y1, int x2, double y2,
                    color clr, string labelText)
{
   //--- Get sub-window
   int win = GetSubWindow();
   
   //--- Convert bar indices to time
   int totalBars = Bars(_Symbol, PERIOD_CURRENT);
   int shift1 = totalBars - 1 - x1;
   int shift2 = totalBars - 1 - x2;
   
   if(shift1 < 0) shift1 = 0;
   if(shift2 < 0) shift2 = 0;
   
   datetime time1 = iTime(_Symbol, PERIOD_CURRENT, shift1);
   datetime time2 = iTime(_Symbol, PERIOD_CURRENT, shift2);
   
   if(time1 == 0 || time2 == 0) return;
   
   //--- Determine line style and prefix
   ENUM_LINE_STYLE lineStyle = STYLE_SOLID;
   string prefix = "";
   
   switch(divType)
   {
      case DIV_BEAR:  lineStyle = STYLE_SOLID; prefix = "Bear";  break;
      case DIV_BULL:  lineStyle = STYLE_SOLID; prefix = "Bull";  break;
      case DIV_HBEAR: lineStyle = STYLE_DASH;  prefix = "HBear"; break;
      case DIV_HBULL: lineStyle = STYLE_DASH;  prefix = "HBull"; break;
   }
   
   //--- Enforce max lines: delete oldest
   TrimLinesByType(divType, InpMaxLines);
   
   //--- Create unique object names
   g_objCounter++;
   string lineName = "RSIDiv_L_" + prefix + "_" + IntegerToString(g_objCounter);
   string lblName  = "RSIDiv_T_" + prefix + "_" + IntegerToString(g_objCounter);
   
   //--- Draw trend line on RSI sub-window
   if(ObjectCreate(0, lineName, OBJ_TREND, win, time1, y1, time2, y2))
   {
      ObjectSetInteger(0, lineName, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, lineName, OBJPROP_WIDTH, InpLineWidth);
      ObjectSetInteger(0, lineName, OBJPROP_STYLE, lineStyle);
      ObjectSetInteger(0, lineName, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, lineName, OBJPROP_RAY_LEFT, false);
      ObjectSetInteger(0, lineName, OBJPROP_BACK, false);
      ObjectSetInteger(0, lineName, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, lineName, OBJPROP_HIDDEN, true);
      AddLineName(divType, lineName);
   }
   
   //--- Draw label
   if(InpShowLabel)
   {
      double yOff;
      ENUM_ANCHOR_POINT anchor;
      
      if(divType == DIV_BEAR || divType == DIV_HBEAR)
      {
         yOff = y2 + 2.0;
         anchor = ANCHOR_LOWER;
      }
      else
      {
         yOff = y2 - 2.0;
         anchor = ANCHOR_UPPER;
      }
      
      if(ObjectCreate(0, lblName, OBJ_TEXT, win, time2, yOff))
      {
         ObjectSetString(0, lblName, OBJPROP_TEXT, labelText);
         ObjectSetInteger(0, lblName, OBJPROP_COLOR, clr);
         ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, 8);
         ObjectSetString(0, lblName, OBJPROP_FONT, "Arial Bold");
         ObjectSetInteger(0, lblName, OBJPROP_ANCHOR, anchor);
         ObjectSetInteger(0, lblName, OBJPROP_SELECTABLE, false);
         ObjectSetInteger(0, lblName, OBJPROP_HIDDEN, true);
         AddLblName(divType, lblName);
      }
   }
}

//+------------------------------------------------------------------+
//| Process divergences at current bar                                |
//+------------------------------------------------------------------+
void ProcessDivergences(int barIndex, 
                        const double &high[],
                        const double &low[],
                        int rates_total)
{
   //--- BEARISH: Price Higher High, RSI Lower High
   if(InpShowBearish && g_phPrice.count >= 2)
   {
      int   curPBar = g_phPrice.bar[g_phPrice.count - 1];
      double curPVal = g_phPrice.val[g_phPrice.count - 1];
      
      for(int i = g_phPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_phPrice.bar[i];
         double prevPVal = g_phPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal > prevPVal)
         {
            int curRBar, prevRBar;
            double curRVal, prevRVal;
            
            if(FindMatchingRSI(g_phRsi, curPBar, curRBar, curRVal) &&
               FindMatchingRSI(g_phRsi, prevPBar, prevRBar, prevRVal))
            {
               if(curRVal < prevRVal)
               {
                  if(IsLineClear(prevRBar, prevRVal, curRBar, curRVal, DIV_BEAR))
                  {
                     DrawDivergence(DIV_BEAR, prevRBar, prevRVal, curRBar, curRVal,
                                    InpColorBear, "Bear Div");
                     break;
                  }
               }
            }
         }
      }
   }
   
   //--- BULLISH: Price Lower Low, RSI Higher Low
   if(InpShowBullish && g_plPrice.count >= 2)
   {
      int   curPBar = g_plPrice.bar[g_plPrice.count - 1];
      double curPVal = g_plPrice.val[g_plPrice.count - 1];
      
      for(int i = g_plPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_plPrice.bar[i];
         double prevPVal = g_plPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal < prevPVal)
         {
            int curRBar, prevRBar;
            double curRVal, prevRVal;
            
            if(FindMatchingRSI(g_plRsi, curPBar, curRBar, curRVal) &&
               FindMatchingRSI(g_plRsi, prevPBar, prevRBar, prevRVal))
            {
               if(curRVal > prevRVal)
               {
                  if(IsLineClear(prevRBar, prevRVal, curRBar, curRVal, DIV_BULL))
                  {
                     DrawDivergence(DIV_BULL, prevRBar, prevRVal, curRBar, curRVal,
                                    InpColorBull, "Bull Div");
                     break;
                  }
               }
            }
         }
      }
   }
   
   //--- HIDDEN BEARISH: Price Lower High, RSI Higher High
   if(InpShowHidden && g_phPrice.count >= 2)
   {
      int   curPBar = g_phPrice.bar[g_phPrice.count - 1];
      double curPVal = g_phPrice.val[g_phPrice.count - 1];
      
      for(int i = g_phPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_phPrice.bar[i];
         double prevPVal = g_phPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal < prevPVal)
         {
            int curRBar, prevRBar;
            double curRVal, prevRVal;
            
            if(FindMatchingRSI(g_phRsi, curPBar, curRBar, curRVal) &&
               FindMatchingRSI(g_phRsi, prevPBar, prevRBar, prevRVal))
            {
               if(curRVal > prevRVal)
               {
                  if(IsLineClear(prevRBar, prevRVal, curRBar, curRVal, DIV_HBEAR))
                  {
                     DrawDivergence(DIV_HBEAR, prevRBar, prevRVal, curRBar, curRVal,
                                    InpColorHBear, "H.Bear");
                     break;
                  }
               }
            }
         }
      }
   }
   
   //--- HIDDEN BULLISH: Price Higher Low, RSI Lower Low
   if(InpShowHidden && g_plPrice.count >= 2)
   {
      int   curPBar = g_plPrice.bar[g_plPrice.count - 1];
      double curPVal = g_plPrice.val[g_plPrice.count - 1];
      
      for(int i = g_plPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_plPrice.bar[i];
         double prevPVal = g_plPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal > prevPVal)
         {
            int curRBar, prevRBar;
            double curRVal, prevRVal;
            
            if(FindMatchingRSI(g_plRsi, curPBar, curRBar, curRVal) &&
               FindMatchingRSI(g_plRsi, prevPBar, prevRBar, prevRVal))
            {
               if(curRVal < prevRVal)
               {
                  if(IsLineClear(prevRBar, prevRVal, curRBar, curRVal, DIV_HBULL))
                  {
                     DrawDivergence(DIV_HBULL, prevRBar, prevRVal, curRBar, curRVal,
                                    InpColorHBull, "H.Bull");
                     break;
                  }
               }
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Custom indicator iteration function                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < InpRSILength + InpPivotLeft + InpPivotRight + 1)
      return 0;

   bool allowZoneNotifications = (prev_calculated > 0);
   
   //--- Copy RSI data
   int copied = CopyBuffer(hRSI, 0, 0, rates_total, RSI_Buffer);
   if(copied <= 0) return 0;
   
   //--- Determine start bar
   int startBar;
   if(prev_calculated == 0)
   {
      startBar = InpRSILength + InpPivotLeft + InpPivotRight;
      
      //--- Reset all data on full recalculation
      g_phPrice.Init();
      g_phRsi.Init();
      g_plPrice.Init();
      g_plRsi.Init();
      g_rsiHistCount = 0;
      g_lastProcessedBar = -1;
      g_lastOverboughtNotifyBar = -1;
      g_lastOversoldNotifyBar = -1;
      g_pushWarningLogged = false;
      
      //--- Clean old objects
      ObjectsDeleteAll(0, "RSIDiv_");
      g_linesBear.Init();  g_linesBull.Init();
      g_linesHBear.Init(); g_linesHBull.Init();
      g_lblsBear.Init();   g_lblsBull.Init();
      g_lblsHBear.Init();  g_lblsHBull.Init();
      g_objCounter = 0;
      
      //--- Reset sub-window index
      subWindowIndex = -1;
   }
   else
   {
      startBar = prev_calculated - 1;
   }
   
   //--- Process only CLOSED bars (exclude current forming bar)
   //    This ensures pivots are confirmed only with completed candles.
   //    Lines are drawn immediately when the confirming candle closes.
   int limit = rates_total - 1;  // last closed bar index = rates_total - 2
   for(int i = startBar; i < limit; i++)
   {
      double rsiVal = RSI_Buffer[i];
      if(rsiVal == EMPTY_VALUE) continue;
      
      //--- Push RSI history
      PushRSIHistory(rsiVal, i);

      if(allowZoneNotifications)
         CheckZoneNotifications(i, time);
      
      //--- Detect pivots (confirmed at bar i - pivotRight)
      // Pivot High on Price (High)
      double phPrice = PivotHigh(high, i, InpPivotLeft, InpPivotRight, rates_total);
      if(phPrice != EMPTY_VALUE)
      {
         g_phPrice.Push(phPrice, i - InpPivotRight);
      }
      
      // Pivot High on RSI
      double phRsi = PivotHigh(RSI_Buffer, i, InpPivotLeft, InpPivotRight, rates_total);
      if(phRsi != EMPTY_VALUE)
      {
         g_phRsi.Push(phRsi, i - InpPivotRight);
      }
      
      // Pivot Low on Price (Low)
      double plPrice = PivotLow(low, i, InpPivotLeft, InpPivotRight, rates_total);
      if(plPrice != EMPTY_VALUE)
      {
         g_plPrice.Push(plPrice, i - InpPivotRight);
      }
      
      // Pivot Low on RSI
      double plRsi = PivotLow(RSI_Buffer, i, InpPivotLeft, InpPivotRight, rates_total);
      if(plRsi != EMPTY_VALUE)
      {
         g_plRsi.Push(plRsi, i - InpPivotRight);
      }
      
      //--- Process divergences only when a new pivot is detected
      //    and only on the latest bars (avoid re-drawing old divergences)
      bool newPivot = (phPrice != EMPTY_VALUE || phRsi != EMPTY_VALUE ||
                       plPrice != EMPTY_VALUE || plRsi != EMPTY_VALUE);
      
      if(newPivot && i > g_lastProcessedBar)
      {
         g_lastProcessedBar = i;
         ProcessDivergences(i, high, low, rates_total);
      }
   }
   
   return rates_total;
}
//+------------------------------------------------------------------+
