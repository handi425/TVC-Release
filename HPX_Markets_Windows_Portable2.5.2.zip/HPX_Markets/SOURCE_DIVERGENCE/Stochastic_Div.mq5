//+------------------------------------------------------------------+
//|                                   Stochastic Divergence.mq5      |
//|                          Converted from TradingView Pine Script  |
//|      Stochastic Divergence Lines v3 - Auto Line with Validation |
//+------------------------------------------------------------------+
//  Fitur:
//    - Deteksi Regular Bearish / Bullish Divergence
//    - Deteksi Hidden Bearish / Bullish Divergence
//    - Validasi: garis divergence TIDAK boleh menembus kurva Stochastic
//      di antara dua pivot yang dihubungkan
//    - Garis lama otomatis dihapus saat melebihi batas maksimum
//+------------------------------------------------------------------+
#property copyright "Converted from TradingView Pine Script"
#property link      ""
#property version   "3.10"
#property indicator_separate_window
#property indicator_buffers 4
#property indicator_plots   2
#property indicator_minimum 0
#property indicator_maximum 100

//--- Stochastic Main Plot
#property indicator_label1  "Main"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrLightSeaGreen
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- Stochastic Signal Plot
#property indicator_label2  "Signal"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrRed
#property indicator_style2  STYLE_DOT
#property indicator_width2  1

//--- Level Lines
#property indicator_level1  80
#property indicator_level2  50
#property indicator_level3  20
#property indicator_levelcolor clrGray
#property indicator_levelstyle STYLE_DOT

//+------------------------------------------------------------------+
//| Enums                                                             |
//+------------------------------------------------------------------+
enum ENUM_DIV_TYPE
{
   DIV_BEAR   = 0,  // Bearish
   DIV_BULL   = 1,  // Bullish
   DIV_HBEAR  = 2,  // Hidden Bearish
   DIV_HBULL  = 3   // Hidden Bullish
};

//+------------------------------------------------------------------+
//| Input Parameters                                                  |
//+------------------------------------------------------------------+
input string sep_stoch      = "═══════ Pengaturan Stochastic ═══════"; // ──────────────────
input int    InpKPeriod     = 5;                                       // K period
input int    InpDPeriod     = 3;                                       // D period
input int    InpSlowing     = 3;                                       // Slowing

input string sep_pivot      = "═══════ Pengaturan Pivot ═══════";     // ──────────────────
input int    InpPivotLeft   = 5;                                       // Pivot Lookback Kiri
input int    InpPivotRight  = 1;                                       // Pivot Lookback Kanan

input string sep_div        = "═══════ Pengaturan Divergence ═══════";// ──────────────────
input int    InpMaxLookback = 60;                                      // Maks Jarak Candle
input int    InpMaxLines    = 5;                                       // Maks Garis per Tipe
input bool   InpShowBearish = true;                                    // Tampilkan Bearish Divergence
input bool   InpShowBullish = true;                                    // Tampilkan Bullish Divergence
input bool   InpShowHidden  = true;                                   // Tampilkan Hidden Divergence

input string sep_display    = "═══════ Tampilan ═══════";             // ──────────────────
input color  InpColorBear   = clrRed;                                  // Warna Bearish
input color  InpColorBull   = clrLime;                                 // Warna Bullish
input color  InpColorHBear  = clrOrange;                               // Warna Hidden Bearish
input color  InpColorHBull  = clrAqua;                                 // Warna Hidden Bullish
input int    InpLineWidth   = 1;                                       // Ketebalan Garis
input bool   InpShowLabel   = true;                                    // Tampilkan Label

input string sep_notify     = "Push Notification";
input bool   InpEnablePush  = true;                                    // Aktifkan push notification

//+------------------------------------------------------------------+
//| Buffers                                                           |
//+------------------------------------------------------------------+
double    ExtMainBuffer[];
double    ExtSignalBuffer[];
double    ExtHighesBuffer[];
double    ExtLowesBuffer[];

//--- Stochastic history for line validation
double g_stochHist[];
int    g_stochHistBar[];
int    g_stochHistCount;
int    g_stochHistMaxSize;

//+------------------------------------------------------------------+
//| Pivot Storage Structures                                          |
//+------------------------------------------------------------------+
#define MAX_PIVOT 50

struct SPivotData
{
   double val[];
   int    bar[];
   int    count;
   
   void Init()
   {
      ArrayResize(val, MAX_PIVOT);
      ArrayResize(bar, MAX_PIVOT);
      count = 0;
   }
   
   void Push(double v, int b)
   {
      if(count >= MAX_PIVOT)
      {
         for(int i = 0; i < MAX_PIVOT - 1; i++)
         {
            val[i] = val[i + 1];
            bar[i] = bar[i + 1];
         }
         count = MAX_PIVOT - 1;
      }
      val[count] = v;
      bar[count] = b;
      count++;
   }
};

//--- Pivot arrays
SPivotData g_phPrice;   // Pivot High - Price
SPivotData g_phStoch;   // Pivot High - Stochastic
SPivotData g_plPrice;   // Pivot Low  - Price
SPivotData g_plStoch;   // Pivot Low  - Stochastic

//--- Divergence line/label tracking
struct SDivLines
{
   string names[];
   int    count;
   
   void Init()
   {
      ArrayResize(names, 0);
      count = 0;
   }
   
   void AddName(string name)
   {
      count++;
      ArrayResize(names, count);
      names[count - 1] = name;
   }
   
   void TrimToMax(int maxCount)
   {
      while(count > maxCount)
      {
         ObjectDelete(0, names[0]);
         for(int i = 0; i < count - 1; i++)
            names[i] = names[i + 1];
         count--;
         ArrayResize(names, count);
      }
   }
};

SDivLines g_linesBear, g_linesBull, g_linesHBear, g_linesHBull;
SDivLines g_lblsBear,  g_lblsBull,  g_lblsHBear,  g_lblsHBull;

//--- Unique object counter
int g_objCounter = 0;

//--- Track last processed bar to avoid duplicates
int g_lastProcessedBar = -1;
datetime g_lastDivergencePivotTime[4];
bool g_pushWarningLogged = false;

//--- Indicator sub-window index
int subWindowIndex = -1;

//+------------------------------------------------------------------+
//| Custom indicator initialization function                          |
//+------------------------------------------------------------------+
int OnInit()
{
   //--- Validate inputs
   if(InpKPeriod < 1)
   {
      Print("K Period must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(InpDPeriod < 1)
   {
      Print("D Period must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(InpSlowing < 1)
   {
      Print("Slowing must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   if(InpPivotLeft < 1 || InpPivotRight < 1)
   {
      Print("Pivot lookback must be >= 1");
      return INIT_PARAMETERS_INCORRECT;
   }
   
   //--- Set buffer
   SetIndexBuffer(0, ExtMainBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, ExtSignalBuffer, INDICATOR_DATA);
   SetIndexBuffer(2, ExtHighesBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(3, ExtLowesBuffer, INDICATOR_CALCULATIONS);
   
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   
   //--- Set accuracy
   IndicatorSetInteger(INDICATOR_DIGITS, 2);
   
   //--- Custom levels for OB/OS
   IndicatorSetInteger(INDICATOR_LEVELS, 3);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 0, 80);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 1, 50);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 2, 20);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 0, clrRed);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 1, clrGray);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 2, clrLime);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 0, STYLE_DASH);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 1, STYLE_DOT);
   IndicatorSetInteger(INDICATOR_LEVELSTYLE, 2, STYLE_DASH);
   
   //--- Init pivot data
   g_phPrice.Init();
   g_phStoch.Init();
   g_plPrice.Init();
   g_plStoch.Init();
   
   //--- Init Stochastic history
   g_stochHistMaxSize = InpMaxLookback + 50;
   ArrayResize(g_stochHist, g_stochHistMaxSize);
   ArrayResize(g_stochHistBar, g_stochHistMaxSize);
   g_stochHistCount = 0;
   
   //--- Init line tracking
   g_linesBear.Init();  g_linesBull.Init();
   g_linesHBear.Init(); g_linesHBull.Init();
   g_lblsBear.Init();   g_lblsBull.Init();
   g_lblsHBear.Init();  g_lblsHBull.Init();
   
   g_objCounter = 0;
   g_lastProcessedBar = -1;
   ArrayInitialize(g_lastDivergencePivotTime, 0);
   g_pushWarningLogged = false;
   
   //--- Set indicator name
   IndicatorSetString(INDICATOR_SHORTNAME, "Stoch Div v3");
   PlotIndexSetString(0, PLOT_LABEL, "Main");
   PlotIndexSetString(1, PLOT_LABEL, "Signal");
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpKPeriod + InpSlowing - 2);
   PlotIndexSetInteger(1, PLOT_DRAW_BEGIN, InpKPeriod + InpDPeriod);
   
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Custom indicator deinitialization                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   //--- Hapus semua objek milik indikator
   ObjectsDeleteAll(0, "StochDiv_");
}

//+------------------------------------------------------------------+
//| Detect pivot high in array data                                   |
//+------------------------------------------------------------------+
double PivotHigh(const double &data[], int index, int leftBars, int rightBars, int totalBars)
{
   int pivotIdx = index - rightBars;
   if(pivotIdx < leftBars || pivotIdx >= totalBars - rightBars)
      return EMPTY_VALUE;
   
   double pivotVal = data[pivotIdx];
   
   for(int i = 1; i <= leftBars; i++)
   {
      int checkIdx = pivotIdx - i;
      if(checkIdx < 0) return EMPTY_VALUE;
      if(data[checkIdx] >= pivotVal) return EMPTY_VALUE;
   }
   
   for(int i = 1; i <= rightBars; i++)
   {
      int checkIdx = pivotIdx + i;
      if(checkIdx >= totalBars) return EMPTY_VALUE;
      if(data[checkIdx] >= pivotVal) return EMPTY_VALUE;
   }
   
   return pivotVal;
}

//+------------------------------------------------------------------+
//| Detect pivot low in array data                                    |
//+------------------------------------------------------------------+
double PivotLow(const double &data[], int index, int leftBars, int rightBars, int totalBars)
{
   int pivotIdx = index - rightBars;
   if(pivotIdx < leftBars || pivotIdx >= totalBars - rightBars)
      return EMPTY_VALUE;
   
   double pivotVal = data[pivotIdx];
   
   for(int i = 1; i <= leftBars; i++)
   {
      int checkIdx = pivotIdx - i;
      if(checkIdx < 0) return EMPTY_VALUE;
      if(data[checkIdx] <= pivotVal) return EMPTY_VALUE;
   }
   
   for(int i = 1; i <= rightBars; i++)
   {
      int checkIdx = pivotIdx + i;
      if(checkIdx >= totalBars) return EMPTY_VALUE;
      if(data[checkIdx] <= pivotVal) return EMPTY_VALUE;
   }
   
   return pivotVal;
}

//+------------------------------------------------------------------+
//| Push Stochastic history value                                    |
//+------------------------------------------------------------------+
void PushStochHistory(double stochVal, int barIdx)
{
   if(g_stochHistCount >= g_stochHistMaxSize)
   {
      for(int i = 0; i < g_stochHistMaxSize - 1; i++)
      {
         g_stochHist[i] = g_stochHist[i + 1];
         g_stochHistBar[i] = g_stochHistBar[i + 1];
      }
      g_stochHistCount = g_stochHistMaxSize - 1;
   }
   g_stochHist[g_stochHistCount] = stochVal;
   g_stochHistBar[g_stochHistCount] = barIdx;
   g_stochHistCount++;
}

//+------------------------------------------------------------------+
//| Validate divergence line - check if line crosses Stochastic curve |
//| divType: DIV_BEAR/DIV_HBEAR → line must be >= Stoch (above)      |
//|          DIV_BULL/DIV_HBULL → line must be <= Stoch (below)      |
//| Returns true if line is CLEAR (does not cross)                    |
//+------------------------------------------------------------------+
bool IsLineClear(int x1, double y1, int x2, double y2, ENUM_DIV_TYPE divType)
{
   int span = x2 - x1;
   if(span <= 1) return true;
   
   for(int j = 0; j < g_stochHistCount; j++)
   {
      int b = g_stochHistBar[j];
      
      if(b > x1 && b < x2)
      {
         double stochAtBar = g_stochHist[j];
         double t = (double)(b - x1) / (double)span;
         double lineVal = y1 + t * (y2 - y1);
         
         if((divType == DIV_BEAR || divType == DIV_HBEAR) && stochAtBar > lineVal)
            return false;
         
         if((divType == DIV_BULL || divType == DIV_HBULL) && stochAtBar < lineVal)
            return false;
      }
   }
   
   return true;
}

//+------------------------------------------------------------------+
//| Find matching Stochastic pivot closest to a price pivot bar       |
//+------------------------------------------------------------------+
bool FindMatchingStoch(const SPivotData &stochData, int targetBar,
                       int &matchBar, double &matchVal)
{
   matchBar = -1;
   matchVal = EMPTY_VALUE;
   int minDist = 999;
   
   if(stochData.count < 2) return false;
   
   for(int i = stochData.count - 1; i >= 0; i--)
   {
      int b = stochData.bar[i];
      double v = stochData.val[i];
      int d = MathAbs(b - targetBar);
      
      if(d <= InpPivotRight * 2 && d < minDist)
      {
         minDist = d;
         matchVal = v;
         matchBar = b;
      }
   }
   
   return (matchBar >= 0 && matchVal != EMPTY_VALUE);
}

//+------------------------------------------------------------------+
//| Get sub-window index (lazy init)                                  |
//+------------------------------------------------------------------+
int GetSubWindow()
{
   if(subWindowIndex < 0)
   {
      subWindowIndex = ChartWindowFind(0, "Stoch Div v3");
      if(subWindowIndex < 0) subWindowIndex = 0;
   }
   return subWindowIndex;
}

//+------------------------------------------------------------------+
//| Helper: Trim lines by divergence type                             |
//+------------------------------------------------------------------+
void TrimLinesByType(ENUM_DIV_TYPE divType, int maxCount)
{
   switch(divType)
   {
      case DIV_BEAR:  g_linesBear.TrimToMax(maxCount); g_lblsBear.TrimToMax(maxCount); break;
      case DIV_BULL:  g_linesBull.TrimToMax(maxCount); g_lblsBull.TrimToMax(maxCount); break;
      case DIV_HBEAR: g_linesHBear.TrimToMax(maxCount); g_lblsHBear.TrimToMax(maxCount); break;
      case DIV_HBULL: g_linesHBull.TrimToMax(maxCount); g_lblsHBull.TrimToMax(maxCount); break;
   }
}

//+------------------------------------------------------------------+
//| Helper: Add line object name to tracking                          |
//+------------------------------------------------------------------+
void AddLineName(ENUM_DIV_TYPE divType, string name)
{
   switch(divType)
   {
      case DIV_BEAR:  g_linesBear.AddName(name); break;
      case DIV_BULL:  g_linesBull.AddName(name); break;
      case DIV_HBEAR: g_linesHBear.AddName(name); break;
      case DIV_HBULL: g_linesHBull.AddName(name); break;
   }
}

//+------------------------------------------------------------------+
//| Helper: Add label object name to tracking                         |
//+------------------------------------------------------------------+
void AddLblName(ENUM_DIV_TYPE divType, string name)
{
   switch(divType)
   {
      case DIV_BEAR:  g_lblsBear.AddName(name); break;
      case DIV_BULL:  g_lblsBull.AddName(name); break;
      case DIV_HBEAR: g_lblsHBear.AddName(name); break;
      case DIV_HBULL: g_lblsHBull.AddName(name); break;
   }
}

//+------------------------------------------------------------------+
//| Send push notification if MT5 terminal is configured              |
//+------------------------------------------------------------------+
bool SendPushMessage(const string message)
{
   if(!InpEnablePush)
      return false;

   if(MQLInfoInteger(MQL_TESTER))
      return false;

   if(!TerminalInfoInteger(TERMINAL_NOTIFICATIONS_ENABLED))
   {
      if(!g_pushWarningLogged)
      {
         Print("Push notifications disabled. Enable them in Tools > Options > Notifications.");
         g_pushWarningLogged = true;
      }
      return false;
   }

   ResetLastError();
   if(!SendNotification(message))
   {
      PrintFormat("SendNotification failed (%d): %s", GetLastError(), message);
      return false;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Collect new divergences; remember historical pivots without push  |
//+------------------------------------------------------------------+
void CollectDivergenceNotification(ENUM_DIV_TYPE divType,
                                  const datetime pivotTime,
                                  const bool allowNotifications,
                                  string &signals)
{
   if(pivotTime <= g_lastDivergencePivotTime[divType])
      return;

   g_lastDivergencePivotTime[divType] = pivotTime;
   if(!allowNotifications)
      return;

   string signal = "";
   switch(divType)
   {
      case DIV_BEAR:  signal = "Bearish Divergence"; break;
      case DIV_BULL:  signal = "Bullish Divergence"; break;
      case DIV_HBEAR: signal = "Hidden Bearish Divergence"; break;
      case DIV_HBULL: signal = "Hidden Bullish Divergence"; break;
   }

   if(signals != "")
      signals += ", ";
   signals += signal;
}

//+------------------------------------------------------------------+
//| Draw divergence line and label                                    |
//+------------------------------------------------------------------+
void DrawDivergence(ENUM_DIV_TYPE divType,
                    int x1, double y1, int x2, double y2,
                    color clr, string labelText)
{
   int win = GetSubWindow();
   
   int totalBars = Bars(_Symbol, PERIOD_CURRENT);
   int shift1 = totalBars - 1 - x1;
   int shift2 = totalBars - 1 - x2;
   
   if(shift1 < 0) shift1 = 0;
   if(shift2 < 0) shift2 = 0;
   
   datetime time1 = iTime(_Symbol, PERIOD_CURRENT, shift1);
   datetime time2 = iTime(_Symbol, PERIOD_CURRENT, shift2);
   
   if(time1 == 0 || time2 == 0) return;
   
   ENUM_LINE_STYLE lineStyle = STYLE_SOLID;
   string prefix = "";
   
   switch(divType)
   {
      case DIV_BEAR:  lineStyle = STYLE_SOLID; prefix = "Bear";  break;
      case DIV_BULL:  lineStyle = STYLE_SOLID; prefix = "Bull";  break;
      case DIV_HBEAR: lineStyle = STYLE_DASH;  prefix = "HBear"; break;
      case DIV_HBULL: lineStyle = STYLE_DASH;  prefix = "HBull"; break;
   }
   
   TrimLinesByType(divType, InpMaxLines);
   
   g_objCounter++;
   string lineName = "StochDiv_L_" + prefix + "_" + IntegerToString(g_objCounter);
   string lblName  = "StochDiv_T_" + prefix + "_" + IntegerToString(g_objCounter);
   
   if(ObjectCreate(0, lineName, OBJ_TREND, win, time1, y1, time2, y2))
   {
      ObjectSetInteger(0, lineName, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, lineName, OBJPROP_WIDTH, InpLineWidth);
      ObjectSetInteger(0, lineName, OBJPROP_STYLE, lineStyle);
      ObjectSetInteger(0, lineName, OBJPROP_RAY_RIGHT, false);
      ObjectSetInteger(0, lineName, OBJPROP_RAY_LEFT, false);
      ObjectSetInteger(0, lineName, OBJPROP_BACK, false);
      ObjectSetInteger(0, lineName, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, lineName, OBJPROP_HIDDEN, true);
      AddLineName(divType, lineName);
   }
   
   if(InpShowLabel)
   {
      double yOff;
      ENUM_ANCHOR_POINT anchor;
      
      if(divType == DIV_BEAR || divType == DIV_HBEAR)
      {
         yOff = y2 + 2.0;
         anchor = ANCHOR_LOWER;
      }
      else
      {
         yOff = y2 - 2.0;
         anchor = ANCHOR_UPPER;
      }
      
      if(ObjectCreate(0, lblName, OBJ_TEXT, win, time2, yOff))
      {
         ObjectSetString(0, lblName, OBJPROP_TEXT, labelText);
         ObjectSetInteger(0, lblName, OBJPROP_COLOR, clr);
         ObjectSetInteger(0, lblName, OBJPROP_FONTSIZE, 8);
         ObjectSetString(0, lblName, OBJPROP_FONT, "Arial Bold");
         ObjectSetInteger(0, lblName, OBJPROP_ANCHOR, anchor);
         ObjectSetInteger(0, lblName, OBJPROP_SELECTABLE, false);
         ObjectSetInteger(0, lblName, OBJPROP_HIDDEN, true);
         AddLblName(divType, lblName);
      }
   }
}

//+------------------------------------------------------------------+
//| Process divergences at current bar                                |
//+------------------------------------------------------------------+
void ProcessDivergences(int barIndex, 
                        const datetime &time[],
                        const bool allowNotifications)
{
   string signals = "";

   //--- BEARISH: Price Higher High, Stochastic Lower High
   if(InpShowBearish && g_phPrice.count >= 2)
   {
      int   curPBar = g_phPrice.bar[g_phPrice.count - 1];
      double curPVal = g_phPrice.val[g_phPrice.count - 1];
      
      for(int i = g_phPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_phPrice.bar[i];
         double prevPVal = g_phPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal > prevPVal)
         {
            int curRsiBar, prevRsiBar;
            double curRsiVal, prevRsiVal;
            
            if(FindMatchingStoch(g_phStoch, curPBar, curRsiBar, curRsiVal) &&
               FindMatchingStoch(g_phStoch, prevPBar, prevRsiBar, prevRsiVal) &&
               curRsiVal < prevRsiVal &&
               IsLineClear(prevRsiBar, prevRsiVal, curRsiBar, curRsiVal, DIV_BEAR))
            {
               DrawDivergence(DIV_BEAR, prevRsiBar, prevRsiVal, curRsiBar, curRsiVal,
                             InpColorBear, "DIV");
               CollectDivergenceNotification(DIV_BEAR, time[curPBar], allowNotifications, signals);
               break;
            }
         }
      }
   }
   
   //--- BULLISH: Price Lower Low, Stochastic Higher Low
   if(InpShowBullish && g_plPrice.count >= 2)
   {
      int   curPBar = g_plPrice.bar[g_plPrice.count - 1];
      double curPVal = g_plPrice.val[g_plPrice.count - 1];
      
      for(int i = g_plPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_plPrice.bar[i];
         double prevPVal = g_plPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal < prevPVal)
         {
            int curRsiBar, prevRsiBar;
            double curRsiVal, prevRsiVal;
            
            if(FindMatchingStoch(g_plStoch, curPBar, curRsiBar, curRsiVal) &&
               FindMatchingStoch(g_plStoch, prevPBar, prevRsiBar, prevRsiVal) &&
               curRsiVal > prevRsiVal &&
               IsLineClear(prevRsiBar, prevRsiVal, curRsiBar, curRsiVal, DIV_BULL))
            {
               DrawDivergence(DIV_BULL, prevRsiBar, prevRsiVal, curRsiBar, curRsiVal,
                             InpColorBull, "DIV");
               CollectDivergenceNotification(DIV_BULL, time[curPBar], allowNotifications, signals);
               break;
            }
         }
      }
   }
   
   //--- HIDDEN BEARISH: Price Lower High, Stochastic Higher High
   if(InpShowHidden && g_phPrice.count >= 2)
   {
      int   curPBar = g_phPrice.bar[g_phPrice.count - 1];
      double curPVal = g_phPrice.val[g_phPrice.count - 1];
      
      for(int i = g_phPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_phPrice.bar[i];
         double prevPVal = g_phPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal < prevPVal)
         {
            int curRsiBar, prevRsiBar;
            double curRsiVal, prevRsiVal;
            
            if(FindMatchingStoch(g_phStoch, curPBar, curRsiBar, curRsiVal) &&
               FindMatchingStoch(g_phStoch, prevPBar, prevRsiBar, prevRsiVal) &&
               curRsiVal > prevRsiVal &&
               IsLineClear(prevRsiBar, prevRsiVal, curRsiBar, curRsiVal, DIV_HBEAR))
            {
               DrawDivergence(DIV_HBEAR, prevRsiBar, prevRsiVal, curRsiBar, curRsiVal,
                             InpColorHBear, "HDIV");
               CollectDivergenceNotification(DIV_HBEAR, time[curPBar], allowNotifications, signals);
               break;
            }
         }
      }
   }
   
   //--- HIDDEN BULLISH: Price Higher Low, Stochastic Lower Low
   if(InpShowHidden && g_plPrice.count >= 2)
   {
      int   curPBar = g_plPrice.bar[g_plPrice.count - 1];
      double curPVal = g_plPrice.val[g_plPrice.count - 1];
      
      for(int i = g_plPrice.count - 2; i >= 0; i--)
      {
         int   prevPBar = g_plPrice.bar[i];
         double prevPVal = g_plPrice.val[i];
         int   dist = curPBar - prevPBar;
         
         if(dist > 0 && dist <= InpMaxLookback && curPVal > prevPVal)
         {
            int curRsiBar, prevRsiBar;
            double curRsiVal, prevRsiVal;
            
            if(FindMatchingStoch(g_plStoch, curPBar, curRsiBar, curRsiVal) &&
               FindMatchingStoch(g_plStoch, prevPBar, prevRsiBar, prevRsiVal) &&
               curRsiVal < prevRsiVal &&
               IsLineClear(prevRsiBar, prevRsiVal, curRsiBar, curRsiVal, DIV_HBULL))
            {
               DrawDivergence(DIV_HBULL, prevRsiBar, prevRsiVal, curRsiBar, curRsiVal,
                             InpColorHBull, "HDIV");
               CollectDivergenceNotification(DIV_HBULL, time[curPBar], allowNotifications, signals);
               break;
            }
         }
      }
   }

   //--- Combine signals confirmed on the same candle into one push.
   if(signals != "")
   {
      string message = StringFormat("[Stoch Div] %s %s: %s confirmed at %s",
                                    _Symbol, EnumToString(_Period), signals,
                                    TimeToString(time[barIndex], TIME_DATE | TIME_MINUTES));
      SendPushMessage(message);
   }
}

//+------------------------------------------------------------------+
//| Custom indicator iteration function                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < InpKPeriod + InpDPeriod + InpSlowing + InpPivotLeft + InpPivotRight + 1)
      return 0;

   bool allowDivergenceNotifications = (prev_calculated > 0);
   
   //--- Determine start bar
   int startBar;
   if(prev_calculated == 0)
   {
      startBar = InpKPeriod + InpSlowing - 2;
      
      //--- Reset all data on full recalculation
      g_phPrice.Init();
      g_phStoch.Init();
      g_plPrice.Init();
      g_plStoch.Init();
      g_stochHistCount = 0;
      g_lastProcessedBar = -1;
      ArrayInitialize(g_lastDivergencePivotTime, 0);
      g_pushWarningLogged = false;
      
      //--- Clean old objects
      ObjectsDeleteAll(0, "StochDiv_");
      g_linesBear.Init();  g_linesBull.Init();
      g_linesHBear.Init(); g_linesHBull.Init();
      g_lblsBear.Init();   g_lblsBull.Init();
      g_lblsHBear.Init();  g_lblsHBull.Init();
      g_objCounter = 0;
      
      //--- Reset sub-window index
      subWindowIndex = -1;
   }
   else
   {
      startBar = prev_calculated - 1;
   }

   //--- Calculate HighesBuffer[] and LowesBuffer[]
   int start;
   if(startBar < InpKPeriod - 1)
      start = InpKPeriod - 1;
   else
      start = startBar;

   for(int i = start; i < rates_total && !IsStopped(); i++)
   {
      double dmin = 1000000.0;
      double dmax = -1000000.0;
      for(int k = i - InpKPeriod + 1; k <= i; k++)
      {
         if(dmin > low[k])
            dmin = low[k];
         if(dmax < high[k])
            dmax = high[k];
      }
      ExtLowesBuffer[i] = dmin;
      ExtHighesBuffer[i] = dmax;
   }

   //--- Calculate Main (%K)
   start = InpKPeriod - 1 + InpSlowing - 1;
   if(start > startBar) startBar = start;
   
   if(prev_calculated == 0)
   {
      for(int i = 0; i < start; i++)
         ExtMainBuffer[i] = 0.0;
   }

   for(int i = start; i < rates_total && !IsStopped(); i++)
   {
      double sum_low = 0.0;
      double sum_high = 0.0;
      for(int k = (i - InpSlowing + 1); k <= i; k++)
      {
         sum_low += (close[k] - ExtLowesBuffer[k]);
         sum_high += (ExtHighesBuffer[k] - ExtLowesBuffer[k]);
      }
      if(sum_high == 0.0)
         ExtMainBuffer[i] = 100.0;
      else
         ExtMainBuffer[i] = sum_low / sum_high * 100;
   }

   //--- Calculate Signal (%D)
   start = InpDPeriod - 1;
   if(start > startBar) startBar = start;
   
   if(prev_calculated == 0)
   {
      for(int i = 0; i < start; i++)
         ExtSignalBuffer[i] = 0.0;
   }

   for(int i = start; i < rates_total && !IsStopped(); i++)
   {
      double sum = 0.0;
      for(int k = 0; k < InpDPeriod; k++)
         sum += ExtMainBuffer[i - k];
      ExtSignalBuffer[i] = sum / InpDPeriod;
   }
   
   //--- Process divergences on CLOSED bars
   int limit = rates_total - 1;
   for(int i = startBar; i < limit; i++)
   {
      double stochVal = ExtMainBuffer[i];
      if(stochVal == EMPTY_VALUE) continue;
      
      //--- Push Stochastic history
      PushStochHistory(stochVal, i);

      //--- Detect pivots on High
      double phPrice = PivotHigh(high, i, InpPivotLeft, InpPivotRight, rates_total);
      if(phPrice != EMPTY_VALUE)
      {
         int pivotIdx = i - InpPivotRight;
         g_phPrice.Push(phPrice, pivotIdx);
      }
      
      double phStoch = PivotHigh(ExtMainBuffer, i, InpPivotLeft, InpPivotRight, rates_total);
      if(phStoch != EMPTY_VALUE)
      {
         int pivotIdx = i - InpPivotRight;
         g_phStoch.Push(phStoch, pivotIdx);
      }
      
      //--- Detect pivots on Low
      double plPrice = PivotLow(low, i, InpPivotLeft, InpPivotRight, rates_total);
      if(plPrice != EMPTY_VALUE)
      {
         int pivotIdx = i - InpPivotRight;
         g_plPrice.Push(plPrice, pivotIdx);
      }
      
      double plStoch = PivotLow(ExtMainBuffer, i, InpPivotLeft, InpPivotRight, rates_total);
      if(plStoch != EMPTY_VALUE)
      {
         int pivotIdx = i - InpPivotRight;
         g_plStoch.Push(plStoch, pivotIdx);
      }
      
      //--- Process divergences when new pivot detected
      bool newPivot = (phPrice != EMPTY_VALUE || phStoch != EMPTY_VALUE ||
                       plPrice != EMPTY_VALUE || plStoch != EMPTY_VALUE);
      
      if(newPivot && i > g_lastProcessedBar)
      {
         ProcessDivergences(i, time, allowDivergenceNotifications && i == limit - 1);
         g_lastProcessedBar = i;
      }
   }
   
   return rates_total;
}
//+------------------------------------------------------------------+
