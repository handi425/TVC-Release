/* RSI / Stochastic divergence presentation for the user's MT5 indicator ports.
 * Original indicator headers: Converted from TradingView Pine Script.
 * Regular lines are solid; hidden lines are dashed, on the oscillator scale.
 */
(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.HPXOscillatorDivergence=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const TYPES={regular_bearish:{label:'Bear Div',short:'Bear',hidden:false,bear:true},regular_bullish:{label:'Bull Div',short:'Bull',hidden:false,bear:false},hidden_bearish:{label:'H.Bear',short:'H.Bear',hidden:true,bear:true},hidden_bullish:{label:'H.Bull',short:'H.Bull',hidden:true,bear:false}};
  const COMMON={enabled:true,pivot_left:5,pivot_right:1,max_lookback:60,show_bearish:true,show_bullish:true,show_labels:true,color_bear:'#FF0000',color_bull:'#00FF00',color_hidden_bear:'#FFA500',color_hidden_bull:'#00FFFF'};
  const DEFAULTS={rsi:{...COMMON,max_lines:3,line_width:2,show_hidden:false},stochastic:{...COMMON,max_lines:5,line_width:1,show_hidden:true}};
  const PRICES=[['close','Close'],['open','Open'],['high','High'],['low','Low'],['median','Median (H+L)/2'],['typical','Typical (H+L+C)/3'],['weighted','Weighted (H+L+2C)/4']];
  const finite=value=>value!==null&&value!==undefined&&typeof value!=='boolean'&&Number.isFinite(Number(value));
  const clamp=(value,lo,hi)=>Math.min(hi,Math.max(lo,value));
  const number=value=>Math.round(Number(value)*1000)/1000;
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const color=(value,fallback='#A7BAD2')=>typeof value==='string'&&/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(value)?value:fallback;
  function mergeConfig(kind,previous){return {...DEFAULTS[kind==='stochastic'?'stochastic':'rsi'],...(previous&&typeof previous==='object'?previous:{})};}
  function settingsHTML(kind,config={}){
    const cfg=mergeConfig(kind,config.divergence),id='osc-div-'+kind;
    const toggle=(key,label,note='')=>`<label class="toggle-setting"><div><b>${escape(label)}</b>${note?`<small>${escape(note)}</small>`:''}</div><input type="checkbox" data-osc-div-setting="${key}"${cfg[key]?' checked':''}><span class="switch"></span></label>`;
    const numeric=(key,label,min,max)=>`<label>${escape(label)}<input type="number" data-osc-div-setting="${key}" min="${min}" max="${max}" step="1" value="${escape(cfg[key])}" required></label>`;
    const colors=[['color_bear','Bearish'],['color_bull','Bullish'],['color_hidden_bear','Hidden bearish'],['color_hidden_bull','Hidden bullish']];
    return (kind==='rsi'?`<label>Sumber harga RSI<select data-osc-price="applied_price" aria-label="Sumber harga RSI">${PRICES.map(([value,label])=>`<option value="${value}"${(config.applied_price||'close')===value?' selected':''}>${escape(label)}</option>`).join('')}</select></label>`:'')+
      `<details class="oscillator-div-settings" id="${id}"><summary>Divergence &amp; hidden divergence</summary><div class="oscillator-div-fields">`+
      toggle('enabled','Garis divergence','Garis berada pada panel indikator; memakai pivot candle selesai.')+
      toggle('show_bearish','Regular bearish','Harga higher high, indikator lower high.')+
      toggle('show_bullish','Regular bullish','Harga lower low, indikator higher low.')+
      toggle('show_hidden','Hidden divergence','Hidden bearish dan bullish memakai garis putus-putus.')+
      `<div class="settings-grid">${numeric('pivot_left','Pivot kiri',1,200)}${numeric('pivot_right','Pivot kanan',1,200)}${numeric('max_lookback','Jarak candle maksimal',1,5000)}${numeric('max_lines','Garis per jenis',1,100)}${numeric('line_width','Ketebalan garis',1,5)}</div>`+
      toggle('show_labels','Label divergence','DIV / HDIV pada Stochastic, label arah pada RSI.')+
      `<details class="oscillator-div-colors"><summary>Warna garis</summary><div class="settings-grid">${colors.map(([key,label])=>`<label>${label}<input type="color" data-osc-div-setting="${key}" value="${color(cfg[key])}" aria-label="${escape(label+' '+kind)}"></label>`).join('')}</div></details>`+
      `<p class="field-note">Pivot baru muncul setelah candle konfirmasi selesai. Garis yang menembus kurva indikator di antara kedua pivot ditolak. Harga dibandingkan pada pivot harga yang dipasangkan; garis digambar pada pivot indikator.</p></div></details>`;
  }
  function readSettings(kind,host,previous={}){
    const result={...previous,divergence:mergeConfig(kind,previous.divergence)};
    for(const input of host.querySelectorAll('[data-osc-div-setting]')){
      const key=input.dataset.oscDivSetting;
      if(!(key in DEFAULTS[kind]))continue;
      result.divergence[key]=input.type==='checkbox'?!!input.checked:input.type==='number'?Number(input.value):input.value;
    }
    const price=host.querySelector('[data-osc-price]');
    if(price&&kind==='rsi')result.applied_price=price.value;
    return result;
  }
  function buildOverlay(data,{kind='rsi',config={},width,height,plotRight=width-74,plotBottom=height,x,y}={}){
    const cfg=mergeConfig(kind,config);
    if(!data||data.enabled===false||!cfg.enabled||!finite(width)||!finite(height)||width<=0||height<=0||typeof x!=='function'||typeof y!=='function')return '';
    const right=clamp(Number(plotRight),0,Number(width)),bottom=clamp(Number(plotBottom),0,Number(height));
    const parts=[],lastClosed=data.meta?.last_closed_index;
    let drawn=0;
    for(const item of (Array.isArray(data.lines)?data.lines:[]).slice(0,400)){
      const type=TYPES[item.type];if(!type)continue;
      if(type.hidden&&!cfg.show_hidden||!type.hidden&&(type.bear?!cfg.show_bearish:!cfg.show_bullish))continue;
      if(finite(lastClosed)&&finite(item.known_index)&&Number(item.known_index)>Number(lastClosed))continue;
      const start=item.start,end=item.end;
      if(!start||!end||![start.index,start.value,end.index,end.value].every(finite)||Number(end.index)<=Number(start.index))continue;
      const ax=x(Number(start.index)),ay=y(Number(start.value)),bx=x(Number(end.index)),by=y(Number(end.value));
      if(![ax,ay,bx,by].every(finite)||Math.max(ax,bx)<0||Math.min(ax,bx)>right||Math.max(ay,by)<0||Math.min(ay,by)>bottom)continue;
      const fallback=cfg[type.hidden?(type.bear?'color_hidden_bear':'color_hidden_bull'):(type.bear?'color_bear':'color_bull')],ink=color(item.color,color(fallback));
      const widthPx=clamp(finite(item.width)?Number(item.width):finite(cfg.line_width)?Number(cfg.line_width):1,1,5),knownDate=finite(item.known_at)?new Date(Number(item.known_at)*1000):null,
        known=knownDate&&Number.isFinite(knownDate.getTime())?' · konfirmasi '+knownDate.toISOString().replace('T',' ').slice(0,16)+' UTC':'';
      const label=String(item.label|| (kind==='stochastic'?(type.hidden?'HDIV':'DIV'):type.label)).slice(0,80);
      const tooltip=`${type.hidden?'Hidden':'Regular'} ${type.bear?'bearish':'bullish'} · ${kind==='rsi'?'RSI':'Stochastic'}${known}`;
      parts.push(`<line x1="${number(ax)}" y1="${number(ay)}" x2="${number(bx)}" y2="${number(by)}" stroke="${ink}" stroke-width="${widthPx}"${type.hidden?' stroke-dasharray="5 4"':''}><title>${escape(tooltip)}</title></line>`);
      if(cfg.show_labels&&item.show_label!==false){
        const labelValue=Number(end.value)+(type.bear?2:-2),labelY=y(labelValue);
        if(finite(labelY)&&bx>=-20&&bx<=right+20){
          const py=type.bear?Number(labelY)-3:Number(labelY)+11;
          parts.push(`<text x="${number(bx)}" y="${number(py)}" text-anchor="middle" fill="${ink}" font-family="Arial,Segoe UI,sans-serif" font-size="10" font-weight="700" paint-order="stroke" stroke="#0b141f" stroke-width="2" stroke-linejoin="round">${escape(label)}<title>${escape(tooltip)}</title></text>`);
        }
      }
      drawn++;
    }
    if(!drawn)return '';
    const clip='osc-div-'+(kind==='stochastic'?'stochastic':'rsi')+'-clip';
    return `<defs><clipPath id="${clip}"><rect width="${right}" height="${bottom}"/></clipPath></defs><g clip-path="url(#${clip})" data-divergence-lines="${drawn}">${parts.join('')}</g>`;
  }
  function status(data,{kind='rsi',config={},enabled=true,loading=false}={}){
    const cfg=mergeConfig(kind,config);
    if(!enabled||!cfg.enabled)return {headline:'Garis divergence nonaktif',detail:[]};
    if(loading)return {headline:'Memeriksa pivot candle selesai…',detail:[]};
    if(!data)return {headline:'Menunggu analisis divergence',detail:[]};
    const counts={regular:0,hidden:0};
    for(const line of Array.isArray(data.lines)?data.lines:[]){const type=TYPES[line.type];if(type)counts[type.hidden?'hidden':'regular']++;}
    return {headline:`${counts.regular} regular · ${cfg.show_hidden?counts.hidden+' hidden':'hidden nonaktif'}`,detail:['Regular: garis utuh · Hidden: putus-putus','Pivot memakai candle selesai; garis dapat berada di luar rentang chart yang terlihat.']};
  }
  return {TYPES,DEFAULTS,PRICES,mergeConfig,settingsHTML,readSettings,buildOverlay,status};
});
