"""Port of the user's RSIDiv.mq5 v3.00 and Stochastic_Div.mq5 v3.10.

Original source notice: "Converted from TradingView Pine Script".
Price and oscillator pivots remain separate and are matched only once known.
Drawings live in oscillator coordinates, not on the main price chart.
"""
from __future__ import annotations

from collections import deque
from copy import deepcopy
from hashlib import sha256
import json
from math import isfinite


SOURCE_HASHES = {
    'rsi': '997fb5c0c23a2849b7478092e8ce433efafe28c13d55887ebfe0185d00d5cfec',
    'stochastic': 'cbc2e34e373b8545a806ea2e251ffda66dc8da3d8791bc936ac9014327c1bcca',
}
TYPES = ('regular_bearish', 'regular_bullish', 'hidden_bearish', 'hidden_bullish')
DEFAULT_DIVERGENCE = {
    'enabled': True, 'pivot_left': 5, 'pivot_right': 1, 'max_lookback': 60,
    'max_lines': 3, 'show_bearish': True, 'show_bullish': True, 'show_hidden': False,
    'show_labels': True, 'line_width': 2, 'color_bear': '#FF0000', 'color_bull': '#00FF00',
    'color_hidden_bear': '#FFA500', 'color_hidden_bull': '#00FFFF',
}


def divergence_defaults(indicator: str) -> dict:
    config = deepcopy(DEFAULT_DIVERGENCE)
    if indicator == 'stochastic':
        config.update(max_lines=5, line_width=1, show_hidden=True)
    return config


def pivot_at(values: list[float | None], confirmation: int, left: int, right: int,
             high: bool) -> tuple[int, float] | None:
    """MQ5 strict extrema: ties on either side invalidate the candidate."""
    index = confirmation-right
    if index < left or confirmation >= len(values):
        return None
    center = values[index]
    window = values[index-left:confirmation+1]
    if center is None or any(value is None or not isfinite(value) for value in window):
        return None
    neighbors = window[:left]+window[left+1:]
    if any(value >= center if high else value <= center for value in neighbors):
        return None
    return index, center


def matching_pivot(pivots: list | deque, target: int, right: int) -> tuple[int, float] | None:
    """Newest wins equal distances, matching the reverse MQ5 scan."""
    if len(pivots) < 2:
        return None
    nearest = None
    distance = 999
    for index, value in reversed(pivots):
        d = abs(index-target)
        if d <= right*2 and d < distance:
            nearest, distance = (index, value), d
    return nearest


def line_clear(values: list[float | None], start: tuple[int, float], end: tuple[int, float],
               bearish: bool) -> bool:
    """Equality may touch the line; strict penetration invalidates it."""
    x1, y1 = start
    x2, y2 = end
    if x2 <= x1:
        return False
    for index in range(x1+1, x2):
        value = values[index]
        if value is None:
            return False
        level = y1+(index-x1)/(x2-x1)*(y2-y1)
        if (value > level) if bearish else (value < level):
            return False
    return True


def divergence_analysis(rows: list[dict], oscillator: list[float | None], indicator: str,
                        config: dict, *, start_index: int, include_lines: bool = True,
                        minimum_closed_bars: int = 0) -> dict:
    """Replay the source's chronological closed-bar pivot/matching decisions.

    Stable endpoint IDs suppress repeated identical objects. Unlike the source
    TrimToMax-before-add off-by-one, the configured per-type cap is exact.
    """
    cfg = config
    output = {'enabled': bool(cfg['enabled']), 'lines': [], 'latest': None,
              'counts': {kind: 0 for kind in TYPES},
              'meta': {'source_file': 'RSIDiv.mq5' if indicator == 'rsi' else 'Stochastic_Div.mq5',
                       'source_sha256': SOURCE_HASHES[indicator], 'closed_only': True,
                       'known_at_basis': 'confirmation candle opening time; available after that candle closes',
                       'matching': 'nearest confirmed oscillator pivot within 2 * pivot_right; newer wins distance ties',
                       'max_pivots_per_side': 50, 'line_validation': 'all oscillator bars strictly between endpoints; touching allowed',
                       'lines_omitted': not include_lines,
                       'implementation_notes': [
                           'Undefined initial Stochastic extrema and non-display warmup values are omitted.',
                           'Identical endpoint lines are deduplicated; per-type max_lines is an exact cap.',
                           'Line validation checks the complete interval, including when unusually large pivot_right exceeds the source history ring.',
                       ]}}
    if not cfg['enabled'] or not rows:
        return output
    closed_end = next((i for i in range(len(rows)-1, -1, -1) if rows[i]['closed']), -1)
    if closed_end < start_index or closed_end+1 < minimum_closed_bars:
        return output
    prices = {True: [row['high'] for row in rows], False: [row['low'] for row in rows]}
    price_pivots = {True: deque(maxlen=50), False: deque(maxlen=50)}
    osc_pivots = {True: deque(maxlen=50), False: deque(maxlen=50)}
    retained = {kind: deque(maxlen=cfg['max_lines']) for kind in TYPES}
    seen = set()
    left, right = cfg['pivot_left'], cfg['pivot_right']
    unique = 0
    rules = (
        ('regular_bearish', True, cfg['show_bearish'], 1, -1, 'color_bear'),
        ('regular_bullish', False, cfg['show_bullish'], -1, 1, 'color_bull'),
        ('hidden_bearish', True, cfg['show_hidden'], -1, 1, 'color_hidden_bear'),
        ('hidden_bullish', False, cfg['show_hidden'], 1, -1, 'color_hidden_bull'),
    )
    for confirmation in range(start_index, closed_end+1):
        if oscillator[confirmation] is None:
            continue
        changed = False
        for high in (True, False):
            p = pivot_at(prices[high], confirmation, left, right, high)
            q = pivot_at(oscillator, confirmation, left, right, high)
            if p is not None:
                price_pivots[high].append(p)
                changed = True
            if q is not None:
                osc_pivots[high].append(q)
                changed = True
        if not changed:
            continue
        for kind, high, enabled, price_sign, osc_sign, color_key in rules:
            pp = price_pivots[high]
            if not enabled or len(pp) < 2:
                continue
            current = pp[-1]
            for prior in reversed(list(pp)[:-1]):
                distance = current[0]-prior[0]
                if not (0 < distance <= cfg['max_lookback'] and price_sign*(current[1]-prior[1]) > 0):
                    continue
                current_osc = matching_pivot(osc_pivots[high], current[0], right)
                prior_osc = matching_pivot(osc_pivots[high], prior[0], right)
                if (current_osc is None or prior_osc is None
                        or osc_sign*(current_osc[1]-prior_osc[1]) <= 0
                        or not line_clear(oscillator, prior_osc, current_osc, high)):
                    continue
                def endpoint(osc, price):
                    return {'index': osc[0], 'time': rows[osc[0]]['time'], 'value': osc[1],
                            'price': price[1], 'price_index': price[0], 'price_time': rows[price[0]]['time']}
                start, end = endpoint(prior_osc, prior), endpoint(current_osc, current)
                key = json.dumps([indicator, kind,
                                  [start[field] for field in ('time', 'value', 'price_time', 'price')],
                                  [end[field] for field in ('time', 'value', 'price_time', 'price')]])
                if key not in seen:
                    seen.add(key)
                    unique += 1
                    hidden = kind.startswith('hidden')
                    caption = ('HDIV' if hidden else 'DIV') if indicator == 'stochastic' else (
                        'H.Bear' if kind == 'hidden_bearish' else 'H.Bull' if kind == 'hidden_bullish'
                        else 'Bear Div' if high else 'Bull Div')
                    available_at = max(confirmation, minimum_closed_bars-1)
                    retained[kind].append({
                        'id': sha256(key.encode()).hexdigest()[:20], 'type': kind,
                        'start': start, 'end': end, 'known_index': available_at,
                        'pivot_confirmation_index': confirmation,
                        'known_at': rows[available_at]['time'], 'age_bars': closed_end-available_at,
                        'color': cfg[color_key], 'width': cfg['line_width'],
                        'style': 'dashed' if hidden else 'solid',
                        'label': caption if cfg['show_labels'] else '',
                        'label_value': end['value']+(2 if high else -2),
                        'label_position': 'above' if high else 'below',
                    })
                # MQ5 stops after the first newest valid earlier price pivot,
                # even if its drawing was already emitted by another new pivot.
                break
    lines = sorted((line for group in retained.values() for line in group), key=lambda x: (x['known_index'], x['end']['index'], TYPES.index(x['type'])))
    output['counts'] = {kind: len(retained[kind]) for kind in TYPES}
    output['latest'] = deepcopy(lines[-1]) if lines else None
    output['lines'] = lines if include_lines else []
    output['meta'].update(detected_unique=unique, retained_lines=len(lines),
                          first_processing_index=start_index, last_closed_index=closed_end)
    return output
