"""One-time replacement of legacy HPX oscillators with the supplied MT5 model."""
from __future__ import annotations

from copy import deepcopy

TECHNICAL_MODEL = 'mt5-oscillator-divergence-v1'


def migrate_legacy_technicals(values: dict | None, model: str | None = None) -> dict | None:
    if values is None:
        return None
    result = deepcopy(values)
    if model == TECHNICAL_MODEL or not isinstance(result, dict):
        return result
    stochastic = result.get('stochastic')
    if isinstance(stochastic, dict) and 'divergence' not in stochastic:
        old_periods = tuple(stochastic.get(key) for key in ('k_period', 'k_smoothing', 'd_period'))
        if old_periods == (14, 3, 3):
            stochastic['k_period'] = 5
    return result
