"""Causal RSI, Stochastic and EMA calculations on supplied market candles.

The module has no network or storage side effects. Warmup values are omitted
from chart series, and screener snapshots always use the last closed candle.
"""
from __future__ import annotations

from copy import deepcopy
from math import isclose, isfinite
import re
from typing import Any

from .oscillator_divergence import divergence_analysis, divergence_defaults


DEFAULT_TECHNICALS = {
    "rsi": {"enabled": True, "period": 14, "applied_price": "close", "overbought": 70, "oversold": 30,
            "divergence": divergence_defaults('rsi')},
    "stochastic": {"enabled": True, "k_period": 5, "k_smoothing": 3, "d_period": 3,
                   "overbought": 80, "oversold": 20, "divergence": divergence_defaults('stochastic')},
    "ema": {"enabled": True, "periods": [21, 34, 90, 200]},
}


def _integer(value: Any, name: str, low: int, high: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} harus bilangan bulat {low}–{high}.")
    if not isfinite(value) or int(value) != value or not low <= value <= high:
        raise ValueError(f"{name} harus bilangan bulat {low}–{high}.")
    return int(value)


def _threshold(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} harus angka 0–100.")
    value = float(value)
    if not isfinite(value) or not 0 <= value <= 100:
        raise ValueError(f"{name} harus angka 0–100.")
    return value


def validate_technical_settings(config: dict | None = None) -> dict:
    """Return an independent normalized configuration or raise ValueError."""
    if config is None:
        return deepcopy(DEFAULT_TECHNICALS)
    if not isinstance(config, dict):
        raise ValueError("Pengaturan indikator harus objek JSON.")
    unknown = set(config) - set(DEFAULT_TECHNICALS)
    if unknown:
        raise ValueError("Indikator tidak dikenal: " + ", ".join(sorted(map(str, unknown))))
    result = deepcopy(DEFAULT_TECHNICALS)
    for name, values in config.items():
        if not isinstance(values, dict):
            raise ValueError(f"Pengaturan {name} harus objek JSON.")
        unknown_fields = set(values) - set(result[name])
        if unknown_fields:
            raise ValueError(f"Parameter {name} tidak dikenal: " + ", ".join(sorted(map(str, unknown_fields))))
        supplied = deepcopy(values)
        if 'divergence' in supplied:
            divergence = supplied.pop('divergence')
            if not isinstance(divergence, dict):
                raise ValueError(f'{name}.divergence harus objek JSON.')
            unknown_divergence = set(divergence)-set(result[name]['divergence'])
            if unknown_divergence:
                raise ValueError(f'Parameter divergence {name} tidak dikenal: '+', '.join(sorted(map(str, unknown_divergence))))
            result[name]['divergence'].update(divergence)
        result[name].update(supplied)
    for name, values in result.items():
        if not isinstance(values["enabled"], bool):
            raise ValueError(f"{name}.enabled harus boolean.")
    result["rsi"]["period"] = _integer(result["rsi"]["period"], "RSI period", 1, 500)
    if result['rsi']['applied_price'] not in ('close', 'open', 'high', 'low', 'median', 'typical', 'weighted'):
        raise ValueError('Sumber RSI harus close/open/high/low/median/typical/weighted.')
    stoch = result["stochastic"]
    stoch["k_period"] = _integer(stoch["k_period"], "Stochastic K period", 1, 500)
    stoch["k_smoothing"] = _integer(stoch["k_smoothing"], "Stochastic smoothing K", 1, 100)
    stoch["d_period"] = _integer(stoch["d_period"], "Stochastic D period", 1, 100)
    for name in ("rsi", "stochastic"):
        values = result[name]
        values["overbought"] = _threshold(values["overbought"], f"{name}.overbought")
        values["oversold"] = _threshold(values["oversold"], f"{name}.oversold")
        if values["oversold"] >= values["overbought"]:
            raise ValueError(f"{name}: oversold harus lebih kecil dari overbought.")
        div = values['divergence']
        for field in ('enabled', 'show_bearish', 'show_bullish', 'show_hidden', 'show_labels'):
            if not isinstance(div[field], bool):
                raise ValueError(f'{name}.divergence.{field} harus boolean.')
        for field, high in (('pivot_left', 200), ('pivot_right', 200), ('max_lookback', 5000), ('max_lines', 100), ('line_width', 5)):
            div[field] = _integer(div[field], name+'.divergence.'+field, 1, high)
        for field in ('color_bear', 'color_bull', 'color_hidden_bear', 'color_hidden_bull'):
            if not isinstance(div[field], str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', div[field]):
                raise ValueError(f'{name}.divergence.{field} harus warna #RRGGBB.')
            div[field] = div[field].upper()
    periods = result["ema"]["periods"]
    if not isinstance(periods, (list, tuple)) or not periods or len(periods) > 64:
        raise ValueError("EMA periods harus daftar berisi 1–8 periode unik.")
    periods = list(dict.fromkeys(_integer(x, "EMA period", 1, 1000) for x in periods))
    if len(periods) > 8:
        raise ValueError("Maksimal delapan periode EMA unik.")
    result["ema"]["periods"] = periods
    return result


def _bars(values: list[dict]) -> list[dict]:
    if not isinstance(values, (list, tuple)):
        raise ValueError("Candle indikator harus berupa daftar.")
    result = []
    last_time = None
    for index, raw in enumerate(values):
        if not isinstance(raw, dict):
            raise ValueError("Candle harus objek OHLC.")
        stamp = raw.get("time")
        if isinstance(stamp, bool) or not isinstance(stamp, (int, float)) or not isfinite(stamp) or int(stamp) != stamp or stamp < 0:
            raise ValueError("Timestamp candle harus detik Unix yang valid.")
        stamp = int(stamp)
        if last_time is not None and stamp <= last_time:
            raise ValueError("Candle harus berurutan dengan timestamp unik.")
        row = {"time": stamp}
        for key in ("high", "low", "close"):
            value = raw.get(key)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
                raise ValueError(f"Nilai candle {key} harus angka finite.")
            row[key] = float(value)
        opening = raw.get("open", row["close"])
        if isinstance(opening, bool) or not isinstance(opening, (int, float)) or not isfinite(opening):
            raise ValueError("Nilai candle open harus angka finite.")
        if row["high"] < max(opening, row["low"], row["close"]) or row["low"] > min(opening, row["high"], row["close"]):
            raise ValueError("Rentang high/low candle tidak valid.")
        row['open'] = float(opening)
        closed = raw.get("closed", True)
        if not isinstance(closed, bool):
            raise ValueError("Status closed candle harus boolean.")
        if not closed and index != len(values) - 1:
            raise ValueError("Hanya candle terakhir yang boleh masih berjalan.")
        row["closed"] = closed
        result.append(row)
        last_time = stamp
    return result


def _sma(values: list[float | None], period: int) -> list[float | None]:
    result: list[float | None] = [None] * len(values)
    total = 0.0
    count = 0
    for index, value in enumerate(values):
        if value is not None:
            total += value
            count += 1
        if index >= period:
            old = values[index - period]
            if old is not None:
                total -= old
                count -= 1
        if index >= period - 1 and count == period:
            result[index] = total / period
    return result


def _ema(closes: list[float], period: int) -> list[float | None]:
    result: list[float | None] = [None] * len(closes)
    if len(closes) < period:
        return result
    result[period - 1] = previous = sum(closes[:period]) / period
    alpha = 2.0 / (period + 1.0)
    for index in range(period, len(closes)):
        previous = closes[index] * alpha + previous * (1.0 - alpha)
        result[index] = previous
    return result


def _rsi(closes: list[float], period: int) -> list[float | None]:
    result: list[float | None] = [None] * len(closes)
    if len(closes) <= period:
        return result
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    if any(not isfinite(change) for change in changes):
        raise ValueError("Perubahan harga melampaui rentang angka indikator.")
    gain = sum(max(change, 0.0) for change in changes[:period]) / period
    loss = sum(max(-change, 0.0) for change in changes[:period]) / period

    def value(up: float, down: float) -> float:
        if down == 0.0:
            return 50.0 if up == 0.0 else 100.0
        if up == 0.0:
            return 0.0
        return 100.0 - 100.0 / (1.0 + up / down)

    result[period] = value(gain, loss)
    for index in range(period + 1, len(closes)):
        change = changes[index - 1]
        gain = (gain * (period - 1) + max(change, 0.0)) / period
        loss = (loss * (period - 1) + max(-change, 0.0)) / period
        result[index] = value(gain, loss)
    return result


def _stochastic(rows: list[dict], period: int, smooth: int, d_period: int) -> tuple[list, list]:
    # MQ5 slows Main by dividing the sum of distances from each rolling low by
    # the sum of each rolling range. This is not an SMA of raw percentages.
    lows: list[float | None] = [None] * len(rows)
    ranges: list[float | None] = [None] * len(rows)
    for index in range(period - 1, len(rows)):
        window = rows[index - period + 1:index + 1]
        highest = max(row["high"] for row in window)
        lowest = min(row["low"] for row in window)
        distance = highest - lowest
        if not isfinite(distance):
            raise ValueError("Rentang harga melampaui batas angka Stochastic.")
        lows[index] = rows[index]['close']-lowest
        ranges[index] = distance
    k: list[float | None] = [None] * len(rows)
    for index in range(period+smooth-2, len(rows)):
        numerator = denominator = 0.0
        for j in range(index-smooth+1, index+1):
            numerator += lows[j]
            denominator += ranges[j]
        if not isfinite(numerator) or not isfinite(denominator):
            raise ValueError('Perhitungan Stochastic melampaui batas angka finite.')
        k[index] = 100.0 if denominator == 0 else numerator/denominator*100.0
    return k, _sma(k, d_period)


def _applied_prices(rows: list[dict], mode: str) -> list[float]:
    if mode in ('close', 'open', 'high', 'low'):
        return [row[mode] for row in rows]
    if mode == 'median':
        return [(row['high']+row['low'])/2 for row in rows]
    if mode == 'typical':
        return [(row['high']+row['low']+row['close'])/3 for row in rows]
    return [(row['high']+row['low']+2*row['close'])/4 for row in rows]


def _state(value: float | None, cfg: dict) -> str | None:
    if value is None:
        return None
    return "overbought" if value >= cfg["overbought"] else "oversold" if value <= cfg["oversold"] else "neutral"


def technical_analysis(bars: list[dict], config: dict | None = None, *, include_divergence_lines: bool = True) -> dict:
    """Compute full chart series, closed-bar screener state and open preview."""
    cfg = validate_technical_settings(config)
    rows = _bars(bars)
    closes = [row["close"] for row in rows]
    blank: list[float | None] = [None] * len(rows)
    rsi = _rsi(_applied_prices(rows, cfg['rsi']['applied_price']), cfg["rsi"]["period"]) if cfg["rsi"]["enabled"] else blank
    if cfg["stochastic"]["enabled"]:
        k, d = _stochastic(rows, cfg["stochastic"]["k_period"], cfg["stochastic"]["k_smoothing"], cfg["stochastic"]["d_period"])
    else:
        k, d = blank, blank
    ema = {str(period): _ema(closes, period) if cfg["ema"]["enabled"] else blank for period in cfg["ema"]["periods"]}
    if any(value is not None and not isfinite(value) for values in (rsi, k, d, *ema.values()) for value in values):
        raise ValueError("Perhitungan indikator melampaui batas angka finite.")
    divergences = {}
    for name, values in (('rsi', rsi), ('stochastic', k)):
        parameters = cfg[name]
        div = parameters['divergence']
        if name == 'rsi':
            start = parameters['period']+div['pivot_left']+div['pivot_right']
            readiness = start+1
        else:
            start = max(parameters['k_period']+parameters['k_smoothing']-2, parameters['d_period']-1)
            readiness = parameters['k_period']+parameters['d_period']+parameters['k_smoothing']+div['pivot_left']+div['pivot_right']
        divergences[name] = divergence_analysis(rows, values, name, {**div, 'enabled': parameters['enabled'] and div['enabled']},
                                               start_index=start, include_lines=include_divergence_lines,
                                               minimum_closed_bars=readiness)

    def chart_series(values: list) -> list[dict]:
        return [{"time": row["time"], "value": value, "closed": row["closed"]}
                for row, value in zip(rows, values) if value is not None]

    def snapshot(index: int | None) -> dict:
        exists = index is not None
        values = {period: values[index] if exists else None for period, values in ema.items()}
        price = rows[index]["close"] if exists else None
        positions = {period: None if value is None or price is None else "equal" if isclose(price, value, rel_tol=1e-12, abs_tol=1e-12) else "above" if price > value else "below" for period, value in values.items()}
        ordered = [values[str(period)] for period in sorted(cfg["ema"]["periods"])]
        alignment = None
        if len(ordered) > 1 and all(value is not None for value in ordered):
            alignment = "bullish" if all(a > b for a, b in zip(ordered, ordered[1:])) else "bearish" if all(a < b for a, b in zip(ordered, ordered[1:])) else "mixed"
        rsi_value, k_value, d_value = (rsi[index], k[index], d[index]) if exists else (None, None, None)
        return {"time": rows[index]["time"] if exists else None, "closed": bool(exists and rows[index]["closed"]),
                "available": exists, "price": price, "rsi": rsi_value, "stochastic_k": k_value, "stochastic_d": d_value,
                "ema": values, "rsi_state": _state(rsi_value, cfg["rsi"]), "stochastic_state": _state(k_value, cfg["stochastic"]),
                "ema_position": positions, "ema_alignment": alignment,
                "rsi_divergence": divergences['rsi']['latest'],
                "stochastic_divergence": divergences['stochastic']['latest'],
                "warmup_complete": {"rsi": rsi_value is not None, "stochastic": k_value is not None and d_value is not None,
                                    "ema": all(value is not None for value in values.values())}}

    latest_index = next((index for index in range(len(rows) - 1, -1, -1) if rows[index]["closed"]), None)
    stoch_cfg = cfg["stochastic"]
    return {"settings": cfg, "series": {"rsi": chart_series(rsi), "stochastic_k": chart_series(k), "stochastic_d": chart_series(d),
                                         "ema": {period: chart_series(values) for period, values in ema.items()}},
            "latest": snapshot(latest_index), "preview": snapshot(len(rows) - 1 if rows else None),
            "divergences": divergences,
            "meta": {"bars": len(rows), "closed_bars": sum(row["closed"] for row in rows),
                     "indicator_model": "mt5_divergence_v1",
                     "rsi_method": "MT5 iRSI: Wilder RMA, SMA seed; selected applied price; flat=50",
                     "stochastic_method": "MQ5 Main = 100 * sum(close-lowest K)/sum(highest K-lowest K) over slowing; Signal=SMA Main; flat range=100",
                     "stochastic_state_basis": "smoothed_k",
                     "ema_method": "SMA seed of first period closes, alpha=2/(period+1)",
                     "warmup_bars": {"rsi": cfg["rsi"]["period"] + 1,
                                     "stochastic_k": stoch_cfg["k_period"] + stoch_cfg["k_smoothing"] - 1,
                                     "stochastic_d": stoch_cfg["k_period"] + stoch_cfg["k_smoothing"] + stoch_cfg["d_period"] - 2,
                                     "ema": {str(period): period for period in cfg["ema"]["periods"]}},
                     "preview_is_open": bool(rows and not rows[-1]["closed"]),
                     "screener_basis": "last_closed_candle", "warmup_values_omitted": True}}
