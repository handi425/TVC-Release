"""ZWave display overlay, ported from the user's Triangle/PDF Pine source.

This Source Code Form is subject to the Mozilla Public License, v. 2.0.
https://mozilla.org/MPL/2.0/
Created by XoRonX | Mr Poleks. Confirmed ZigZag adapted from TradingView
ZigZag library v9; Elliott geometry/search from the supplied ZWave sources.
Python integration for HPX Markets. This module does not place orders or alerts.
"""
from __future__ import annotations

from math import isfinite
from typing import Any

from .zwave_settings import validate_zwave_settings

SOURCE_SHA256 = 'f858b4a592f8d5689da597f867132209b0bbf6ba3da926f4cc2183292e1951ee'


def _atr(bars: list[dict], period: int = 14) -> float | None:
    """Pine ta.atr = Wilder RMA seeded with the first period true ranges."""
    ranges = []
    previous = None
    value = None
    for bar in bars:
        if not bar.get('closed', True):
            continue
        high, low, close = (float(bar[k]) for k in ('high', 'low', 'close'))
        tr = max(high-low, abs(high-previous), abs(low-previous)) if previous is not None else high-low
        if value is None:
            ranges.append(tr)
            if len(ranges) == period:
                value = sum(ranges) / period
        else:
            value = (value*(period-1)+tr)/period
        previous = close
    return value


def _validate_bars(bars: list[dict]) -> None:
    previous = -1
    for i, bar in enumerate(bars):
        try:
            time = int(bar['time'])
            o, h, l, c = (float(bar[key]) for key in ('open', 'high', 'low', 'close'))
        except (ValueError, TypeError, KeyError, OverflowError) as exc:
            raise ValueError(f'Candle ZWave {i} tidak valid.') from exc
        if not all(isfinite(x) for x in (o, h, l, c)) or time <= previous or h < max(o, l, c) or l > min(o, h, c):
            raise ValueError(f'OHLC atau urutan candle ZWave {i} tidak valid.')
        if not isinstance(bar.get('closed', True), bool) or (not bar.get('closed', True) and i != len(bars)-1):
            raise ValueError('Hanya candle terakhir yang boleh belum selesai.')
        previous = time


def _core_drawings(core, cfg: dict, atr: float | None, mintick: float) -> dict:
    result = {'lines': [], 'labels': [], 'zones': [], 'panels': []}
    lines, labels = result['lines'], result['labels']
    major, minor = core.major, core.minor
    visible_from = major[max(0, len(major)-cfg['visible_major'])].b if major else (core.candles[-1].b if core.candles else 0)
    fallback_atr = atr if atr is not None else mintick*12

    def line(a, b, color, width=1, style='solid', kind='zigzag'):
        if b.t > a.t and len(lines) < 440:
            lines.append({'x1': a.b, 'y1': a.p, 'x2': b.b, 'y2': b.p, 'color': color, 'width': width, 'style': style, 'kind': kind})

    if cfg['show_zigzag']:
        for i in range(max(1, len(major)-cfg['visible_major']+1), len(major)):
            line(major[i-1], major[i], '#1E90FF', 2)
        for i in range(max(1, len(minor)-200), len(minor)):
            if minor[i-1].b >= visible_from:
                line(minor[i-1], minor[i], '#00CED1', style='dotted')
    merged = {}
    for count in core.counts:
        p = count.pivot
        if p.b < visible_from or (count.degree == 2 and not cfg['show_micro']):
            continue
        key = (count.degree, p.b, p.p, p.hi)
        if key not in merged:
            merged[key] = [count, count.wave_name]
        elif count.wave_name not in merged[key][1].split(' / '):
            merged[key][1] += ' / '+count.wave_name
    for count, text in list(merged.values())[-350:]:
        p, degree = count.pivot, count.degree
        color = cfg[('large_wave_text_color', 'child_wave_text_color', 'micro_wave_text_color')[degree]]
        offset = max(mintick, fallback_atr/12)*(4 if degree == 0 else 2 if degree == 1 else 0.6)
        price = p.p+offset if p.hi else p.p-offset-fallback_atr*cfg['lower_wave_gap']
        labels.append({'index': p.b, 'price': price, 'text': text, 'color': color,
                       'size': cfg['micro_font_size'] if degree == 2 else cfg['wave_font_size'],
                       'position': 'above' if p.hi else 'below', 'kind': 'wave',
                       'tooltip': f'Degree {degree}; ? = developing geometry; known at bar {p.known}'})
    for link in core.links[-64:]:
        if link.three.b >= visible_from and (link.degree != 2 or cfg['show_micro']):
            line(link.three, link.five, '#FF6347' if link.three.hi else '#32CD32', 2, kind='macd-divergence')
    if cfg['show_hidden']:
        ordered = sorted(core.hidden, key=lambda x: (x.endpoint.known, x.endpoint_osc_bar, x.degree), reverse=True)
        for link in ordered[:cfg['hidden_max_signals']]:
            if link.anchor.b < visible_from or link.endpoint.t <= link.anchor.t:
                continue
            if len(lines) >= 440:
                break
            bullish = not link.endpoint.hi
            ink = cfg['hidden_bull_color'] if bullish else cfg['hidden_bear_color']
            line(link.anchor, link.endpoint, ink, style='dashed', kind='hidden-macd')
            if cfg['hidden_show_labels'] and len(labels) < 440:
                degree_name = ('Large', 'Child', 'Micro')[link.degree]
                caption = ('HBull' if bullish else 'HBear')+' ['+degree_name+']'
                offset = max(mintick, fallback_atr*(0.65 if link.degree == 0 else 0.5 if link.degree == 1 else 0.35))
                labels.append({'index': link.endpoint.b, 'price': link.endpoint.p+(-offset if bullish else offset),
                               'text': caption, 'color': ink, 'size': 'Tiny', 'position': 'below' if bullish else 'above',
                               'kind': 'hidden-macd', 'tooltip': f'{caption}; MACD 12/26/9; known after bar {link.endpoint.known}; latest ZigZag endpoint can move'})
    if cfg['show_panel']:
        latest = 'Child: menunggu swing terkonfirmasi' if len(minor) < 2 else 'Child terakhir: struktur belum terselesaikan'
        for count, text in merged.values():
            if count.degree == 1 and minor and (count.pivot.b, count.pivot.p, count.pivot.hi) == (minor[-1].b, minor[-1].p, minor[-1].hi):
                latest = 'Child terakhir: '+text
        result['panels'] = [
            'Batas pencarian tercapai; beberapa struktur belum terselesaikan' if core.work_exhausted else 'Pivot terkonfirmasi | ? = wave berkembang',
            latest, 'MACD 12/26/9 | Created by XoRonX | Mr Poleks',
        ]
    return result


def zwave_analysis(bars: list[dict[str, Any]], settings: dict | None = None, mintick: float = 0.01,
                   *, previous=None, on_core=None, timezone: str = 'UTC') -> dict:
    cfg = validate_zwave_settings(settings)
    meta = {'indicator': 'ZWave - Triangle and Fibonacci', 'source_sha256': SOURCE_SHA256,
            'closed_bars_only': True, 'attribution': 'Created by XoRonX | Mr Poleks',
            'parity_note': 'Port dari source Pine lampiran. Kesamaan 100% dengan TradingView belum diverifikasi; feed dan jumlah riwayat dapat berbeda.'}
    if not cfg['enabled']:
        return {'enabled': False, 'settings': cfg, 'lines': [], 'labels': [], 'zones': [], 'panels': [], 'meta': meta}
    if isinstance(mintick, bool) or not isinstance(mintick, (float, int)) or not isfinite(mintick) or mintick <= 0:
        raise ValueError('Minimum tick ZWave harus positif.')
    _validate_bars(bars)
    from .zwave_core import ZWaveCore
    from .zwave_patterns import analyze_patterns
    from .zwave_pdf import fibonacci_pdf
    core = ZWaveCore(bars, cfg, mintick, previous=previous)
    core.timezone = timezone
    core.analyze()
    base = _core_drawings(core, cfg, _atr(bars), mintick)
    patterns = analyze_patterns(core, cfg)
    pdf = fibonacci_pdf(core, cfg, patterns)
    output = {key: base[key]+patterns.get(key, [])+pdf.get(key, []) for key in ('lines', 'labels', 'zones', 'panels')}
    # Object ceilings protect mobile rendering; Elliott/Triangle/PDF keep priority
    # over optional hidden-divergence drawings when the display is dense.
    available = {key: len(output[key]) for key in ('lines', 'labels', 'zones')}
    for key in ('lines', 'labels'):
        items = output[key]
        if len(items) > 500:
            items = [x for x in items if x.get('kind') != 'hidden-macd']+[x for x in items if x.get('kind') == 'hidden-macd']
            output[key] = items[:500]
    output['zones'] = output['zones'][:100]
    output['panels'] = list(dict.fromkeys(str(x) for x in output['panels'] if x))
    closed = [(i, bar) for i, bar in enumerate(bars) if bar.get('closed', True)]
    meta.update({'bars': len(bars), 'closed_bars': len(closed), 'last_closed_index': closed[-1][0] if closed else None,
                 'last_closed_time': closed[-1][1]['time'] if closed else None,
                 'work_used': core.work_used, 'work_limit': cfg['work_limit'], 'work_exhausted': core.work_exhausted,
                 'pivots': {'large': len(core.major), 'child': len(core.minor), 'micro': len(core.micro)},
                 'wave_labels': len(core.counts), 'display_objects_available': available,
                 'display_objects_rendered': {key: len(output[key]) for key in available},
                 'display_objects_clipped': any(len(output[key]) < available[key] for key in available),
                 'state_restored': getattr(core, 'state_restored', False),
                 'state_restore_reason': getattr(core, 'state_restore_reason', 'fresh historical evaluation')})
    if on_core is not None:
        on_core(core)
    return {'enabled': True, 'settings': cfg, **output, 'patterns': patterns.get('patterns', []),
            'levels': pdf.get('levels', []), 'color_legend': pdf.get('color_legend', []),
            'projection': pdf.get('projection'), 'meta': meta}
