"""ZWave Elliott geometry and confirmed ZigZag, ported from the supplied Pine v6.

This Source Code Form is subject to the Mozilla Public License, v. 2.0.
https://mozilla.org/MPL/2.0/
Created by XoRonX | Mr Poleks. Confirmed ZigZag adapted from TradingView
ZigZag library v9. Elliott geometry originates in the user's ZWave v1.02;
hidden MACD divergence follows ZWave MT5 v1.05 and never changes wave proofs.

Endpoints retain their original candle coordinates and their separate known
index. Only closed candles enter the pivot streams. The search has the same
24-path beam and explicit candidate-edge budget as the supplied indicator.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass, field
import math
from typing import Any


@dataclass(frozen=True)
class Candle:
    b: int
    t: int
    h: float
    l: float
    m: float | None


@dataclass(frozen=True)
class Pivot:
    b: int
    t: int
    p: float
    hi: bool
    known: int


@dataclass
class Pattern:
    points: list[Pivot] = field(default_factory=list)
    fit: float = -1.0


@dataclass
class Count:
    pivot: Pivot
    degree: int
    wave_name: str


@dataclass
class DivLink:
    three: Pivot
    five: Pivot
    degree: int


@dataclass
class HiddenDivLink:
    anchor: Pivot
    endpoint: Pivot
    degree: int
    anchor_osc_bar: int
    endpoint_osc_bar: int
    anchor_macd: float


@dataclass
class ImpulseAnchor:
    origin: Pivot
    one: Pivot
    two: Pivot
    three: Pivot
    degree: int
    developing: bool


@dataclass
class ExtensionSpan:
    two: Pivot
    three: Pivot
    degree: int
    proved: bool


@dataclass
class PFPDFPath:
    points: list[Pivot]
    degree: int
    motive: bool
    developing: bool
    family: str = ""


class RangeCache:
    """Sparse extrema tables over closed bars, retaining original bar indices."""
    def __init__(self, candles: list[Candle]):
        self.base = candles[0].b if candles else 0
        self.n = len(candles)
        self.indices = [c.b for c in candles]
        self.logs = [0] * (self.n + 1)
        for i in range(2, self.n + 1):
            self.logs[i] = self.logs[i // 2] + 1
        self.highs = [[c.h for c in candles]]
        self.lows = [[c.l for c in candles]]
        self.max_macd = [[c.m if c.m is not None else -math.inf for c in candles]]
        self.min_macd = [[c.m if c.m is not None else math.inf for c in candles]]
        self.bad_macd = [0]
        for c in candles:
            self.bad_macd.append(self.bad_macd[-1] + (c.m is None))
        for k in range(1, self.logs[self.n] + 1):
            half = 1 << (k - 1)
            length = self.n - 2 * half + 1
            for table, operation in ((self.highs, max), (self.lows, min),
                                     (self.max_macd, max), (self.min_macd, min)):
                prior = table[k - 1]
                table.append([operation(prior[i], prior[i + half]) for i in range(length)])

    def range(self, from_: int, finish: int, mode: int) -> float | None:
        if not self.n or from_ < self.indices[0] or finish > self.indices[-1] or from_ > finish:
            return None
        a, b = bisect_left(self.indices, from_), bisect_right(self.indices, finish) - 1
        if a > b:
            return None
        if abs(mode) == 2 and self.bad_macd[b + 1] != self.bad_macd[a]:
            return None
        k = self.logs[b - a + 1]
        span = 1 << k
        table = self.highs if mode == 1 else self.lows if mode == -1 else self.max_macd if mode == 2 else self.min_macd
        operation = max if mode > 0 else min
        return operation(table[k][a], table[k][b - span + 1])


def same(a: Pivot | None, b: Pivot | None) -> bool:
    return a is not None and b is not None and a.b == b.b and a.p == b.p and a.hi == b.hi


def fit(ratio: float, target: float) -> float:
    return math.exp(-abs(math.log(ratio / target)) * 2) if ratio > 0 and target > 0 else 0.0


def best_fit(ratio: float, *targets: float) -> float:
    return max((fit(ratio, target) for target in targets), default=0.0)


def geometry(x: list[float], legs: int, kind: int, d: int, eps: float) -> bool:
    if len(x) <= legs or any((d if j % 2 else -d) * (x[j] - x[j - 1]) <= eps for j in range(1, legs + 1)):
        return False
    if kind == 1:
        if legs >= 2 and d * (x[2] - x[0]) <= eps:
            return False
        if legs >= 3 and d * (x[3] - x[1]) <= eps:
            return False
        if legs >= 4 and d * (x[4] - x[1]) <= eps:
            return False
        if legs >= 5:
            one, three, five = abs(x[1] - x[0]), abs(x[3] - x[2]), abs(x[5] - x[4])
            if d * (x[5] - x[3]) <= eps or three + eps < min(one, five):
                return False
    elif legs >= 3:
        origin, finish = d * (x[2] - x[0]), d * (x[3] - x[1])
        return ((origin > eps and finish > eps) if kind == 4 else
                (origin >= -eps and finish > eps) if kind == 5 else
                (origin < -eps and finish > eps) if kind == 6 else
                (origin < -eps and finish < -eps and d * (x[3] - x[0]) > eps) if kind == 7 else False)
    return True


def score(x: list[float], legs: int, kind: int) -> float:
    a = abs(x[1] - x[0])
    terms: list[float] = []
    if a > 0 and kind == 1:
        if legs >= 2:
            terms.append(best_fit(abs(x[2] - x[1]) / a, .5, .618, .786, .886))
        if legs >= 3:
            terms.append(best_fit(abs(x[3] - x[2]) / a, 1, 1.618, 2, 2.618, 3))
        if legs >= 4:
            terms.append(best_fit(abs(x[4] - x[3]) / abs(x[3] - x[2]), .236, .382))
        if legs >= 5:
            five = abs(x[5] - x[4])
            terms.append(max(best_fit(five / abs(x[4] - x[3]), 1.236, 1.618),
                             best_fit(five / abs(x[3] - x[2]), .5, .618, 1)))
    elif a > 0:
        if legs >= 2:
            ratio = abs(x[2] - x[1]) / a
            terms.append(best_fit(ratio, .382, .5, .618) if kind == 4 else best_fit(ratio, .9, 1, 1.13))
        if legs >= 3:
            terms.append(best_fit(abs(x[3] - x[2]) / a, .786, 1, 1.236, 1.618))
    return sum(terms) / len(terms) if terms else 0.0


class ZWaveCore:
    def __init__(self, bars: list[dict], config: dict[str, Any], mintick: float = .00001,
                 *, previous: ZWaveCore | None = None):
        # Keep an immutable-in-practice input snapshot: provider/cache code may
        # replace or mutate its own active candle after this analysis returns.
        self.bars = [dict(bar) for bar in bars]
        self.config = dict(config)
        self.mintick = mintick
        self.eps = mintick * .1
        self.candles: list[Candle] = []
        self.major: list[Pivot] = []
        self.minor: list[Pivot] = []
        self.micro: list[Pivot] = []
        self.counts: list[Count] = []
        self.confirmed_counts: list[Count] = []
        self.links: list[DivLink] = []
        self.hidden: list[HiddenDivLink] = []
        self.paths: list[PFPDFPath] = []
        self.impulse_anchors: list[ImpulseAnchor] = []
        self.extension_spans: list[ExtensionSpan] = []
        self.work_used = 0
        self.cache = RangeCache([])
        self.last_closed_index = -1
        self._candle_by_index: dict[int, Candle] = {}
        self._previous = previous
        self.state_restored = False
        self.state_restore_reason = "fresh_session"

    @property
    def work_limit(self) -> int:
        return int(self.config.get("work_limit", 80000))

    @property
    def work_exhausted(self) -> bool:
        return self.work_used >= self.work_limit

    same = staticmethod(same)
    geometry = staticmethod(geometry)
    score = staticmethod(score)

    def known(self, p: Pivot | None) -> bool:
        if p is None or not self.candles:
            return False
        c = self._candle_by_index.get(p.b)
        return bool(c and p.known > p.b and p.known <= self.candles[-1].b and c.t == p.t and p.p == (c.h if p.hi else c.l))

    def settled(self, p: Pivot, degree: int) -> bool:
        if not self.known(p):
            return False
        for next_ in reversed((self.major, self.minor, self.micro)[degree]):
            if next_.b <= p.b:
                break
            if next_.hi != p.hi:
                return True
        return False

    def find_pivot(self, radius: int, hi: bool) -> Pivot | None:
        n = len(self.candles)
        if n < radius * 2 + 1:
            return None
        center = n - 1 - radius
        c = self.candles[center]
        price = c.h if hi else c.l
        for x in self.candles[center + 1:]:
            if (x.h > price) if hi else (x.l < price):
                return None
        for x in self.candles[center - radius:center]:
            if (x.h >= price) if hi else (x.l <= price):
                return None
        return Pivot(c.b, c.t, price, hi, self.candles[-1].b)

    @staticmethod
    def register(stream: list[Pivot], p: Pivot | None, dev: float) -> bool:
        if p is None:
            return False
        if not stream:
            stream.append(p)
            return True
        last = stream[-1]
        if last.hi == p.hi:
            if (p.p > last.p) if last.hi else (p.p < last.p):
                stream[-1] = p
                return True
        elif last.p != 0:
            move = 100 * (p.p - last.p) / abs(last.p)
            if (not last.hi and move >= dev) or (last.hi and move <= -dev):
                stream.append(p)
                return True
        return False

    def update(self, stream: list[Pivot], dev: float, legs: int) -> bool:
        radius = max(2, math.floor(legs / 2))
        h = self.register(stream, self.find_pivot(radius, True), dev)
        l = self.register(stream, self.find_pivot(radius, False), dev)
        oldest = self.candles[0].b
        while stream and stream[0].b < oldest:
            stream.pop(0)
        return h or l

    def range(self, from_: int, finish: int, mode: int) -> float | None:
        return self.cache.range(from_, finish, mode)

    def inside(self, a: Pivot, b: Pivot, lo: float, hi: float, eps: float | None = None) -> bool:
        eps = self.eps if eps is None else eps
        ok = bool(self.candles and a.b >= self.candles[0].b and b.b <= self.candles[-1].b and a.b < b.b)
        if ok and b.b > a.b + 1:
            low, high = self.range(a.b + 1, b.b - 1, -1), self.range(a.b + 1, b.b - 1, 1)
            ok = low is not None and high is not None and low >= lo - eps and high <= hi + eps
        return ok

    def adverse(self, a: Pivot, b: Pivot, direction: int, level: float, eps: float | None = None) -> bool:
        eps = self.eps if eps is None else eps
        ok = bool(self.candles and a.b >= self.candles[0].b and b.b <= self.candles[-1].b and a.b < b.b)
        if ok and b.b > a.b + 1:
            value = self.range(a.b + 1, b.b - 1, -1 if direction > 0 else 1)
            ok = value is not None and (value > level + eps if direction > 0 else value < level - eps)
        return ok

    @staticmethod
    def keep(pool: list[tuple[list[int], float]], candidate: tuple[list[int], float]) -> None:
        if len(pool) < 24:
            pool.append(candidate)
        else:
            worst = min(range(len(pool)), key=lambda i: pool[i][1])
            if candidate[1] > pool[worst][1]:
                pool[worst] = candidate

    def search(self, points: list[Pivot], legs: int, kind: int, eps: float | None = None) -> Pattern:
        eps = self.eps if eps is None else eps
        n = len(points)
        if not (legs + 1 <= n <= 256 and 2 <= legs <= 5 and self.work_used < self.work_limit):
            return Pattern()
        origin = points[0]
        d = -1 if origin.hi else 1
        endpoint = n - 1
        if any(points[i].b <= points[i - 1].b for i in range(1, n)):
            return Pattern()
        if points[-1].hi != ((d == 1) if legs % 2 else (d == -1)):
            return Pattern()
        pool: list[tuple[list[int], float]] = [([0] * 6, 0.0)]
        done = 0
        for stage in range(1, legs + 1):
            next_: list[tuple[list[int], float]] = []
            for previous, _ in pool:
                a = previous[stage - 1]
                move = d if stage % 2 else -d
                first = endpoint if stage == legs else a + 1
                last = endpoint if stage == legs else endpoint - (legs - stage)
                for b in range(first, last + 1):
                    self.work_used += 1
                    if self.work_used > self.work_limit:
                        break
                    pa, pb = points[a], points[b]
                    if pb.hi != (move == 1) or move * (pb.p - pa.p) <= eps:
                        continue
                    motive_role = bool(stage % 2) if kind == 1 else stage != 2 if kind == 4 else stage == 3
                    if motive_role and not self.inside(pa, pb, min(pa.p, pb.p), max(pa.p, pb.p), eps):
                        continue
                    at = previous.copy()
                    at[stage] = b
                    x = [points[at[k]].p for k in range(stage + 1)]
                    if not geometry(x, stage, kind, d, eps):
                        continue
                    if kind == 1 and stage == 2 and not self.adverse(pa, pb, d, x[0], eps):
                        continue
                    if kind == 1 and stage == 4 and not self.adverse(pa, pb, d, x[1], eps):
                        continue
                    self.keep(next_, (at, score(x, stage, kind)))
                if self.work_used > self.work_limit:
                    break
            if not next_ or self.work_used > self.work_limit:
                break
            pool, done = next_, stage
        if done != legs:
            return Pattern()
        chosen, quality = max(pool, key=lambda item: item[1])
        return Pattern([points[chosen[j]] for j in range(legs + 1)], quality)

    @staticmethod
    def append(points: list[Pivot], p: Pivot) -> bool:
        n = len(points)
        if not n:
            points.append(p)
        else:
            last = points[-1]
            if p.b <= last.b:
                return False
            if p.hi == last.hi:
                if n > 1 and ((p.p > last.p) if p.hi else (p.p < last.p)):
                    points[-1] = p
            elif n >= 256:
                return False
            else:
                points.append(p)
        return True

    def collect(self, stream: list[Pivot], start: Pivot, finish: Pivot | None, fixed_finish: bool) -> list[Pivot]:
        if not self.known(start) or (fixed_finish and (not self.known(finish) or finish.b <= start.b)):
            return []
        points = [start]
        for p in stream:
            if p.b <= start.b or (fixed_finish and p.b >= finish.b):
                continue
            if not self.known(p) or not self.append(points, p):
                return []
        if fixed_finish:
            if len(points) > 1 and points[-1].hi == finish.hi:
                points[-1] = finish
            elif not self.append(points, finish):
                return []
        return points if len(points) >= 2 else []

    def correction(self, points: list[Pivot], legs: int, eps: float | None = None) -> Pattern:
        best = Pattern()
        for kind in range(4, 8):
            candidate = self.search(points, legs, kind, eps)
            if candidate.fit > best.fit:
                best = candidate
        return best

    def proof(self, finer: list[Pivot], start: Pivot, finish: Pivot, motive: bool, eps: float | None = None) -> Pattern:
        if start.hi == finish.hi:
            return Pattern()
        points = self.collect(finer, start, finish, True)
        return self.search(points, 5, 1, eps) if motive else self.correction(points, 3, eps)

    def divergence(self, proof: list[Pivot]) -> bool:
        if len(proof) != 6:
            return False
        two, three, four, five = proof[2:]
        up = not proof[0].hi
        m3 = self.range(two.b, three.b, 2 if up else -2)
        m5 = self.range(four.b, five.b, 2 if up else -2)
        return bool(four.b > three.b and three.hi == five.hi and m3 is not None and m5 is not None
                    and (five.p > three.p and m5 < m3 if up else five.p < three.p and m5 > m3))

    def hidden_oscillator(self, stream: list[Pivot], point: int, extremes: bool) -> tuple[int | None, float | None]:
        p = stream[point]
        left = p.b
        if p.b not in self._candle_by_index:
            return None, None
        if extremes:
            if point == 0:
                return None, None
            left = stream[point - 1].b
            if left not in self._candle_by_index or left > p.b:
                return None, None
        value = self.range(left, p.b, 2 if p.hi else -2)
        if value is not None:
            for candle in reversed(self.candles):
                if candle.b > p.b:
                    continue
                if candle.b < left:
                    break
                if candle.m == value:
                    return candle.b, value
        return None, value

    @staticmethod
    def hidden_match(high_point: bool, old_price: float | None, new_price: float | None,
                     old_macd: float | None, new_macd: float | None, zero_filter: bool) -> bool:
        if any(value is None for value in (old_price, new_price, old_macd, new_macd)):
            return False
        same_side = not zero_filter or (old_macd > 0 and new_macd > 0 if high_point else old_macd < 0 and new_macd < 0)
        return same_side and (new_price < old_price and new_macd > old_macd if high_point else new_price > old_price and new_macd < old_macd)

    def hidden_degree(self, stream: list[Pivot], degree: int, min_bars: int, max_bars: int,
                      zero_filter: bool, extremes: bool, out: list[HiddenDivLink]) -> int:
        oscillator = [self.hidden_oscillator(stream, i, extremes) for i in range(len(stream))]
        high_chain = low_chain = None
        for i in range(2, len(stream)):
            previous, current = stream[i - 2], stream[i]
            old_osc, old_value = oscillator[i - 2]
            new_osc, new_value = oscillator[i]
            valid = (previous.hi == current.hi and previous.b >= self.cache.base and old_osc is not None
                     and new_osc is not None and new_osc > old_osc and current.known > current.b
                     and current.known <= self.last_closed_index)
            extended = False
            chain = high_chain if current.hi else low_chain
            if valid and chain is not None:
                direction = current.p < previous.p if current.hi else current.p > previous.p
                distance = current.b - chain.anchor.b
                if (chain.endpoint.b == previous.b and direction and min_bars <= distance <= max_bars
                        and new_osc > chain.anchor_osc_bar
                        and self.hidden_match(current.hi, chain.anchor.p, current.p, chain.anchor_macd, new_value, zero_filter)):
                    chain.endpoint, chain.endpoint_osc_bar = current, new_osc
                    extended = True
            if not extended:
                chain = None
                distance = current.b - previous.b
                if (valid and min_bars <= distance <= max_bars
                        and self.hidden_match(current.hi, previous.p, current.p, old_value, new_value, zero_filter)):
                    chain = HiddenDivLink(previous, current, degree, old_osc, new_osc, old_value)
                    out.append(chain)
            if current.hi:
                high_chain = chain
            else:
                low_chain = chain
        return len(out)

    def prepare_counts(self, counts: list[Count]) -> None:
        for i in range(len(self.confirmed_counts) - 1, -1, -1):
            c = self.confirmed_counts[i]
            if not self.known(c.pivot):
                self.confirmed_counts.pop(i)
            else:
                counts.append(Count(c.pivot, c.degree, c.wave_name))
        self.impulse_anchors[:] = [a for a in self.impulse_anchors if not a.developing and self.known(a.origin) and self.known(a.three)]
        self.extension_spans[:] = [s for s in self.extension_spans if s.proved and self.known(s.two) and self.known(s.three)]

    def _restore_previous(self) -> None:
        """Carry source-style settled state across a compatible closed-bar step.

        A process/session restart intentionally behaves like a fresh Pine chart.
        Revisions, changed settings, and unrelated histories also start fresh.
        Original pivot and confirmation timestamps, rather than old bar indices,
        are the identity when a provider's rolling window moves forward.
        """
        previous = self._previous
        self._previous = None  # do not retain an unbounded linked history
        if previous is None:
            return
        if self.config != previous.config or self.mintick != previous.mintick:
            self.state_restore_reason = "settings_changed"
            return
        if not self.candles or not previous.candles:
            self.state_restore_reason = "empty_history"
            return
        if self.candles[-1].t <= previous.candles[-1].t:
            self.state_restore_reason = "closed_history_not_advanced"
            return
        current_closed = {int(bar["time"]): (i, bar) for i, bar in enumerate(self.bars) if bar.get("closed", True)}
        previous_closed = {int(bar["time"]): bar for bar in previous.bars if bar.get("closed", True)}
        shared = current_closed.keys() & previous_closed.keys()
        if not shared:
            self.state_restore_reason = "no_closed_history_overlap"
            return
        if any(any(float(current_closed[t][1][key]) != float(previous_closed[t][key])
                       for key in ("open", "high", "low", "close")) for t in shared):
            self.state_restore_reason = "closed_history_revised"
            return
        # Missing interior closed bars are a changed history, even when its
        # surviving OHLC values happen to match. A dropped prefix is permitted.
        overlap_start, overlap_end = max(min(current_closed), min(previous_closed)), min(max(current_closed), max(previous_closed))
        if ({t for t in current_closed if overlap_start <= t <= overlap_end}
                != {t for t in previous_closed if overlap_start <= t <= overlap_end}):
            self.state_restore_reason = "closed_history_revised"
            return

        memo: dict[Pivot, Pivot | None] = {}

        def remap(p: Pivot) -> Pivot | None:
            if p in memo:
                return memo[p]
            mapped = None
            if (p.t in current_closed and 0 <= p.known < len(previous.bars)
                    and previous.bars[p.known].get("closed", True)):
                confirmation_time = int(previous.bars[p.known]["time"])
                if confirmation_time in current_closed:
                    b = current_closed[p.t][0]
                    known = current_closed[confirmation_time][0]
                    candidate = Pivot(b, p.t, p.p, p.hi, known)
                    if self.known(candidate):
                        mapped = candidate
            memo[p] = mapped
            return mapped

        self.confirmed_counts = []
        for c in previous.confirmed_counts:
            p = remap(c.pivot)
            if p is not None and "?" not in c.wave_name:
                self.confirmed_counts.append(Count(p, c.degree, c.wave_name))
        self.impulse_anchors = []
        for anchor in previous.impulse_anchors:
            points = [remap(p) for p in (anchor.origin, anchor.one, anchor.two, anchor.three)]
            if not anchor.developing and all(p is not None for p in points):
                self.impulse_anchors.append(ImpulseAnchor(*points, anchor.degree, False))
        self.extension_spans = []
        for span in previous.extension_spans:
            two, three = remap(span.two), remap(span.three)
            if span.proved and two is not None and three is not None:
                self.extension_spans.append(ExtensionSpan(two, three, span.degree, True))
        self.state_restored = True
        self.state_restore_reason = "closed_history_advanced"

    def remember_counts(self, counts: list[Count]) -> None:
        self.confirmed_counts = [Count(c.pivot, c.degree, c.wave_name) for c in counts
                                 if "?" not in c.wave_name and self.settled(c.pivot, c.degree)]

    def add_count(self, counts: list[Count], p: Pivot, degree: int, wave_name: str) -> None:
        exists = False
        developing = "?" in wave_name
        for i in range(len(counts) - 1, -1, -1):
            c = counts[i]
            if c.degree == degree and same(c.pivot, p):
                old_developing = "?" in c.wave_name
                if not developing and old_developing:
                    counts.pop(i)
                elif not old_developing or c.wave_name == wave_name:
                    exists = True
        if not exists:
            counts.append(Count(p, degree, wave_name))

    @staticmethod
    def counted(counts: list[Count], p: Pivot, degree: int) -> bool:
        return any(c.degree == degree and same(c.pivot, p) and "?" not in c.wave_name for c in counts)

    def extended_three(self, points: list[Pivot]) -> bool:
        if len(points) < 4:
            return False
        one, three = abs(points[1].p - points[0].p), abs(points[3].p - points[2].p)
        return one > self.eps and three >= 2.618 * one

    @staticmethod
    def remove_three(counts: list[Count], p: Pivot, degree: int) -> None:
        counts[:] = [c for c in counts if not (c.degree == degree and same(c.pivot, p) and c.wave_name in ("3", "3?"))]

    @staticmethod
    def conflicting_count(counts: list[Count], p: Pivot, degree: int, wave_name: str) -> bool:
        return any(c.degree == degree and same(c.pivot, p) and "?" not in c.wave_name and c.wave_name != wave_name for c in counts)

    def record_three(self, points: list[Pivot], degree: int, developing: bool,
                     counts: list[Count], proved_third: bool) -> int:
        accepted = 1
        if len(points) < 4:
            return accepted
        origin, one, two, three = points[:4]
        extended = self.extended_three(points)
        conflict = self.conflicting_count(counts, one, degree, "1") or self.conflicting_count(counts, two, degree, "2")
        found = next((i for i, a in enumerate(self.impulse_anchors) if a.degree == degree
                      and same(a.origin, origin) and same(a.one, one) and same(a.two, two)), -1)
        if conflict:
            accepted = 0
        elif found >= 0:
            prior = self.impulse_anchors[found]
            if not same(prior.three, three):
                further = three.b > prior.three.b and (three.p > prior.three.p if three.hi else three.p < prior.three.p)
                proved_extension = extended and (not developing or proved_third)
                if further and extended and developing and not prior.developing and degree == 1 and not proved_third:
                    proved_extension = self.proof(self.micro, two, three, True).fit >= 0
                if further and (prior.developing or proved_extension):
                    self.remove_three(counts, prior.three, degree)
                    self.remove_three(self.confirmed_counts, prior.three, degree)
                    accepted = 1 if prior.developing else 2
                else:
                    accepted = 0
            elif extended and not prior.developing and developing:
                accepted = 2
            if accepted > 0:
                self.impulse_anchors[found] = ImpulseAnchor(origin, one, two, three, degree, developing and prior.developing)
        else:
            self.impulse_anchors.append(ImpulseAnchor(origin, one, two, three, degree, developing))
        if accepted > 0 and extended:
            span_index = next((i for i, s in enumerate(self.extension_spans) if s.degree == degree and same(s.two, two)), -1)
            span = ExtensionSpan(two, three, degree, not developing or accepted == 2)
            if span_index >= 0:
                self.extension_spans[span_index] = span
            else:
                self.extension_spans.append(span)
        return accepted

    def internal_extension(self, p: Pivot, degree: int, wave_name: str) -> bool:
        for span in self.extension_spans:
            outer_three = degree == span.degree and same(p, span.three) and wave_name in ("3", "3?")
            if span.two.b < p.b <= span.three.b and degree >= span.degree and not outer_three:
                return True
        return False

    def filter_extensions(self, counts: list[Count], links: list[DivLink]) -> None:
        counts[:] = [c for c in counts if not self.internal_extension(c.pivot, c.degree, c.wave_name)]
        links[:] = [link for link in links if not any(link.degree >= span.degree and link.three.b > span.two.b
                                                     and link.five.b <= span.three.b for span in self.extension_spans)]

    def record_path(self, points: list[Pivot], degree: int, motive: bool, developing: bool, family: str = "") -> None:
        if not (2 <= len(points) <= 6 and degree <= 1):
            return
        candidate = PFPDFPath(points.copy(), degree, motive, developing, family)
        in_degree: list[tuple[int, PFPDFPath]] = []
        for i, prior in enumerate(self.paths):
            if prior.degree != degree:
                continue
            in_degree.append((i, prior))
            if (prior.motive == motive and prior.family == family and len(prior.points) == len(points)
                    and all(same(a, b) for a, b in zip(prior.points, points))):
                prior.developing = prior.developing and developing
                return
        if len(in_degree) >= 12:
            oldest, path = min(in_degree, key=lambda pair: pair[1].points[-1].b)
            if points[-1].b < path.points[-1].b:
                return
            self.paths.pop(oldest)
        self.paths.append(candidate)

    def emit(self, points: list[Pivot], degree: int, motive: bool, developing: bool,
             preserve_existing: bool, counts: list[Count], links: list[DivLink], proved_third: bool = False) -> None:
        if len(points) <= 1:
            return
        accepted = self.record_three(points, degree, developing, counts, proved_third) if motive else 1
        if accepted > 0:
            self.record_path(points, degree, motive, developing)
        if accepted > 0 and motive and not developing and self.divergence(points):
            three, five = points[3], points[5]
            if not any(link.degree == degree and same(link.three, three) and same(link.five, five) for link in links):
                links.append(DivLink(three, five, degree))
        for i, p in enumerate(points[1:], 1):
            extension_three = motive and i == 3 and self.extended_three(points)
            if (accepted == 0 or (developing and not self.config.get("show_developing", True) and not (i == 3 and accepted == 2))
                    or (preserve_existing and not extension_three and self.counted(counts, p, degree))):
                continue
            wave_name = str(i) if motive else "A" if i == 1 else "B" if i == 2 else "C"
            if developing and not (i == 3 and accepted == 2):
                wave_name += "?"
            if extension_three and not self.counted(counts, p, degree):
                self.add_count(counts, p, degree, wave_name)
            elif extension_three:
                if "?" not in wave_name:
                    counts[:] = [c for c in counts if not (c.degree == degree and same(c.pivot, p) and "?" in c.wave_name)]
                if not any(c.degree == degree and same(c.pivot, p) and c.wave_name in ("3", wave_name) for c in counts):
                    counts.append(Count(p, degree, wave_name))
            else:
                self.add_count(counts, p, degree, wave_name)

    def nested(self, points: list[Pivot], eps: float, counts: list[Count], links: list[DivLink]) -> None:
        if not self.config.get("show_micro", False):
            return
        for leg in range(1, len(points)):
            if leg == 3 and self.extended_three(points):
                continue
            start, finish = points[leg - 1], points[leg]
            five = self.proof(self.micro, start, finish, True, eps)
            if five.fit >= 0:
                self.emit(five.points, 2, True, False, False, counts, links)
            else:
                abc = self.proof(self.micro, start, finish, False, eps)
                if abc.fit >= 0:
                    self.emit(abc.points, 2, False, False, False, counts, links)

    def first_complete(self, points: list[Pivot], motive: bool, eps: float) -> Pattern:
        legs = 5 if motive else 3
        for finish in range(legs, len(points)):
            if points[finish].hi == points[0].hi:
                continue
            prefix = points[:finish + 1]
            candidate = self.search(prefix, 5, 1, eps) if motive else self.correction(prefix, 3, eps)
            if candidate.fit >= 0:
                return candidate
            if self.work_used > self.work_limit:
                break
        return Pattern()

    def partial(self, points: list[Pivot], motive: bool, eps: float) -> Pattern:
        legs = min(4 if motive else 2, len(points) - 1)
        while legs >= 2:
            candidate = self.search(points, legs, 1, eps) if motive else self.correction(points, legs, eps)
            if candidate.fit >= 0:
                return candidate
            legs -= 1
        if len(points) == 2:
            a, b = points
            d = -1 if a.hi else 1
            if (a.hi != b.hi and d * (b.p - a.p) > eps
                    and (not motive or self.inside(a, b, min(a.p, b.p), max(a.p, b.p), eps))):
                return Pattern(points.copy(), 0.0)
        return Pattern()

    def locked_extension(self, points: list[Pivot], degree: int, eps: float) -> Pattern:
        if degree != 1 or len(points) < 4 or not self.impulse_anchors or self.work_used >= self.work_limit:
            return Pattern()
        origin, last = points[0], points[-1]
        for anchor in reversed(self.impulse_anchors[-128:]):
            if anchor.degree != degree or not same(anchor.origin, origin):
                continue
            three = anchor.three
            for p in points[1:]:
                if p.b > anchor.three.b and p.hi == three.hi and (p.p > three.p if three.hi else p.p < three.p):
                    three = p
            if same(three, anchor.three):
                continue
            candidate = [origin, anchor.one, anchor.two, three]
            prices = [p.p for p in candidate]
            d = -1 if origin.hi else 1
            if (not self.extended_three(candidate) or not geometry(prices, 3, 1, d, eps)
                    or not self.inside(anchor.two, three, min(anchor.two.p, three.p), max(anchor.two.p, three.p), eps)):
                continue
            proof = self.proof(self.micro, anchor.two, three, True, eps)
            if proof.fit < 0:
                if self.work_used >= self.work_limit:
                    break
                continue
            if last.b > three.b and last.hi != three.hi:
                prices.append(last.p)
                if geometry(prices, 4, 1, d, eps) and self.adverse(three, last, d, anchor.one.p, eps):
                    candidate.append(last)
            return Pattern(candidate, proof.fit)
        return Pattern()

    def first_real_endpoint(self, start: Pivot, last: int, motive: bool, eps: float) -> Pattern:
        for endpoint in self.minor:
            if endpoint.b <= start.b or endpoint.b > last or endpoint.hi == start.hi:
                continue
            candidate = self.proof(self.minor, start, endpoint, motive, eps)
            if candidate.fit >= 0:
                return candidate
            if self.work_used > self.work_limit:
                break
        return Pattern()

    def sequential(self, start: Pivot, finish: Pivot | None, fixed_finish: bool, eps: float,
                   counts: list[Count], links: list[DivLink]) -> bool:
        have_pair, anchor = False, start
        selected: list[tuple[Pattern, bool]] = []
        last = finish.b if fixed_finish else self.candles[-1].b
        for _ in range(4):
            five = self.first_real_endpoint(anchor, last, True, eps)
            if five.fit < 0:
                break
            abc = self.first_real_endpoint(five.points[5], last, False, eps)
            if abc.fit < 0 and not have_pair:
                break
            selected.append((five, True))
            if abc.fit < 0:
                break
            selected.append((abc, False))
            have_pair = True
            anchor = abc.points[3]
            if fixed_finish and anchor.b >= finish.b:
                break
        if have_pair:
            for pattern, motive in selected:
                self.emit(pattern.points, 1, motive, False, False, counts, links)
                self.nested(pattern.points, eps, counts, links)
        return have_pair

    def continue_(self, finer: list[Pivot], start: Pivot, finish: Pivot | None, fixed_finish: bool,
                  degree: int, eps: float, counts: list[Count], links: list[DivLink]) -> None:
        anchor, motive = start, True
        last = finish.b if fixed_finish else self.candles[-1].b
        for c in counts:
            if (c.degree == degree and anchor.b < c.pivot.b <= last and c.wave_name in ("5", "C")
                    and not self.internal_extension(c.pivot, c.degree, c.wave_name)):
                anchor, motive = c.pivot, c.wave_name == "C"
        if fixed_finish and anchor.b >= finish.b:
            return
        for _ in range(12):
            points = self.collect(finer, anchor, finish, fixed_finish)
            if len(points) < 2:
                break
            extended = self.locked_extension(points, degree, eps) if motive else Pattern()
            if extended.fit >= 0:
                self.emit(extended.points, degree, True, True, True, counts, links, True)
                break
            full = self.first_complete(points, motive, eps)
            if full.fit >= 0:
                self.emit(full.points, degree, motive, False, True, counts, links)
                next_ = full.points[-1]
                if next_.b <= anchor.b:
                    break
                anchor, motive = next_, not motive
                if fixed_finish and anchor.b >= finish.b:
                    break
            else:
                partial = self.partial(points, motive, eps)
                if (partial.fit >= 0 and self.config.get("show_developing", True)
                        and (not fixed_finish or not self.settled(finish, degree - 1))):
                    self.emit(partial.points, degree, motive, True, True, counts, links)
                break

    def analysis(self, counts: list[Count], links: list[DivLink], eps: float) -> None:
        m = len(self.major)
        if not m:
            return
        first = max(1, m - 12)
        five_cache = [Pattern() for _ in self.major]
        for i in range(first, m):
            start, finish = self.major[i - 1], self.major[i]
            five = self.proof(self.minor, start, finish, True, eps)
            five_cache[i] = five
            abc = self.proof(self.minor, start, finish, False, eps)
            extended = five if five.fit >= 0 and self.extended_three(five.points) else self.locked_extension(self.collect(self.minor, start, finish, True), 1, eps)
            sequential = self.sequential(start, finish, True, eps, counts, links) if extended.fit < 0 else False
            if extended.fit >= 0:
                self.emit(extended.points, 1, True, len(extended.points) < 6, False, counts, links, True)
                self.nested(extended.points, eps, counts, links)
            elif five.fit >= 0:
                if not sequential:
                    self.emit(five.points, 1, True, False, False, counts, links)
                    self.nested(five.points, eps, counts, links)
            elif abc.fit >= 0 and not sequential:
                self.emit(abc.points, 1, False, False, False, counts, links)
                self.nested(abc.points, eps, counts, links)
        for i in range(first, m - 3):
            if five_cache[i].fit < 0:
                continue
            abc = self.correction(self.major[i:i + 4], 3, eps)
            if abc.fit < 0:
                continue
            self.emit(abc.points, 0, False, False, False, counts, links)
            if i + 4 < m:
                self.add_count(counts, self.major[i + 4], 0, "D")
        origin = self.major[-1]
        active = self.collect(self.minor, origin, None, False)
        five = self.search(active, 5, 1, eps)
        extended = five if five.fit >= 0 and self.extended_three(five.points) else self.locked_extension(active, 1, eps)
        sequential = self.sequential(origin, None, False, eps, counts, links) if extended.fit < 0 else False
        if extended.fit >= 0:
            self.emit(extended.points, 1, True, len(extended.points) < 6, False, counts, links, True)
            self.nested(extended.points, eps, counts, links)
        elif not sequential:
            if five.fit >= 0:
                self.emit(five.points, 1, True, False, False, counts, links)
                self.nested(five.points, eps, counts, links)
            else:
                abc = self.correction(active, 3, eps)
                if abc.fit >= 0:
                    self.emit(abc.points, 1, False, False, False, counts, links)
                    self.nested(abc.points, eps, counts, links)
                if self.config.get("show_developing", True) and len(active) >= 3:
                    partial = self.partial(active, True, eps)
                    if partial.fit >= 0:
                        self.emit(partial.points, 1, True, True, False, counts, links)
                        self.nested(partial.points, eps, counts, links)
        for i in range(first, m):
            self.continue_(self.minor, self.major[i - 1], self.major[i], True, 1, eps, counts, links)
        self.continue_(self.minor, origin, None, False, 1, eps, counts, links)
        mn = len(self.minor)
        child_first = max(1, mn - 48)
        visible_start = self.major[max(0, m - 13)].b
        if self.config.get("show_micro", False):
            for i in range(child_first, mn):
                if self.minor[i - 1].b >= visible_start:
                    self.continue_(self.micro, self.minor[i - 1], self.minor[i], True, 2, eps, counts, links)
            if mn and self.minor[-1].b >= visible_start:
                self.continue_(self.micro, self.minor[-1], None, False, 2, eps, counts, links)

    def analyze(self) -> ZWaveCore:
        # ta.ema starts from the first source value. Warm up before cropping so
        # MACD within the history window does not acquire a different seed.
        fast = slow = None
        history = int(self.config.get("history_bars", 5000))
        start = max(0, len(self.bars) - 1 - history)
        deviation = float(self.config.get("deviation", 2.5))
        factor = float(self.config.get("factor", 3.0))
        if deviation / (factor * factor) < .00001:
            raise ValueError("Child/micro deviation must be at least 0.00001%.")
        for index, bar in enumerate(self.bars):
            close = float(bar["close"])
            fast = close if fast is None else (2 / 13) * close + (11 / 13) * fast
            slow = close if slow is None else (2 / 27) * close + (25 / 27) * slow
            if not bar.get("closed", True) or index < start:
                continue
            self.candles.append(Candle(index, int(bar["time"]), float(bar["high"]), float(bar["low"]), fast - slow))
            if len(self.candles) > history:
                self.candles.pop(0)
            self.update(self.major, deviation, int(self.config.get("depth", 10)))
            self.update(self.minor, deviation / factor, int(self.config.get("child_depth", 4)))
            self.update(self.micro, deviation / (factor * factor), 2)
        if not self.candles:
            return self
        self.last_closed_index = self.candles[-1].b
        self._candle_by_index = {c.b: c for c in self.candles}
        self.cache = RangeCache(self.candles)
        self.work_used = 0
        self._restore_previous()
        self.prepare_counts(self.counts)
        self.analysis(self.counts, self.links, self.eps)
        self.remember_counts(self.counts)
        self.filter_extensions(self.counts, self.links)
        if self.config.get("show_hidden", True):
            minimum = int(self.config.get("hidden_min_bars", 5))
            maximum = int(self.config.get("hidden_max_bars", 500))
            if maximum < minimum:
                raise ValueError("Hidden divergence maximum bars must be at least minimum bars.")
            for degree, stream, key in ((0, self.major, "hidden_large"), (1, self.minor, "hidden_child"), (2, self.micro, "hidden_micro")):
                if self.config.get(key, True):
                    self.hidden_degree(stream, degree, minimum, maximum, bool(self.config.get("hidden_same_side_of_zero", False)),
                                       bool(self.config.get("hidden_use_swing_extremes", True)), self.hidden)
        return self
