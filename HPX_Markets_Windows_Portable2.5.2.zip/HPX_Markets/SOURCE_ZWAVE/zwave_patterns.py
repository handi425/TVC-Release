"""ZWave Triangle/ABC boundary port from the supplied Pine v6 indicator.

This Source Code Form is subject to the Mozilla Public License, v. 2.0.
https://mozilla.org/MPL/2.0/
Created by XoRonX | Mr Poleks. Python adaptation for HPX Markets.
Geometry candidates and child-subdivision proofs are deliberately distinct;
neither proves the parent wave 4/B/X placement.
"""
from __future__ import annotations

from dataclasses import asdict
from math import floor
from typing import Any


PATTERN_DEFAULTS = {
    "zt_triangles": True, "zt_boundaries": True, "zt_abc": True,
    "zt_large": True, "zt_child": True, "zt_legs": True, "zt_strict": False,
    "zt_projection": 20, "zt_max": 2, "zt_tolerance": 5.0, "zt_status": True,
    "zt_large_color": "#7B1FA2", "zt_child_color": "#00796B",
}

EXPLANATION = ("G: geometry candidate. S: every child leg proved. Parent wave "
               "4/B/X placement is not verified. Endpoint is settled by a later "
               "opposite pivot; counts remain alternative Elliott interpretations.")


def same_pivot(a: Any, b: Any) -> bool:
    return a.b == b.b and a.p == b.p and a.hi == b.hi


def triangle_kind(points: list, eps: float, tolerance_percent: float = 5.0) -> str:
    """Exact zt_triangleKind rules, including the projected A-C/B-D envelope."""
    if len(points) != 6:
        return ""
    o, a, b, c, d, e = points
    if c.b == a.b or d.b == b.b:
        return ""
    direction = 1.0 if a.p > o.p else -1.0
    ay, by, cy, dy, ey = (direction * (point.p - o.p) for point in (a, b, c, d, e))
    tolerance = max(eps * 2, ay * tolerance_percent / 100)
    contracting = cy < ay - tolerance and dy > by + tolerance and ey < cy - eps
    barrier_low = cy < ay - tolerance and abs(dy - by) <= tolerance and ey < cy - eps
    barrier_high = abs(cy - ay) <= tolerance and dy > by + tolerance and ey < cy + tolerance
    expanding = cy > ay + tolerance and dy < by - tolerance and ey > cy + eps
    upper_slope = (cy - ay) / (c.b - a.b)
    lower_slope = (dy - by) / (d.b - b.b)
    upper_e = ay + upper_slope * (e.b - a.b)
    lower_e = by + lower_slope * (e.b - b.b)
    envelope = upper_e > lower_e + eps and ey > lower_e - tolerance and ey <= upper_e + tolerance
    if ay > eps and envelope:
        if (contracting or barrier_low or barrier_high) and upper_slope < lower_slope:
            return "Barrier" if barrier_low or barrier_high else "Running contracting" if by < -eps else "Contracting"
        if expanding and upper_slope > lower_slope:
            return "Expanding"
    return ""


def ordered(core: Any, points: list, eps: float) -> bool:
    for a, b in zip(points, points[1:]):
        if (not core.known(a) or not core.known(b) or b.b <= a.b or b.t <= a.t
                or a.hi == b.hi or abs(b.p - a.p) <= eps):
            return False
        if not core.inside(a, b, min(a.p, b.p), max(a.p, b.p), eps):
            return False
    return True


def subdivisions(core: Any, finer: list, points: list, kind: int, eps: float) -> bool:
    for j in range(1, len(points)):
        motive = False if kind == 0 else j != 2 if kind == 4 else j == 3
        if core.proof(finer, points[j - 1], points[j], motive, eps).fit < 0:
            return False
    return True


class _Draw:
    def __init__(self, last: int, config: dict):
        self.last, self.config = last, config
        self.lines: list[dict] = []
        self.labels: list[dict] = []

    def line(self, x1, y1, x2, y2, color, style, width, opacity=1.0):
        if x2 > x1 and x1 >= self.last - 9999 and x2 <= self.last + 500 and len(self.lines) < 40:
            self.lines.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2,
                               "color": color, "style": style, "width": width,
                               "opacity": opacity, "kind": "pattern_boundary"})

    def label(self, point, text, color, badge=False):
        if point.b >= self.last - 9999 and len(self.labels) < 40:
            self.labels.append({"index": point.b, "price": point.p, "text": text,
                                "color": color, "size": "Tiny", "badge": badge,
                                "above": point.hi, "kind": "pattern_boundary",
                                "tooltip": EXPLANATION})

    def bounds(self, a, c, b, d, finish, color, style, opacity=1.0):
        upper_slope = (c.p - a.p) / (c.b - a.b)
        lower_slope = (d.p - b.p) / (d.b - b.b)
        delta = upper_slope - lower_slope
        gap = a.p + upper_slope * (finish.b - a.b) - b.p - lower_slope * (finish.b - b.b)
        apex = finish.b - gap / delta if abs(delta) > 1e-12 else None
        end = min(finish.b + self.config["zt_projection"], self.last + 200)
        if apex is not None:
            end = min(end, floor(apex - 1)) if apex > finish.b else finish.b
        end = max(finish.b, end)
        self.line(a.b, a.p, end, a.p + upper_slope * (end - a.b), color, style, 2, opacity)
        self.line(b.b, b.p, end, b.p + lower_slope * (end - b.b), color, style, 2, opacity)


def analyze_patterns(core: Any, config: dict | None = None) -> dict:
    """Scan settled, non-overlapping patterns and append Triangle PDF anchors."""
    cfg = {**PATTERN_DEFAULTS, **(config or {})}
    last = core.candles[-1].b if core.candles else -1
    visible = core.major[max(0, len(core.major) - cfg.get("visible_major", 24))].b if core.major else last
    eps = core.mintick * 0.1
    draw = _Draw(last, cfg)
    patterns: list[dict] = []
    totals = {"triangles_large": 0, "triangles_child": 0, "abc_large": 0, "abc_child": 0}

    def record(points, degree, family, proved):
        patterns.append({"family": family, "degree": degree, "proof": "S" if proved else "G",
                         "parent_verified": False, "settled": True,
                         "points": [asdict(p) for p in points]})

    def triangles(stream, finer, degree, ink):
        shown, before, n = 0, last + 1, len(stream)
        if not cfg["zt_triangles"] or n < 7:
            return shown
        for i in range(n - 2, max(5, n - 81) - 1, -1):
            endpoint, origin = stream[i], stream[i - 5]
            if origin.b < visible or endpoint.b >= before:
                continue
            points = stream[i - 5:i + 1]
            if not ordered(core, points, eps):
                continue
            kind = triangle_kind(points, eps, cfg["zt_tolerance"])
            if not kind:
                continue
            proved = subdivisions(core, finer, points, 0, eps)
            if cfg["zt_strict"] and not proved:
                continue
            style = "solid" if proved else "dashed"
            if cfg["zt_legs"]:
                for j, name in enumerate("ABCDE", 1):
                    a, b = points[j - 1:j + 1]
                    draw.line(a.b, a.p, b.b, b.p, ink, style, 1, 0.7)
                    draw.label(b, name, ink)
            if cfg["zt_boundaries"]:
                draw.bounds(points[1], points[3], points[2], points[4], endpoint, ink, style)
            core.record_path(points, degree, False, False, "Triangle " + kind)
            draw.label(endpoint, "Triangle " + kind + " [" + ("S" if proved else "G") + "] "
                       + ("Large" if degree == 0 else "Child"), ink, True)
            record(points, degree, "Triangle " + kind, proved)
            shown += 1
            before = origin.b
            if shown >= cfg["zt_max"]:
                break
        return shown

    def abc(stream, finer, degree, ink):
        shown, before, n = 0, last + 1, len(stream)
        if not cfg["zt_boundaries"] or not cfg["zt_abc"] or n < 5:
            return shown
        for i in range(n - 2, max(3, n - 81) - 1, -1):
            endpoint, origin = stream[i], stream[i - 3]
            if origin.b < visible or endpoint.b >= before:
                continue
            points = stream[i - 3:i + 1]
            if not ordered(core, points, eps):
                continue
            prices = [p.p for p in points]
            direction, selected_kind, best = (-1 if origin.hi else 1), 0, 0.60
            for kind in range(4, 8):
                if core.geometry(prices, 3, kind, direction, eps):
                    fit = core.score(prices, 3, kind)
                    if fit >= best:
                        best, selected_kind = fit, kind
            if selected_kind == 0:
                continue
            proved = subdivisions(core, finer, points, selected_kind, eps)
            if cfg["zt_strict"] and not proved:
                continue
            family = {4: "Zigzag", 5: "Regular Flat", 6: "Expanded Flat", 7: "Running Flat"}[selected_kind]
            draw.bounds(points[1], points[3], points[0], points[2], endpoint,
                        ink, "solid" if proved else "dashed", 0.85)
            draw.label(endpoint, family + " bounds [" + ("S" if proved else "G") + "] "
                       + ("Large" if degree == 0 else "Child"), ink, True)
            record(points, degree, family, proved)
            shown += 1
            before = origin.b
            if shown >= cfg["zt_max"]:
                break
        return shown

    if core.candles:
        for degree, stream, finer, active, ink in (
                (0, core.major, core.minor, cfg["zt_large"], cfg["zt_large_color"]),
                (1, core.minor, core.micro, cfg["zt_child"], cfg["zt_child_color"])):
            if active:
                name = "large" if degree == 0 else "child"
                totals["triangles_" + name] = triangles(stream, finer, degree, ink)
                totals["abc_" + name] = abc(stream, finer, degree, ink)
    panels = []
    if cfg["zt_status"]:
        panels = [f"Triangle L: {totals['triangles_large']} / C: {totals['triangles_child']} | ABC bounds: {totals['abc_large'] + totals['abc_child']}",
                  "G = geometry | S = child proof | parent unverified"]
    return {"lines": draw.lines, "labels": draw.labels, "zones": [], "panels": panels,
            "patterns": patterns, "status": totals}
