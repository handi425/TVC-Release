"""ZWave PDF Fibonacci targets and conditional direction scenarios.

This Source Code Form is subject to the Mozilla Public License, v. 2.0.
https://mozilla.org/MPL/2.0/
Created by XoRonX | Mr Poleks. Python adaptation for HPX Markets.
Profile categories describe the supplied PDF, not measured probabilities.
"""
from __future__ import annotations

from datetime import datetime, timezone
from math import isfinite
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .zwave_patterns import same_pivot


PDF_DEFAULTS = {
    "show_large_fib": True, "show_child_fib": True, "child_fib_legs": 1,
    "large_fib_color": "#708090", "child_fib_color": "#48D1CC",
    "fib_line_width": 1, "fib_line_style": "Dotted",
    "large_fib_font_size": "Tiny", "child_fib_font_size": "Tiny",
    "large_fib_text_color": "#708090", "child_fib_text_color": "#48D1CC",
    "large_fib_text_alignment": "Right", "child_fib_text_alignment": "Right",
    "fib_text_shift": 1, "fib_right_extension": 20,
    "pf_enabled": True, "pf_degree": "Child", "pf_view": "Wave aktif/terakhir",
    "pf_method": "Larry Pull", "pf_tu": True, "pf_pu": True, "pf_u": True,
    "pf_su": True, "pf_rare": False, "pf_allow_developing": True,
    "pf_hide_swing_fib": True, "pf_shade": True, "pf_panel_on": True,
    "pf_forward": 20, "pf_tu_color": "#607D8B", "pf_pu_color": "#B8860B",
    "pf_u_color": "#228B22", "pf_su_color": "#E67E22",
    "pj_enabled": True, "pj_scope": "Ikuti Fibonacci PDF", "pj_class": "Paling umum",
    "pj_fallback": True, "pj_developing": True, "pj_alternative": True,
    "pj_show_levels": True, "pj_show_panel": True, "pj_horizon": 30,
    "pj_visual_atr": 2.0, "pj_bull": "#00897B", "pj_bear": "#C62828",
}

# (lower ratio, upper ratio, category rank), kept in Pine's original order.
PROFILES = {
    1: [(0.236, 0.382, 0), (0.618, 0.786, 1), (0.382, 0.5, 2), (0.886, 1, 4)],
    2: [(1, 1.618, 0), (3, 3.618, 0), (1.618, 1.786, 1), (1.786, 2.618, 1), (2.618, 3, 2), (4, 4.618, 4)],
    3: [(4.236, 4.236, 0), (4.414, 4.414, 0), (4.618, 4.618, 0), (1.236, 1.236, 1),
        (1.618, 1.618, 1), (2.236, 2.236, 1), (2.618, 2.618, 2), (3.236, 3.236, 2), (3.618, 3.618, 2)],
    4: [(0.236, 0.272, 0), (0.382, 0.5, 1), (0.3414, 0.382, 2), (0.618, 0.66, 2)],
    5: [(2, 2.618, 0), (1.236, 1.618, 1), (1.786, 2, 2)],
    6: [(0.236, 0.272, 0), (0.382, 0.5, 1), (0.236, 0.382, 2), (0.618, 0.66, 2), (0.786, 0.886, 2)],
    7: [(0.618, 0.618, 0), (2.382, 2.618, 0), (1.618, 1.786, 1), (1, 1, 2), (2, 2, 2),
        (2.236, 2.236, 2), (2.272, 2.272, 2), (1.236, 1.236, 3), (1.272, 1.272, 3), (1.382, 1.382, 3)],
    8: [(x, x, 5) for x in (0.618, 1, 1.236, 1.382, 1.618)],
    9: [(x, x, 5) for x in (1.236, 1.382, 1.618)],
    10: [(x, x, 5) for x in (0.618, 1, 1.236, 1.382, 1.618, 2.236)],
    11: [(x, x, 5) for x in (0.55, 0.618, 0.66, 0.706, 0.786)],
    12: [(x, x, 5) for x in (0.55, 0.618, 0.66, 0.706, 0.786, 0.9)],
    13: [(1.05, 1.13, 5), (1.236, 1.272, 5), (1.3414, 1.382, 5)],
}


def _number(value: float) -> str:
    return f"{value:.4f}".rstrip("0").rstrip(".")


def rank_name(rank: int) -> str:
    return {0: "Tak umum", 1: "Paling umum", 2: "Umum", 3: "Sangat umum", 4: "Langka"}.get(rank, "Tanpa peringkat")


def rank_color(rank: int, cfg: dict) -> str:
    return cfg["pf_tu_color"] if rank == 0 else cfg["pf_pu_color"] if rank == 1 else cfg["pf_u_color"] if rank == 2 else cfg["pf_su_color"] if rank == 3 else "#FF00FF" if rank == 4 else "#008080"


def same_path(a: Any, b: Any) -> bool:
    return (a.degree == b.degree and a.motive == b.motive and a.family == b.family
            and len(a.points) == len(b.points)
            and all(same_pivot(x, y) for x, y in zip(a.points, b.points)))


def path_valid(path: Any, counts: list, allow_developing: bool) -> bool:
    if not allow_developing and path.developing:
        return False
    if not path.family:
        for j, point in enumerate(path.points[1:], 1):
            name = str(j) if path.motive else "A" if j == 1 else "B" if j == 2 else "C"
            found = any(c.degree == path.degree and (allow_developing or "?" not in c.wave_name)
                        and same_pivot(c.pivot, point)
                        and f" / {name} / " in " / " + c.wave_name.replace("?", "") + " / "
                        for c in counts)
            if not found:
                return False
    return True


def select_path(paths: list, counts: list, degree: int, allow_developing: bool):
    selected, latest, ambiguous = None, -1, False
    for path in paths:
        if path.degree != degree or not path_valid(path, counts, allow_developing):
            continue
        end = path.points[-1].b
        if end > latest:
            selected, latest, ambiguous = path, end, False
        elif end == latest and not same_path(selected, path):
            ambiguous = True
    return selected, ambiguous


def extended_three(points: list, mintick: float) -> bool:
    if len(points) < 4:
        return False
    one, three = abs(points[1].p - points[0].p), abs(points[3].p - points[2].p)
    return one > mintick * 0.1 and three >= 2.618 * one


def _atr(bars: list[dict], last: int, period: int = 14) -> float | None:
    """Pine ta.atr: true range with Wilder RMA seeded by the first SMA."""
    current, warmup, previous = None, [], None
    for bar in bars[:last + 1]:
        h, l, close = float(bar["high"]), float(bar["low"]), float(bar["close"])
        tr = h - l if previous is None else max(h - l, abs(h - previous), abs(l - previous))
        if current is None:
            warmup.append(tr)
            if len(warmup) == period:
                current = sum(warmup) / period
        else:
            current = (current * (period - 1) + tr) / period
        previous = close
    return current


class _Draw:
    def __init__(self, kind: str, max_lines: int = 498, max_labels: int = 498):
        self.kind, self.max_lines, self.max_labels = kind, max_lines, max_labels
        self.lines: list[dict] = []
        self.labels: list[dict] = []
        self.zones: list[dict] = []

    def line(self, x1, y1, x2, y2, color, style="dotted", width=1, **extra):
        if y1 is None or y2 is None or not isfinite(y1) or not isfinite(y2) or x2 <= x1 or len(self.lines) >= self.max_lines:
            return None
        line = {"x1": x1, "y1": y1, "x2": x2, "y2": y2, "color": color,
                "style": style, "width": width, "kind": self.kind, **extra}
        self.lines.append(line)
        return line

    def label(self, index, price, text, color, size="Tiny", **extra):
        if price is None or not isfinite(price) or len(self.labels) >= self.max_labels:
            return None
        label = {"index": index, "price": price, "text": text, "color": color,
                 "size": size, "kind": self.kind, **extra}
        self.labels.append(label)
        return label


def ordinary_fibonacci(core: Any, config: dict | None = None) -> dict:
    """Two-point retracement grid; viewport-aware endpoints are exposed to UI."""
    cfg = {**PDF_DEFAULTS, **(config or {})}
    draw = _Draw("swing_fibonacci", 440, 440)
    if not core.candles or cfg["pf_enabled"] and cfg["pf_hide_swing_fib"]:
        return {"lines": [], "labels": [], "zones": [], "panels": []}
    last = core.candles[-1].b
    left_visible = cfg.get("left_visible_index")
    right_visible = cfg.get("right_visible_index", last)
    visible = core.major[max(0, len(core.major) - cfg.get("visible_major", 24))].b if core.major else last
    slots: list[dict] = []

    def fibonacci(a, b, degree: str, latest: bool):
        if not (b.t > a.t and a.hi != b.hi and abs(a.p - b.p) >= core.mintick * 0.5):
            return False
        align_left = cfg[degree + "_fib_text_alignment"] == "Left"
        left = a.b if left_visible is None else left_visible
        line_end = max(b.b, right_visible) + cfg["fib_right_extension"] if latest else b.b
        label_anchor = max(a.b, left) + cfg["fib_text_shift"] if align_left else line_end + max(1, cfg["fib_text_shift"])
        visible_label = (label_anchor >= left and label_anchor <= right_visible + cfg["fib_right_extension"] + cfg["fib_text_shift"]
                         and label_anchor <= line_end + max(1, cfg["fib_text_shift"]))
        for ratio in (0, 0.236, 0.382, 0.5, 0.618, 0.707, 0.786, 0.886, 1):
            price = b.p + (a.p - b.p) * ratio
            extra = {"latest": latest, "swing_start": a.b, "swing_end": b.b, "align_left": align_left,
                     "fib_right_extension": cfg["fib_right_extension"], "fib_text_shift": cfg["fib_text_shift"]}
            draw.line(a.b, price, line_end, price, cfg[degree + "_fib_color"], cfg["fib_line_style"].lower(), cfg["fib_line_width"], **extra)
            if visible_label:
                text = f"{ratio * 100:.1f}%"
                match = next((slot for slot in slots if slot["index"] == label_anchor and slot["align_left"] == align_left
                              and abs(slot["price"] - price) <= core.mintick * 0.5), None)
                if match is not None:
                    if text not in match["text"].split(" | "):
                        match["text"] += " | " + text
                else:
                    label = draw.label(label_anchor, price, text, cfg[degree + "_fib_text_color"], cfg[degree + "_fib_font_size"], **extra)
                    if label is not None and len(slots) < 72:
                        slots.append(label)
        return True

    if cfg["show_large_fib"] and len(core.major) >= 2:
        fibonacci(core.major[-2], core.major[-1], "large", True)
    if cfg["show_child_fib"] and len(core.minor) >= 2:
        found = 0
        for i in range(len(core.minor) - 1, 0, -1):
            a, b = core.minor[i - 1:i + 1]
            if a.b < visible:
                break
            if fibonacci(a, b, "child", found == 0):
                found += 1
            if found >= cfg["child_fib_legs"]:
                break
    return {"lines": draw.lines, "labels": draw.labels, "zones": [], "panels": []}


def pdf_targets(core: Any, config: dict | None = None) -> dict:
    cfg = {**PDF_DEFAULTS, **(config or {})}
    draw = _Draw("pdf_fibonacci")
    levels: list[dict] = []
    zones: list[dict] = []
    summary = [""] * 6
    status = "Menunggu counting yang memiliki anchor lengkap" if cfg["pf_enabled"] else "Fibonacci nonaktif"
    anchors, profile, selected_metadata = "", 0, None
    selected, ambiguous = (select_path(core.paths, core.counts, 0 if cfg["pf_degree"] == "Large" else 1,
                                       cfg["pf_allow_developing"]) if cfg["pf_enabled"] else (None, False))

    def level(price, caption, rank):
        found = next((v for v in levels if abs(v["price"] - price) < core.mintick * 0.25), None)
        priority = 4 if rank == 1 else 3 if rank == 3 else 2 if rank == 2 else 1
        if found is not None:
            if caption not in found["caption"]:
                found["caption"] += " / " + caption
            if priority > found["priority"]:
                found.update(color=rank_color(rank, cfg), priority=priority, category_rank=rank)
        elif len(levels) < 12:
            levels.append({"price": price, "caption": caption, "color": rank_color(rank, cfg), "priority": priority,
                           "category_rank": rank})

    if selected is not None and not ambiguous and core.candles:
        path, p = selected, selected.points
        stage = len(p) - 1
        triangle = bool(path.family)
        next_wave = cfg["pf_view"] == "Wave berikutnya" or not triangle and stage == 1
        target = stage + int(next_wave)
        base = unit = None
        wave, measure, pages = "", "Larry Pull", ""
        o, one, endpoint = p[0], p[1], p[-1]
        if triangle:
            if not next_wave and "Expanding" not in path.family:
                profile, base, unit = (12 if "Barrier" in path.family else 11), p[4].p, p[3].p - p[4].p
                wave, measure, pages = "Triangle E", "Retracement leg D", "18-20"
            else:
                status = "Belum ada target Fibonacci langsung setelah E / Expanding Triangle"
        elif path.motive:
            wave, pages = "Wave " + str(target), str(target + 5)
            if target == 2:
                profile, base, unit, measure = 1, one.p, o.p - one.p, "Retracement W1"
            elif target == 3:
                larry = cfg["pf_method"] == "Larry Pull"
                profile, base, unit, measure = 2 if larry else 3, o.p if larry else p[2].p, one.p - o.p, cfg["pf_method"]
            elif target == 4:
                profile, base, unit, measure = 4, p[3].p, p[2].p - p[3].p, "Retracement W3"
            elif target == 5:
                profile, base, unit = 5, p[4].p, p[3].p - p[4].p
            else:
                status = "Setelah Wave 5: menunggu counting baru"
        else:
            wave, pages = ("Wave B", "12") if target == 2 else ("Wave C", "13")
            if target == 2:
                profile, base, unit, measure = 6, one.p, o.p - one.p, "Retracement A"
                if stage >= 2 and abs(p[2].p - one.p) > abs(one.p - o.p):
                    profile, pages, measure = 13, "15/17", "B Expanded/Running - rasio pola tanpa peringkat"
            elif target == 3:
                profile, base, unit = 7, o.p, one.p - o.p
                if cfg["pf_method"] != "Larry Pull" and unit:
                    base = p[2].p
                    ratio = abs(p[2].p - one.p) / abs(unit)
                    profile = 10 if ratio > 1 else 9 if ratio >= 0.886 else 8
                    measure = "Trend Based C (keluarga masih hipotesis)"
            else:
                status = "Setelah C: menunggu counting baru"
        if profile > 0 and unit is not None and abs(unit) >= core.mintick:
            for lo, hi, rank in PROFILES[profile]:
                if not cfg.get({0: "pf_tu", 1: "pf_pu", 2: "pf_u", 3: "pf_su", 4: "pf_rare"}.get(rank, ""), True):
                    continue
                level(base + unit * lo, _number(lo), rank)
                if hi != lo:
                    level(base + unit * hi, _number(hi), rank)
                    zones.append({"a": base + unit * lo, "b": base + unit * hi, "color": rank_color(rank, cfg)})
                entry = _number(lo) + (" - " + _number(hi) if hi != lo else "")
                summary[rank] += ("; " if summary[rank] else "") + entry
            if profile == 5 and len(p) >= 5:
                extended = extended_three(p, core.mintick)
                rank = 2 if extended else 0
                if extended and cfg["pf_u"] or not extended and cfg["pf_tu"]:
                    level(p[4].p + one.p - o.p, "1x W1", rank)
            condition = " ? bersyarat" if path.developing else " bersyarat" if next_wave else " evaluasi counting terakhir"
            status = "Fibonacci | " + wave + condition + " | " + cfg["pf_degree"] + " | " + measure
            try:
                origin_zone = ZoneInfo(getattr(core, "timezone", "UTC"))
            except (ZoneInfoNotFoundError, ValueError, TypeError):
                origin_zone = timezone.utc
            origin_date = datetime.fromtimestamp(o.t, origin_zone).strftime("%d %b %Y")
            anchors = f"Anchor Fibonacci | harga = {_number(base)} + r x {_number(unit)} | origin {origin_date}"
            last = core.candles[-1].b
            left, right = max(endpoint.b, last - 80), last + cfg["pf_forward"]
            tooltip = anchors + "; warna menandai kategori referensi, bukan probabilitas hasil backtest. " + ("Target berikutnya, bersyarat pada counting." if next_wave else "Evaluasi wave yang dilabeli, bukan klaim wave berikutnya.")
            for item in levels:
                draw.line(left, item["price"], right, item["price"], item["color"], "dotted" if path.developing else "dashed")
                draw.label(right + 1, item["price"], wave + " | " + item["caption"] + " | " + _number(item["price"]), item["color"], tooltip=tooltip)
            if cfg["pf_shade"]:
                for zone in zones:
                    a = next((v for v in levels if abs(v["price"] - zone["a"]) < core.mintick * 0.25), None)
                    b = next((v for v in levels if abs(v["price"] - zone["b"]) < core.mintick * 0.25), None)
                    if a is not None and b is not None and a is not b:
                        draw.zones.append({"x1": left, "x2": right, "lower": min(zone["a"], zone["b"]), "upper": max(zone["a"], zone["b"]), "color": zone["color"], "opacity": 0.08, "kind": "pdf_fibonacci"})
            selected_metadata = {"degree": path.degree, "stage": stage, "wave": wave, "next": next_wave,
                                 "developing": path.developing, "family": path.family, "base": base, "unit": unit,
                                 "profile": profile, "endpoint_index": endpoint.b, "origin_index": o.b}
    elif ambiguous:
        status = "Counting alternatif / anchor ambigu - target otomatis ditahan"
    panels = []
    if cfg["pf_panel_on"] and cfg["pf_enabled"]:
        panels = [status]
        if anchors:
            panels.append(anchors)
    return {"lines": draw.lines, "labels": draw.labels, "zones": draw.zones, "panels": panels,
            "levels": levels, "summary": {rank_name(i): s for i, s in enumerate(summary) if s},
            "color_legend": [{"rank": rank, "color": rank_color(rank, cfg), "label": rank_name(rank), "ranges": values}
                             for rank, values in enumerate(summary) if values] if cfg["pf_panel_on"] and cfg["pf_enabled"] else [],
            "status": status, "anchors": anchors, "selection": selected_metadata, "ambiguous": ambiguous}


def projection_priority(rank: int, category: str) -> int:
    preferred = 0 if category == "Tak umum" else 2 if category == "Umum" else 1
    return 0 if category == "Terdekat dari semua kategori" or rank == preferred else 1 if rank == 1 else 2 if rank == 3 else 3 if rank == 2 else 4 if rank == 0 else 5


def projection_bands(profile: int, base: float, unit: float) -> list[dict]:
    """Projection profiles deliberately omit Rare bands, as the Pine does."""
    return [{"a": base + unit * lo, "b": base + unit * hi, "rank": rank,
             "ratios": _number(lo) + (" - " + _number(hi) if hi != lo else "")}
            for lo, hi, rank in PROFILES.get(profile, []) if profile <= 10 and rank != 4]


def pick_projection_band(bands: list[dict], direction: int, invalidation: float | None,
                         invalid_side: int, trigger: float | None, close: float,
                         mintick: float, config: dict | None = None):
    cfg = {**PDF_DEFAULTS, **(config or {})}
    selected, goal, best_priority, best_distance = None, None, 100, 1e20
    preferred = 0 if cfg["pj_class"] == "Tak umum" else 2 if cfg["pj_class"] == "Umum" else 1
    for i, band in enumerate(bands):
        near = min(band["a"], band["b"]) if direction > 0 else max(band["a"], band["b"])
        far = max(band["a"], band["b"]) if direction > 0 else min(band["a"], band["b"])
        mid = (near + far) * 0.5
        candidate = mid if direction * (mid - close) > mintick else far
        allowed = cfg["pj_fallback"] or cfg["pj_class"] == "Terdekat dari semua kategori" or band["rank"] in (preferred, 5)
        legal = invalidation is None or invalid_side != direction or direction * (far - invalidation) < -mintick
        if (allowed and legal and direction * (candidate - close) > mintick
                and (trigger is None or direction * (candidate - trigger) > mintick)):
            priority = projection_priority(band["rank"], cfg["pj_class"])
            distance = direction * (candidate - close)
            if priority < best_priority or priority == best_priority and distance < best_distance:
                best_priority, best_distance, selected, goal = priority, distance, i, candidate
    return selected, goal


def _trigger(core, stream: list, endpoint: Any, direction: int, fallback: float) -> float:
    n = len(stream)
    if n >= 3:
        for i in range(n - 2, max(0, n - 81) - 1, -1):
            point = stream[i]
            if point.b > endpoint.b and point.hi == (direction > 0) and core.known(point):
                return point.p
    return fallback


def direction_projection(core: Any, config: dict | None = None) -> dict:
    """Source-equivalent next-direction scenario; never generates OHLC bars."""
    cfg = {**PDF_DEFAULTS, **(config or {})}
    draw = _Draw("direction_projection", 6, 6)
    headline = "Proyeksi: menunggu counting lengkap" if cfg["pj_enabled"] else ""
    detail, levels, ink = "", "", "#808080"
    degree = (0 if cfg["pj_scope"] == "Large" else 1 if cfg["pj_scope"] == "Child"
              else 0 if cfg["pf_degree"] == "Large" else 1)
    selected, ambiguous = (select_path(core.paths, core.counts, degree, cfg["pj_developing"])
                           if cfg["pj_enabled"] else (None, False))
    scenario: dict = {"available": False, "ambiguous": ambiguous, "degree": degree,
                      "is_scenario": True, "horizon_is_prediction": False}

    def label(x, price, caption, color, explanation):
        draw.label(x, price, caption, color, "Small", tooltip=explanation + " Jalur adalah skenario bersyarat; panjang candle hanya ruang gambar.")

    if ambiguous:
        headline = "Proyeksi ditahan: counting / anchor alternatif"
    elif selected is not None and core.candles:
        path, p = selected, selected.points
        stage = len(p) - 1
        o, one, endpoint = p[0], p[1], p[-1]
        last = core.candles[-1].b
        close = float(core.bars[last]["close"])
        finer = core.minor if degree == 0 else core.micro
        impulse_direction = 1 if one.p > o.p else -1
        direction, profile, invalid_side = 0, 0, 0
        base = unit = trigger = invalidation = structural = None
        next_wave, open_scenario = "", False
        raw_atr = _atr(core.bars, last)
        atr = max(core.mintick * 10, raw_atr if raw_atr is not None else abs(close) * 0.001)
        right = last + cfg["pj_horizon"]
        scenario.update(available=True, stage=stage, developing=path.developing,
                        family=path.family, endpoint_index=endpoint.b, close=close)
        if path.family:
            upper = max(point.p for point in p[1:6])
            lower = min(point.p for point in p[1:6])
            up, down = close > upper + core.mintick, close < lower - core.mintick
            headline = "Triangle: breakout rentang atas teramati" if up else "Triangle: breakout rentang bawah teramati" if down else "Triangle: tunggu breakout rentang A-E"
            detail = "Arah setelah E bersyarat; belum ada target thrust Fibonacci langsung"
            levels = f"Atas {_number(upper)} | bawah {_number(lower)}"
            if cfg["pj_show_levels"]:
                draw.line(last, upper, right, upper, cfg["pj_bull"])
                draw.line(last, lower, right, lower, cfg["pj_bear"])
            if up or not down and cfg["pj_alternative"]:
                y = close + atr * cfg["pj_visual_atr"] if up else upper + atr * 0.5
                draw.line(last, close, right, y, cfg["pj_bull"], "dashed", 2)
                label(right, y, "Naik? setelah tembus atas", cfg["pj_bull"], "Skenario arah; panjang visual ATR, bukan target Fibonacci. Gagal bertahan di dalam batas Triangle membatalkan asumsi breakout.")
            if down or not up and cfg["pj_alternative"]:
                y = close - atr * cfg["pj_visual_atr"] if down else lower - atr * 0.5
                draw.line(last, close, right, y, cfg["pj_bear"], "dashed", 2)
                label(right, y, "Turun? setelah tembus bawah", cfg["pj_bear"], "Skenario arah; panjang visual ATR, bukan target Fibonacci. Gagal bertahan di dalam batas Triangle membatalkan asumsi breakout.")
            scenario.update(triangle=True, upper=upper, lower=lower,
                            breakout="up" if up else "down" if down else None,
                            target_is_pdf=False)
        else:
            if path.motive and stage <= 4:
                target = stage + 1
                next_wave = "W" + str(target) + "?"
                direction = -impulse_direction if target in (2, 4) else impulse_direction
                if target == 2:
                    profile, base, unit = 1, one.p, o.p - one.p
                    trigger, invalidation, invalid_side = one.p + unit * 0.236, o.p, direction
                elif target == 3:
                    larry = cfg["pf_method"] == "Larry Pull"
                    profile, base, unit = 2 if larry else 3, o.p if larry else p[2].p, one.p - o.p
                    trigger, invalidation, invalid_side = one.p, p[2].p, -direction
                elif target == 4:
                    profile, base, unit = 4, p[3].p, p[2].p - p[3].p
                    trigger, invalidation, invalid_side = base + unit * 0.236, one.p, direction
                elif target == 5:
                    profile, base, unit = 5, p[4].p, p[3].p - p[4].p
                    trigger, invalidation, invalid_side = p[3].p, p[4].p, -direction
            elif not path.motive and stage <= 2:
                direction = -impulse_direction if stage == 1 else impulse_direction
                next_wave = "B?" if stage == 1 else "C?"
                if stage == 1:
                    profile, base, unit = 6, one.p, o.p - one.p
                    trigger = base + unit * 0.236
                else:
                    profile, base, unit, trigger = 7, o.p, one.p - o.p, one.p
                    if cfg["pf_method"] != "Larry Pull" and unit:
                        base = p[2].p
                        ratio = abs(p[2].p - one.p) / abs(unit)
                        profile = 10 if ratio > 1 else 9 if ratio >= 0.886 else 8
                invalidation, invalid_side = endpoint.p, -direction
            else:
                open_scenario, direction = True, -impulse_direction
                next_wave = "Koreksi setelah 5?" if path.motive else "Reaksi setelah C?"
                structural = p[4].p if path.motive else p[2].p
                fallback = endpoint.p + direction * max(core.mintick * 2, abs(endpoint.p - structural) * 0.25)
                trigger = _trigger(core, finer, endpoint, direction, fallback)
                invalidation, invalid_side = endpoint.p, -direction
            ink = cfg["pj_bull"] if direction > 0 else cfg["pj_bear"]
            invalid = False
            if invalidation is not None and endpoint.b + 1 < core.cache.base + core.cache.n:
                extreme = core.range(endpoint.b + 1, core.cache.base + core.cache.n - 1, 1 if invalid_side > 0 else -1)
                invalid = extreme is not None and isfinite(extreme) and (extreme > invalidation + core.mintick if invalid_side > 0 else extreme < invalidation - core.mintick)
            scenario.update(triangle=False, direction="up" if direction > 0 else "down",
                            next_wave=next_wave, trigger=trigger, invalidation=invalidation,
                            invalid_side=invalid_side, invalid=invalid, profile=profile,
                            open_scenario=open_scenario, target_is_pdf=profile > 0)
            if invalid:
                headline = "Skenario " + next_wave + " invalid - menunggu counting baru"
                detail, ink = "Batas pernah dilanggar pada candle tertutup sejak anchor", "#808080"
            else:
                triggered = trigger is not None and direction * (close - trigger) >= 0
                headline = ("NAIK: " if direction > 0 else "TURUN: ") + next_wave + " | " + ("harga melewati pemicu" if triggered else "bersyarat, tunggu pemicu")
                scenario["triggered"] = triggered
                if profile > 0:
                    bands = projection_bands(profile, base, unit)
                    index, goal = pick_projection_band(bands, direction, invalidation, invalid_side, trigger, close, core.mintick, cfg)
                    if index is not None:
                        band = bands[index]
                        detail = "Target Fibonacci " + band["ratios"]
                        a = draw.line(last + 2, band["a"], right, band["a"], ink)
                        b = draw.line(last + 2, band["b"], right, band["b"], ink)
                        if a is not None and b is not None and band["a"] != band["b"]:
                            draw.zones.append({"x1": last + 2, "x2": right, "lower": min(band["a"], band["b"]), "upper": max(band["a"], band["b"]), "color": ink, "opacity": 0.10, "kind": "direction_projection"})
                        draw.line(last, close, right, goal, ink, "dashed", 2, arrow=True)
                        label(right, goal, ("Naik " if direction > 0 else "Turun ") + next_wave + " | " + _number(goal), ink, detail + "; hanya target yang masih di depan harga dipilih.")
                        scenario.update(goal=goal, band=band)
                    else:
                        headline = "Target Fibonacci berikutnya terlewati / melanggar invalidasi"
                        detail = "Tidak menarik panah kembali ke target lama; tunggu counting baru"
                        scenario["target_unavailable"] = True
                elif open_scenario:
                    ahead = direction * (structural - close) > core.mintick and direction * (structural - trigger) > core.mintick
                    visual = close + direction * atr * cfg["pj_visual_atr"]
                    goal = structural if ahead else max(visual, trigger + atr * 0.5) if direction > 0 else min(visual, trigger - atr * 0.5)
                    detail = "Referensi struktur " + _number(structural) + "; bukan target Fibonacci" if ahead else "Panah arah visual ATR; belum ada target Fibonacci langsung"
                    draw.line(last, close, right, goal, ink, "dashed", 2, arrow=True)
                    if ahead:
                        draw.line(last + 2, structural, right, structural, ink)
                    label(right, goal, next_wave + (" | area struktur" if ahead else " | arah saja"), ink, detail + "; belum membuktikan wave A/1 baru.")
                    scenario.update(goal=goal, structural=structural, structural_ahead=ahead)
                    if cfg["pj_alternative"] and not triggered:
                        opposite = close - direction * atr * cfg["pj_visual_atr"]
                        draw.line(last, close, right, opposite, "#808080", "dashed", 1, arrow=True)
                        label(right, opposite, "Alternatif: tren lanjut / koreksi kompleks", "#808080", "Alternatif tanpa target Fibonacci; dipertimbangkan bila reaksi belum mendapat pemicu.")
            levels = "Pemicu " + (_number(trigger) if trigger is not None else "na") + " | invalidasi skenario " + (_number(invalidation) if invalidation is not None else "na")
            if cfg["pj_show_levels"]:
                draw.line(last, trigger, right, trigger, ink, opacity=0.65)
                draw.line(last, invalidation, right, invalidation, "#808080")
                if invalidation is not None:
                    label(right, invalidation, "Invalidasi " + _number(invalidation), "#808080", "Batas skenario dengan anchor tetap; dapat memerlukan recount. Pelanggaran diperiksa pada seluruh candle tertutup setelah endpoint.")
    panels = [headline, detail, levels] if cfg["pj_enabled"] and cfg["pj_show_panel"] else []
    return {"lines": draw.lines, "labels": draw.labels, "zones": draw.zones, "panels": panels,
            "headline": headline, "detail": detail, "levels": levels, **scenario}


def fibonacci_pdf(core: Any, config: dict | None = None, patterns: dict | None = None) -> dict:
    """Compose the source's ordinary grids, PDF targets and direction overlay.

    Call analyze_patterns first: settled Triangle paths participate in both
    automatic target and projection selection, including ambiguity checks.
    """
    swing = ordinary_fibonacci(core, config)
    pdf = pdf_targets(core, config)
    projection = direction_projection(core, config)
    return {"lines": swing["lines"] + pdf["lines"] + projection["lines"],
            "labels": swing["labels"] + pdf["labels"] + projection["labels"],
            "zones": pdf["zones"] + projection["zones"],
            "panels": pdf["panels"] + projection["panels"],
            "levels": pdf["levels"], "summary": pdf["summary"], "pdf": pdf, "color_legend": pdf["color_legend"],
            "projection": projection}
