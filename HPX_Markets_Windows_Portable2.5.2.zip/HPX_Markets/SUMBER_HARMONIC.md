# Harmonic validation bands: source and numerical contract

`harmonic_validation.json` supplies learning-panel overlays for the twelve Harmonic families. It does not change HPX scanner criteria. Price points in an existing lesson remain schematic; a missing three-way intersection must be shown honestly rather than moving a pivot to manufacture confluence.

## Sources reviewed

Primary supplied reference: `D:/INVESTMENT COURSE/Six Figure Harmonic Pattern/2. Course Bonuses/4. Trader Resources/Harmonic Mastery (Student Edition).pdf`, 65 pages. Page numbers below are **PDF file pages, one-based**; printed page numbers are one lower. Text was extracted locally and the relevant diagrams rendered and visually inspected. Temporary extraction/renders are in `tmp/pdfs/harmonic-validation/` and are not app content.

Reviewed elements: file pages 9–18. Reviewed risk illustrations: 31–35. Reviewed PRZ examples: 39–55. A primary independent cross-check for the Cypher denominator is [TradingView's Cypher drawing-tool documentation](https://www.tradingview.com/support/solutions/43000791680-cypher-harmonic-pattern-drawing-tool/), which specifies D as 78.6% of **XC**. Stingray is HPX-specific and is sourced from `backend/hpx.py`, notably `b_eligible`, `c_eligible`, `option` for kind 12, and `raw_hop`.

## Units and B-only tolerance

All numerical ratios are fractions: `0.382` means 38.2%, `1.618` means 161.8%. Additional tolerance in this **Fibonacci guide only** is restricted to B measurements with explicit annotations in the supplied book. Original C/D ranges, final D sources, AB=CD candidates and reference-only basis rulers have no additional padding. No scanner setting or scanner algorithm is changed.

The book's percent notation does not explicitly define relative-percent multiplication versus percentage-point addition. The guide uses **percentage points** for the annotated amounts, preserving the user's 50%→55% Bat example. This unit interpretation is an implementation choice, not a statement that the book mandates a universal tolerance formula. The Bat notation places its allowance at 50%; it does not support reducing the original 38.2% lower boundary to 33.2%.

| Family | Original B core | Book's annotation | Guide outer range | File / printed pages |
| --- | --- | --- | --- | --- |
| Bat | 38.2–50% XA | B allowance ±5% at 50% | **38.2–55%**; original lower boundary retained | 9 / 8 |
| Gartley | 61.8% XA | B allowance ±3% | **58.8–64.8%** | 9–10 / 8–9 |
| Butterfly | 78.6% XA | B allowance ±3% | **75.6–81.6%** | 10 / 9 |
| Alternate Bat | 38.2% XA | B allowance one-sided -3% | **35.2–38.2%** | 11–12 / 10–11 |
| Crab | 38.2–61.8% XA | Explicitly no defined tolerance | Original core, no padding | 11 / 10 |
| Deep Crab | 88.6% XA | No tolerance annotation | Original core, no padding | 12 / 11 |

All other Harmonic sources, including Shark, Cypher, AB=CD, 5-0, Three Drives and HPX-specific Stingray, retain their original ranges without invented book tolerance. Source absence is not reinterpreted as permission for a default ±5-point band.

Every Harmonic source explicitly sets the legacy `tolerance_pp` to **zero**. Positive magnitudes `tolerance_pp_lower` and `tolerance_pp_upper` specify the additional allowance on the low and high ratio boundaries: Bat B `0/5`, Gartley B `3/3`, Butterfly B `3/3`, Alternate Bat B `3/0`, and `0/0` everywhere else. `tolerance_label` and `tolerance_note` identify the source scope and unit interpretation. This prevents a renderer's symmetric fallback from widening unannotated C/D ranges.

## Core ratios and reference legs

| Family | B or first correction | C or second pivot | D references | File pages |
| --- | --- | --- | --- | --- |
| Bat | 0.382–0.50 XA | 0.382–0.886 AB | 0.886 XA; 1.618–2.618 BC; equal/alternate AB=CD | 9, 15–16, 39–41 |
| Gartley | 0.618 XA | 0.382–0.886 AB | 0.786 XA; 1.13–1.618 BC; AB=CD | 9–10, 15–16 |
| Butterfly | 0.786 XA | 0.382–0.886 AB | 1.272 XA; 1.618–2.24 BC; alternate AB=CD | 10, 44–45 |
| Alternate Bat | 0.382 XA reference | 0.382–0.886 AB | 1.13 XA; 2.0–3.618 BC; alternate AB=CD | 11–12, 47–48 |
| Crab | 0.382–0.618 XA | 0.382–0.886 AB | 1.618 XA; 2.618–3.618 BC; alternate AB=CD | 11, 46 |
| Deep Crab | 0.886 XA | 0.382–0.886 AB | 1.618 XA; 2.0–3.618 BC; equal/alternate AB=CD | 12, 49–50 |
| Shark | A/OX 0.382–0.618 is optional | B/XA 1.13–1.618 | C/OB 0.886–1.13 and C/AB 1.618–2.24, in the book's OXABC notation | 13, 51–53 |
| Cypher | 0.382–0.618 XA | Diagram's strict C/XA 1.272–1.414 | 0.786 whole XC | 13–14, 53–55 |
| AB=CD | C/AB 0.382–0.886 | — | AB=CD, separate alternate projections; BC 1.13–2.618 as companion measurement | 15–16 |
| 5-0 | 1.13–1.618 XA | 1.618–2.24 AB | 0.50 BC plus reciprocal AB=CD | 14, 16 |
| Three Drives | 0.618–0.786 first-drive correction | 1.272–1.618 next drive, then 0.618–0.786 correction | Third-drive projection 1.272–1.618, local AB=CD and drive symmetry comparisons | 17–18 |
| Stingray | HPX Bat/Gartley-route B 0.382–0.618 XA | HPX C/AB 0.382–0.886 | HPX 1.272–1.414 XA; no book-based required BC/AB=CD D ranges | HPX source code |

The Alternate Bat B point is the specific reference edition's 0.382 example. It is not a claim that all published Alternate Bat definitions require exactly 0.382. The Cypher C core intentionally follows the stricter 1.272–1.414 diagram supplied by the user; TradingView allows a broader lower bound of 1.13, which is not silently substituted.

For an equal/alternate AB=CD family, ratios are separate candidates, not a continuous admissible interval. The metadata selects the equal or example projections relevant to each family: Bat 1, 1.272, 1.618; Butterfly 1.13 and 1.272; Alternate Bat 2.618; Crab 1.618, 2.24 and 3.14; Deep Crab 1.272 and 1.618; standalone AB=CD 1, 1.272 and 1.618. General alternate projection discussion is on pages 15–16; family examples are on the PRZ pages listed above. A projected candidate is a comparison that still needs confluence and structural validation, not a promise that each alternate is valid for arbitrary C.

## Source conflicts and notation

- **Butterfly, page 10:** the diagram labels BC 1.618–2.24. The adjacent text table repeats the Gartley 1.13–1.618 range. The panel uses the actual Butterfly diagram and records the conflict.
- **Cypher, pages 13–14:** the element caption says D/XA and calls the C measurement AB extension, conflicting with the labeled geometry, later PRZ discussion, and primary Cypher definition. The panel uses C projected from XA and D retraced from **whole XC**. No required BC or AB=CD D source is invented.
- **Shark:** the supplied reference uses **O–X–A–B–C**, while the existing HPX lesson has **X–A–B–C–D**. Map book O→guide X, X→A, A→B, B→C, C→D. Thus book **OB becomes guide XC**, and book **AB becomes guide BC**. The legacy step id `cd-xa` remains for compatibility, but its validation metadata and title now correctly select XC; the source name is preserved in the card.
- **Three Drives:** book second correction B is labeled C on the existing HPX illustration; sources explicitly identify this mapping.
- **Stingray:** no Stingray definition appears in this book. The guide identifies its ranges as HPX-specific. The HPX code supplies XA completion and raw 1.618 XA protection; it does not impose canonical BC and AB=CD D bands. Using measured D-derived ratios to fabricate validation would be circular.

## Confluence and stop calculation

A source is a **union** of its core and any alternate candidates. Only the four explicitly annotated B sources receive the asymmetric allowances described above; C/D candidates remain at their original ranges or exact point ratios. Do not shade the gaps between 100%, 127.2%, and 161.8% candidates. A final confluence is the **intersection of the source-family unions**. This allows “AB=CD OR an alternate AB=CD” without incorrectly requiring mutually exclusive projections simultaneously. Empty intersection remains empty; an exact-point intersection remains a point. Existing schematic pivots are not moved to create overlap, so removing invented D padding can correctly leave the illustrated final sources without a common PRZ.

Retracement price for anchor prices `(p, q)` and ratio `r` is `q - r*(q-p)`. Extension for `(p,q,z)` is `z + r*(q-p)`. Anchor order matters; Cypher C uses reversed `[A,X]`, while D uses `[X,C]`.

The SL overlay is a learning illustration based on both the source limit and the whole displayed ratio envelope. It is placed farther in the adverse direction than **every displayed candidate** and the optional structural limit, then receives a separate buffer of 5% of the named reference-leg length. This is deliberately explicit and is not a universal live-trading risk rule. This existing illustrative SL buffer is distinct from B validation tolerance; retaining it does not add tolerance to C or D ratios.

| Family | Structural SL basis before extra buffer | File page |
| --- | --- | --- |
| Bat | beyond 1.13 XA | 31 |
| Gartley | beyond X, equivalent to XA retracement 1.0 | 31 |
| Butterfly | beyond 1.414 XA | 31 |
| Alternate Bat | beyond 1.272 XA | 32 |
| Crab, Deep Crab | beyond 2.0 XA | 32 |
| Cypher | beyond X | 33 |
| Shark | beyond 1.13 OB for the 0.886 setup; beyond 1.272 OB for the 1.13 setup. The composite illustration uses the deeper 1.272 OB threshold. | 33 |
| 5-0 | beyond 0.618 BC retracement | 33 |
| AB=CD | reference says beyond the next projection; panel illustrates 2.0 after its deepest 1.618 candidate | 34 |
| Three Drives | reference says beyond next projection; panel illustrates 2.0 after 1.618 | 35 |
| Stingray | raw HPX 1.618 XA limit | HPX code |

For AB=CD and Three Drives, 2.0 is the panel's explicitly documented next-projection illustration; it is not represented as a fixed numerical stop mandated by the reference. Mirror transformations must reflect both bands and SL exactly. The direction reference is `[X,A]` for standard XABCD, `[X,C]` for Shark's OB, `[B,C]` for 5-0, `[B,A]` for AB=CD and `[1,O]` for Three Drives.

No source pages or long copyrighted excerpts are embedded in the application. The data above paraphrases numerical and geometric facts for the requested overlays.
