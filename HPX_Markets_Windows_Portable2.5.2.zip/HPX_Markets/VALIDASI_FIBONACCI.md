# Area rasio, toleransi, konfluensi D, dan SL pada Panduan

## Toleransi

Panduan Harmonic versi 2.5.2 memakai toleransi **hanya pada B yang dianotasi eksplisit dalam buku**. C, D, dan semua sumber proyeksi D memakai rasio/rentang aslinya tanpa tambahan toleransi. X dan A adalah titik acuan pengukuran.

| Pola | Inti B | Batas B yang ditampilkan |
| --- | --- | --- |
| BAT | 38,2–50% | 38,2–55%; toleransi pada acuan 50%, batas bawah tidak diperlebar |
| Gartley | 61,8% | 58,8–64,8% (±3 poin) |
| Butterfly | 78,6% | 75,6–81,6% (±3 poin) |
| Alternate BAT | 38,2% | 35,2–38,2% (−3 poin satu sisi) |
| Pola lain | Rasio/rentang asli | Tidak ditambah toleransi yang tidak dinyatakan sumber |

Buku menulis persen tanpa menjelaskan secara tegas persen relatif atau poin persentase. Panduan memakai interpretasi poin persentase, konsisten dengan contoh pengguna 50% menjadi 55%; ini dicatat sebagai interpretasi satuan, bukan kutipan batas numerik dari buku. Batas BAT 33,2% pada versi 2.5.0 telah dihapus. Perbaikan khusus Panduan Fibonacci, sesuai klarifikasi pengguna; mesin deteksi Chart, Radar, dan Pantau tidak diubah. Elliott memakai rasio aslinya tanpa toleransi, dengan aturan struktur tetap berlaku.

Sumber tanpa toleransi menampilkan area asli; nilai tunggal ditampilkan sebagai garis, tanpa lebar buatan. Titik diagram dipertahankan dan diukur, bukan dipindahkan agar terlihat cocok. Area panduan adalah acuan pengukuran. Deteksi mengikuti parameter Harmonic pada Pengaturan.

## Harmonic

`harmonic_validation.json` memetakan 65 langkah pada 12 keluarga. Pada langkah terakhir D, XA, BC, dan AB=CD ditampilkan bersama bila ketiganya merupakan pengukuran yang relevan. Kandidat alternatif AB=CD tetap terpisah. Konfluensi dihitung dengan mengiriskan gabungan kandidat setiap sumber; celah tidak diisi dan hasil kosong tetap dijelaskan.

Cypher memakai XC; Shark memerlukan padanan notasi O-X-A-B-C terhadap label HPX; AB=CD, 5-0, Three Drives, dan Stingray mempunyai referensi khusus. Tidak ditambahkan syarat XA/BC/AB=CD yang tidak berlaku pada suatu pola.

SL skematis berada di luar seluruh area sumber serta batas struktural yang dirujuk, kemudian diberi buffer berdasarkan panjang ayunan acuan. Buffer SL terpisah dari toleransi rasio B dan tidak memperlebar C atau D. Angka SL adalah demonstrasi posisi invalidasi dan buffer, bukan ukuran risiko transaksi yang berlaku universal.

Rujukan utama: *Harmonic Mastery (Student Edition)*. Halaman fisik dan nomor cetak, ketidakkonsistenan tabel Butterfly/Cypher, metode tiap anchor, serta dasar SL dicatat dalam `HARMONIC_VALIDATION_SOURCES.md`.

## Elliott

`elliott_validation.json` memetakan 76 langkah pada 16 artikel. Seluruh 226 sumber rasio Elliott memakai **nol tambahan toleransi**. Rasio, kandidat alternatif, titik penarikan, kategori, dan aturan struktur dipertahankan dari acuan Elliott; tidak diganti dengan rasio Harmonic. Angka tunggal tampil sebagai garis tepat dan rentang memakai batas aslinya. Kategori **Umum** dan **Paling umum** mengikuti tabel yang memang memberi peringkat. Angka yang terpisah tetap terpisah; pengelompokan tidak otomatis diubah menjadi rentang kontinu. Tabel pola tanpa peringkat disebut **acuan**, dan bagian tanpa target numerik menjelaskan batas referensinya.

Rasio Larry Pull dua titik dan Trend Based tiga titik memakai anchor masing-masing. Wave 5 paling umum dari sumber menggunakan 0→3→4 pada 0,618; perbandingan terhadap Wave 1 tetap metode berbeda. Batas struktur tetap berlaku, termasuk larangan Wave 2 menyentuh/melewati awal Wave 1. Jika acuan tunggal berada di luar batas struktur, rasionya tetap dijelaskan pada kartu tetapi tidak dicat sebagai area valid. Ini berlaku pada acuan C Expanded Flat 1,236 di bawah batas >1,25 serta acuan Wave 4 Ending Diagonal 0,5 yang tepat pada batas eksklusif. Tidak dibuat toleransi untuk memaksakan kecocokan.

Rujukan utama: *Elliott Wave Cheatsheet* (2022), 24 halaman berkas. Pemetaan kategori, metode, batas struktur, dan errata Running Flat/Regular Flat/Barrier dicatat dalam `elliott_validation_sources.md`.

## Video terbaru

- Stingray: `m3AGdq77Bmg`, judul terverifikasi “19 Stingray”.
- Expanding Triangle: `OBDyqxjYluk`, judul terverifikasi “29 Expanding Triangle 1080p”. Tautan pertama disebut Expanded Flat dalam pesan, tetapi subjek video dan materi yang dibuat sebelumnya adalah Expanding Triangle. Video Expanded Flat tetap memakai pelajaran yang sesuai.

Keduanya berasal dari MR Poleks dan mengizinkan embed saat diperiksa pada 28 Oktober 2026. Tautan baru dibuka langsung ke video, tanpa mengasumsikan video sudah menjadi anggota playlist.
